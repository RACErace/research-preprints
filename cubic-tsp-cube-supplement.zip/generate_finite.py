"""Generate proof trees; for an independent replay run verify_finite.py."""
import argparse
from collections import Counter
from functools import lru_cache
from itertools import combinations_with_replacement, permutations
import gzip
import json
from math import isqrt
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

DEN = 256
SCALE = 1 << 16

def cost_table():
    divisor = 8 * DEN**6
    def edge(s):
        return 1 + isqrt((SCALE**2 * s**3 - 1) // divisor) if s else 0
    return np.array([edge(s) for s in range(3 * DEN**2+1)], dtype=np.int32)

def reflect(p):
    return p if p[0]<p[-1] else p[::-1]

def chambers(n):
    axes = [p for p in permutations(range(n)) if p[0]<p[-1]]
    seen = set()
    for b,c in combinations_with_replacement(axes, 2):
        if (b,c) in seen:
            continue
        a = tuple(range(n))
        for p,q,r in ((a,b,c),(b,c,a),(c,a,b)):
            for order in (p,p[::-1]):
                ranks = {v:i for i,v in enumerate(order)}
                pair = tuple(sorted(reflect(tuple(ranks[v] for v in side)) for side in (q,r)))
                seen.add(pair)
        yield (a,b,c)

def simplex(p):
    return np.array([[DEN*int(x in p[k:]) for x in range(len(p))]
                     for k in range(1,len(p))], dtype=np.int32)

class Prover:
    def __init__(self,n):
        self.n = n
        self.tours = [(0,)+p for p in permutations(range(1,n)) if p[0]<p[-1]]
        edges = [(i,j) for i in range(n) for j in range(i)]
        self.e1,self.e2 = np.array(edges).T
        lookup = {tuple(sorted((i,j))):k for k,(i,j) in enumerate(edges)}
        self.T = np.array([[lookup[tuple(sorted((t[i-1],t[i])))] for i in range(n)]
                           for t in self.tours])
        self.rounded = cost_table()
        self.stats = Counter()
        self.scale = 4*SCALE

    def costs(self, sides):
        d = [(a[:,self.e1]-a[:,self.e2])**2 for a in sides]
        sq = (d[0][:,None,None]+d[1][None,:,None]+d[2][None,None,:]).reshape(-1,len(self.e1))
        w = self.rounded[sq]
        # Sum each tour, avoiding a large intermediate of shape (rows,tours,n).
        a = w[:,self.T[:,0]].copy()
        for i in range(1,self.n):
            a += w[:,self.T[:,i]]
        return np.ascontiguousarray(a)

    def prove(self,sides,depth=0):
        self.stats['nodes'] += 1
        self.stats['max_depth'] = max(depth,self.stats['max_depth'])
        a = self.costs(sides)
        mx = a.max(axis=0)
        j = int(mx.argmin())
        if mx[j] <= self.scale:
            self.stats['single'] += 1
            return j
        # Cheap equal mixtures of pairs, focusing on tours good near the worst vertices.
        idx = np.argsort(mx)[:min(10,len(mx))]
        for j in idx:
            ok = np.flatnonzero((a[:,idx]+a[:,[j]]).max(axis=0)<=2*self.scale)
            if len(ok):
                self.stats['pair'] += 1
                return ['m',int(j),1,int(idx[ok[0]]),1]
        k = a.shape[1]
        A = np.empty((len(a),k+1)); A[:,:-1]=a/self.scale; A[:,-1]=-1
        res=linprog([0]*k+[1], A_ub=A,b_ub=np.zeros(len(a)),
                    A_eq=[[1]*k+[0]],b_eq=[1],bounds=(0,None),method='highs')
        if not res.success:
            raise RuntimeError(res.message)
        if res.fun<1.0000001:
            for denom in (10,100,1000,10000,1000000):
                weights = np.rint(res.x[:-1]*denom).astype(np.int64)
                if weights.sum() and (a@weights).max()<=self.scale*weights.sum():
                    self.stats['lp'] += 1
                    mix = ['m']
                    for j in np.flatnonzero(weights):
                        mix.extend((int(j),int(weights[j])))
                    return mix
        # Pick a long simplex edge whose ends carry weight in the dual LP.
        probs=-res.ineqlin.marginals.reshape((self.n-1,)*3)
        choices=[]
        for axis,s in enumerate(sides):
            p=probs.sum(axis=tuple(i for i in range(3) if i!=axis))
            for i in range(len(s)):
                for j in range(i):
                    delta=s[i]-s[j]
                    if np.any(delta%2):
                        continue
                    choices.append(((0.0001+p[i])*(0.0001+p[j])*(delta@delta),axis,j,i))
        if not choices or depth>90:
            raise RuntimeError('Precision or depth limit in subdivision')
        _,axis,i,j=max(choices)
        mid=(sides[axis][i]+sides[axis][j])//2
        children=[]
        for end in (i,j):
            sub=sides.copy();sub[axis]=sub[axis].copy();sub[axis][end]=mid
            children.append(self.prove(sub,depth+1))
        return ['s',axis,i,j,*children]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('n',type=int,choices=range(4,8))
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    solver=Prover(args.n)
    with gzip.open(args.output,'wt',encoding='ascii') as out:
        for k,axes in enumerate(chambers(args.n)):
            proof=solver.prove([simplex(x) for x in axes])
            out.write(json.dumps([axes[1],axes[2],proof],separators=(',',':'))+'\n')
            if k%1000==999: print(k+1,dict(solver.stats),flush=True)
    print('chambers',k+1,dict(solver.stats),flush=True)

if __name__=='__main__':
    main()
