"""Replay finite-point certificates and check equality cases. Needs only NumPy and Python 3."""
import gzip
from itertools import combinations, combinations_with_replacement, permutations
import json
from math import isqrt
from pathlib import Path
import sys
import numpy as np

BASE=256
UNIT=65536
HERE=Path(__file__).resolve().parent

def insist(statement):
    if not statement:
        raise ValueError("invalid certificate")

def ub(s):
    if not s:
        return 0
    num=UNIT**2*s**3
    den=8*BASE**6
    root=isqrt(num//den)
    return root+(root*root*den<num)

def ordered_chambers(n):
    orders=list(permutations(range(n)))
    # No quotient is assumed in the proof. Return all pairs for a fixed
    # first coordinate and then compare them with the union of the proven orbits.
    names={p:min(p,p[::-1]) for p in orders}
    canonical=sorted(set(names.values()))
    return names,set(combinations_with_replacement(canonical,2))

def orbit(chamber,names):
    for i,j,k in permutations(range(3)):
        for p in (chamber[i],chamber[i][::-1]):
            rank={pt:v for v,pt in enumerate(p)}
            sides=[names[tuple(rank[e] for e in chamber[axis])] for axis in (j,k)]
            yield tuple(sorted(sides))

class Checker:
    def __init__(self,n):
        self.n=n
        self.tours=[(0,)+p for p in permutations(range(1,n)) if p[0]<p[-1]]
        self.edges=list(combinations(range(n),2))
        self.edge_id={e:i for i,e in enumerate(self.edges)}
        tour_matrix=[]
        for t in self.tours:
            counts=[0]*len(self.edges)
            for x,y in zip(t,t[1:]+t[:1]):
                counts[self.edge_id[tuple(sorted((x,y)))]]+=1
            tour_matrix.append(counts)
        self.tour_matrix=np.array(tour_matrix, dtype=np.int64)
        self.W=np.array([ub(s) for s in range(3*BASE**2+1)],dtype=np.int64)
        self.leaves=self.splits=self.parity_rows=self.other_rows=self.depth=0
    def verify(self,cells,tree,depth=0):
        self.depth=max(self.depth,depth)
        if isinstance(tree,list) and tree[0]=='s':
            _,k,i,j,l,r=tree
            insist(0<=k<3 and 0<=i<j<self.n-1)
            box=cells[k]
            insist(np.all((box[i]+box[j])%2==0))
            middle=(box[i]+box[j])//2
            self.splits+=1
            for which,node in ((i,l),(j,r)):
                part=box.copy();part[which]=middle
                new=list(cells);new[k]=part
                self.verify(new,node,depth+1)
            return
        if isinstance(tree,int):
            ids=[tree];weights=[1]
        else:
            insist(tree[0]=='m' and len(tree)%2==1 and len(tree)>=3)
            ids=tree[1::2];weights=tree[2::2]
        insist(all(0<=i<len(self.tours) for i in ids))
        insist(all(isinstance(w,int) and w>0 for w in weights))
        total=sum(weights)
        insist(total*self.n*int(self.W[-1])<2**63)
        usage=np.array(weights,dtype=np.int64)@self.tour_matrix[ids]
        i,j=zip(*self.edges)
        sq=[(s[:,i]-s[:,j])**2 for s in cells]
        all_sq=sq[0][:,None,None,:]+sq[1][None,:,None,:]+sq[2][None,None,:,:]
        scores=self.W[all_sq]@usage
        limit=4*UNIT*total
        insist(int(scores.max())<=limit)
        for indices in np.argwhere(scores==limit):
            block=tuple(indices)
            points={tuple(int(cells[d][block[d],v]) for d in range(3)) for v in range(self.n)}
            bits = all(x in (0,BASE) for p in points for x in p)
            if len(points)==4 and bits and len({sum(p)//BASE%2 for p in points})==1:
                self.parity_rows+=1
            else:
                costs=self.tour_matrix@self.W[all_sq[block]]
                insist(int(costs.min())<4*UNIT)
                self.other_rows+=1
        self.leaves+=1

def run(n):
    check=Checker(n)
    names,expected=ordered_chambers(n)
    proved=set(); roots=0
    with gzip.open(HERE/f'n{n}.jsonl.gz','rt') as f:
        for line in f:
            p,q,tree=json.loads(line)
            chamber=(tuple(range(n)),tuple(p),tuple(q))
            insist(all(x in names for x in chamber))
            cells=[]
            for order in chamber:
                # Vertices of the normalized order simplex have a single jump.
                rank=np.argsort(order)
                cells.append(np.array([(rank>=cut)*BASE for cut in range(1,n)],dtype=np.int64))
            check.verify(cells,tree)
            proved.update(orbit(chamber,names));roots+=1
    insist(proved==expected)
    print('n',n,'roots',roots,'covered',len(proved),'leaves',check.leaves,'splits',check.splits,
          'depth',check.depth,'tight_parity_rows',check.parity_rows,
          'other_tight_rows_with_strict_tour',check.other_rows,flush=True)

if __name__=='__main__':
    for n in (map(int,sys.argv[1:]) if sys.argv[1:] else (4,5,6)):
        run(n)
