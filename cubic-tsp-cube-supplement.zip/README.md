# MDS 2026 问题 4.1 复算包

完整论证见仓库中的 cubic-tsp-cube.pdf，可编辑原稿为 proof.md。符号 C 表示总成本。当前证明给出 8√2 ≤ C ≤ 1533√6/221。四、五、六点的上确界已证为 8√2。全部程序可在本机离线复算，数学核验不依赖网络或商业求解器。

## 核验三个严格结论

在解压后的本目录运行以下命令。Python 需要 3.10 或更高版本。第一项只用标准库；第二项用 NumPy。第三项需要支持 C++17 和 __builtin_ctz 的编译器。运行检查过的环境为 Python 3.12.14、NumPy 2.3.5、SciPy 1.17.0、GCC 14.2.0。

~~~sh
python3 verify_curve.py
python3 verify_finite.py
g++ -std=c++17 -O3 verify_grid.cpp -o verify_grid
./verify_grid
~~~

- **全体点数。** verify_curve.py 内含两种 Spring 递归块、顶层环及角点时间算法。程序按相对平移合并状态，所有判断用整数或 Fraction。有 429 个展开状态，最大时间起点差为 55。它还重构一条达到根式上界的实际弦。相应运行记录为 curve.log。
- **连续坐标。** n4.jsonl.gz、n5.jsonl.gz、n6.jsonl.gz 是有限证明树。每行给出第二、第三轴的坐标次序及其树，第一轴固定为标签顺序。内节点 ["s",axis,i,j,left,right] 把相应单纯形的第 i、j 个顶点所成的边平分。整数叶表示一条巡回，["m",tour,weight,...] 表示正整数加权的巡回。巡回以 0 为起点，按排列字典序编号，反向重复通过比较首尾邻居去掉。verify_finite.py 独立重建顶点与巡回、覆盖与等号检查，输出见 finite.log。四舍五入或线性规划状态都无法使叶通过，除非最后的整数不等式成立。
- **三阶立方格。** verify_grid.cpp 逐个覆盖 134,217,728 个位掩码，验证严格上界或交错四点等号。每个上界由真实巡回逐边计费获得。运行记录为 grid.log。
- **局部稳定性。** 四个角块内任意点数的定量结论是证明稿第 5 节的解析推论，依赖全体点数上界 K < 17。

如需重新生成有限树，运行下列命令。生成器使用 NumPy、SciPy 的线性规划来选权重。不同版本可能生成不同的有效树，数学核验以 verify_finite.py 为准。原文件在交付包的根目录。

~~~sh
mkdir regenerated
python3 generate_finite.py 4 regenerated/n4.jsonl.gz
python3 generate_finite.py 5 regenerated/n5.jsonl.gz
python3 generate_finite.py 6 regenerated/n6.jsonl.gz
cp verify_finite.py regenerated/
python3 regenerated/verify_finite.py
~~~

## 反例搜索与候选证书

search.cpp 在分母 64 的三维网格上搜索，保存各点数的最高评分候选。以下参数复现 search.jsonl。浮点运算仅用于挑选候选，因此不同平台可能走不同的优化路径。本次在同一云端编译环境重跑，逐字节复现了候选记录。

~~~sh
g++ -std=c++17 -O3 search.cpp -o search
./search 120 420 12 > reproduced.jsonl
python3 held_karp.py search.jsonl
~~~

最后一条命令精确复现 intervals.jsonl。输入为每行一个含 denominator、points 的 JSON 对象，坐标是 0 至 denominator 的整数。对自有候选可运行 python3 held_karp.py candidate.jsonl。若输出 lower² > 128 × denominator²（此处 denominator 为输出的成本公共分母），该点集才构成严格反例。区间跨阈值时可提高 --precision；本包四点交错例的精确等号另有解析证明。

## 文件完整性与原稿

SHA256SUMS 覆盖其余所有交付文件。解压后可运行 sha256sum -c SHA256SUMS。proof.md 已内嵌示意图并保留文献链接。使用 Pandoc 可将其转为含原生 MathML 的 HTML，再以支持 MathML 的 Chromium 打印为 A4 PDF。

~~~sh
pandoc proof.md -f markdown+tex_math_dollars -t html5 --mathml -s \
  --wrap=none -M lang=zh-CN -M pagetitle=MDS2026-4.1 \
  -H print-style.html -o proof.html
~~~

文献层面的核查范围、已有猜想的归属、精确值仍未闭合的原因，见原稿第 6 节。
