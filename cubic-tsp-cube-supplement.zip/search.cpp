// Deterministic grid and hill-climb search. Floating scores guide proposals only.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
using Point=std::array<int,3>;
using Points=std::vector<Point>;
constexpr int side=64;
std::mt19937 rng(20261126);
int pick(int n){return static_cast<int>(rng()%n);}
const Point tetra[4]={{0,0,0},{0,64,64},{64,0,64},{64,64,0}};
std::vector<double> dp,weight;
double tour(const Points& p){
    const int n=p.size(), m=n-1, all=(1<<m)-1;
    double w[14][14]{};
    for(int i=0;i<n;++i)for(int j=0;j<i;++j){
        int d=0;for(int k=0;k<3;++k){int e=p[i][k]-p[j][k];d+=e*e;}
        w[i][j]=w[j][i]=weight[d];
    }
    dp.resize((1<<m)*m);
    for(int mask=1;mask<=all;++mask)for(int todo=mask;todo;todo&=todo-1){
        int j=__builtin_ctz((unsigned)todo), prev=mask^(1<<j);
        double best=prev?std::numeric_limits<double>::infinity():w[0][j+1];
        for(int alt=prev;alt;alt&=alt-1){
            int k=__builtin_ctz((unsigned)alt);
            best=std::min(best,dp[prev*m+k]+w[k+1][j+1]);
        }
        dp[mask*m+j]=best;
    }
    double best=std::numeric_limits<double>::infinity();
    for(int j=0;j<m;++j)best=std::min(best,dp[all*m+j]+w[j+1][0]);
    return best;
}
bool distinct(const Points& p){
    for(size_t i=0;i<p.size();++i)for(size_t j=0;j<i;++j)if(p[i]==p[j])return false;
    return true;
}
Point sample(int mode,int index){
    Point x{};
    if(mode==0)for(int& a:x)a=pick(side+1);
    if(mode==1)for(int& a:x)a=32*pick(3);
    if(mode==2){
        x=tetra[index%4];
        for(int& a:x)if(pick(3)==0){int d=pick(9);a=a?side-d:d;}
    }
    if(mode==3)for(int& a:x){a=pick(2)*side;if(pick(4)==0)a=pick(side+1);}
    if(mode==4){for(int& a:x)a=pick(side+1);x[pick(3)]=pick(2)*side;}
    return x;
}
int main(int argc,char** argv){
    int rounds=argc>1?std::atoi(argv[1]):32, steps=argc>2?std::atoi(argv[2]):250;
    int largest=argc>3?std::atoi(argv[3]):11;
    if(largest<4||largest>13||rounds<1||steps<1)return 2;
    std::cout<<std::setprecision(16);
    for(int d=0;d<=3*side*side;++d)weight.push_back(d*std::sqrt((double)d)/(side*side*side));
    for(int n=4;n<=largest;++n){
        double best=-1;Points champ;long calls=0;
        for(int r=0;r<rounds;++r){
            Points cur;
            for(int i=0;i<n;++i){
                Point pt;do{pt=sample(r%5,i);}while(std::find(cur.begin(),cur.end(),pt)!=cur.end());
                cur.push_back(pt);
            }
            if(r==0&&n==4)cur.assign(tetra,tetra+4);
            double val=tour(cur);++calls;
            for(int h=0;h<=steps;++h){
                if(val>best){best=val;champ=cur;}
                if(h==steps)break;
                Points next=cur;int j=pick(n),k=pick(3),mode=pick(10);
                if(mode<2){ int which=pick(4); int family=pick(5); next[j]=sample(family,which); }
                else if(mode<4)next[j][k]=pick(2)*side;
                else if(mode==4)next[j][k]=pick(side+1);
                else if(mode==5){next[j]=next[(j+1+pick(n-1))%n];next[j][k]=std::clamp(next[j][k]+(pick(2)?1:-1),0,side);}
                else {int delta=1+pick(1<<pick(5));next[j][k]=std::clamp(next[j][k]+(pick(2)?delta:-delta),0,side);}
                if(!distinct(next)||next==cur)continue;
                double newval=tour(next);++calls;
                const double temp=0.003+0.15*(1.0-double(h)/steps);
                if(newval>=val || double(rng())/(double(rng.max())+1)<std::exp((newval-val)/temp)){
                    val=newval;cur=next;
                }
            }
        }
        std::cout<<"{\"n\":"<<n<<",\"evaluations\":"<<calls<<",\"score\":"<<best<<",\"denominator\":"<<side<<",\"points\":[";
        for(int j=0;j<n;++j){if(j)std::cout<<',';auto x=champ[j];std::cout<<'['<<x[0]<<','<<x[1]<<','<<x[2]<<']';}
        std::cout<<"]}"<<std::endl;
    }
}
