// Exhaustive upper certificates for every subset of {0,1/2,1}^3.
// Build: c++ -std=c++17 -O3 verify_grid.cpp -o verify_grid
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
using Mask=std::uint32_t;
using Perm=std::array<int,27>;
using Path=std::vector<int>;
constexpr int U=65536,K=4*U;
std::array<std::array<int,27>,27> cost{};
int index(int x,int y,int z){return x+3*y+9*z;}
int edge(int s){
    std::uint64_t num=std::uint64_t(U)*U*s*s*s, den=8*64;
    int lo=0,hi=4*U;
    while(lo<hi){
        int mid=(lo+hi)/2;
        if(std::uint64_t(mid)*mid*den>=num)hi=mid;
        else lo=mid+1;
    }
    return lo;
}
int snake_cost(Mask mask,const Perm& p){
    int first=-1,last=-1,sum=0;
    for(int x:p)if(mask&(Mask(1)<<x)){
        if(first<0)first=x;
        else sum+=cost[last][x];
        last=x;
    }
    return first<0?0:sum+cost[last][first];
}
int insertion(Mask mask){
    Path p;
    for(int i=0;i<27;++i)if(mask&(Mask(1)<<i))p.push_back(i);
    int n=p.size();
    if(n<2)return 0;
    int best=1000000000;
    for(int i=0;i<n;++i)for(int j=0;j<i;++j){
        Path t={p[i],p[j]};
        Mask rest=mask^(Mask(1)<<p[i])^(Mask(1)<<p[j]);
        while(rest){
            int inc=1000000000,place=-1,v=-1;
            for(auto m=rest;m;m&=m-1){
                int x=__builtin_ctz(m);
                for(int k=0;k<int(t.size());++k){
                    int a=t[k],b=t[(k+1)%t.size()];
                    int delta=cost[a][x]+cost[x][b]-cost[a][b];
                    if(delta<inc){inc=delta;place=k+1;v=x;}
                }
            }
            t.insert(t.begin()+place,v);rest^=Mask(1)<<v;
        }
        int sum=0;for(int k=0;k<n;++k)sum+=cost[t[k]][t[(k+1)%n]];
        best=std::min(best,sum);if(best<K)return best;
    }
    return best;
}
int main(){
    for(int i=0;i<27;++i)for(int j=0;j<27;++j){
        int a=i,b=j,s=0;for(int k=0;k<3;++k){int d=a%3-b%3;s+=d*d;a/=3;b/=3;}
        cost[i][j]=edge(s);
    }
    std::vector<Perm> group,orders;
    std::array<int,3> ax{0,1,2};
    Perm snake{};int k=0;
    for(int z=0;z<3;++z)for(int row=0;row<3;++row)for(int col=0;col<3;++col){
        int y=z%2?2-row:row, x=(3*z+row)%2?2-col:col;
        snake[k++]=index(x,y,z);
    }
    do{for(int signs=0;signs<8;++signs){
        Perm g{},order{};
        for(int i=0;i<27;++i){
            int p[3]={i%3,i/3%3,i/9},v[3];
            for(int d=0;d<3;++d)v[d]=((signs>>d)&1)?2-p[ax[d]]:p[ax[d]];
            g[i]=index(v[0],v[1],v[2]);
        }
        group.push_back(g);
        for(int i=0;i<27;++i)order[i]=g[snake[i]];
        orders.push_back(order);
    }}while(std::next_permutation(ax.begin(),ax.end()));
    std::vector<std::array<std::array<Mask,512>,3>> tab(group.size());
    for(int g=0;g<int(group.size());++g)for(int j=0;j<3;++j)for(Mask m=1;m<512;++m){
        int b=__builtin_ctz(m);
        tab[g][j][m]=tab[g][j][m&(m-1)]|(Mask(1)<<group[g][9*j+b]);
    }
    Mask even=0,odd=0;
    for(int x:{0,2})for(int y:{0,2})for(int z:{0,2}){
        Mask bit=Mask(1)<<index(x,y,z);
        if(((x+y+z)/2)%2)odd|=bit;else even|=bit;
    }
    constexpr Mask limit=Mask(1)<<27;
    std::vector<std::uint64_t> seen(limit/64);
    std::uint64_t reps=0,unique=0,via_insertion=0,tight=0,fail=0;
    for(Mask m=0;m<limit;++m){
        if((seen[m>>6]>>(m%64))&1)continue;
        ++reps;
        for(const auto& t:tab){
            auto v=t[0][m&511]|t[1][(m>>9)&511]|t[2][m>>18];
            auto bit=std::uint64_t(1)<<(v%64);
            if(!(seen[v>>6]&bit)){seen[v>>6]|=bit;++unique;}
        }
        bool parity=m==even||m==odd;
        bool ok=false;
        for(const auto& o:orders){
            int sum=snake_cost(m,o);
            if(sum<K||(sum==K&&parity)){ok=true;break;}
        }
        if(!ok){
            ++via_insertion;
            int sum=insertion(m);
            ok=sum<K||(sum==K&&parity);
        }
        if(parity)++tight;
        if(!ok){++fail;if(fail<=15)std::cerr<<"unresolved mask "<<m<<'\n';}
    }
    std::cout<<"subsets "<<unique<<" orbits "<<reps<<" insertion_calls "<<via_insertion
             <<" parity_orbits "<<tight<<" unresolved "<<fail<<'\n';
    return (unique==limit && tight==1 && fail==0)?0:1;
}
