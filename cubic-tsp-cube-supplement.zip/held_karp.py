"""Outward-rounded Held--Karp recursion for rational point sets. No external packages."""
import argparse
import json
from math import isqrt
from pathlib import Path

def cycle(w):
    n=len(w)
    if n<2:return 0
    dp={}
    for mask in range(1,1<<(n-1)):
        vertices=[j+1 for j in range(n-1) if mask&(1<<j)]
        for j in vertices:
            rest=mask^(1<<(j-1))
            dp[mask,j]=(min(dp[rest,k]+w[k][j] for k in vertices if k!=j)
                        if rest else w[0][j])
    return min(dp[(1<<(n-1))-1,j]+w[j][0] for j in range(1,n))

def certificate(points,den,precision):
    if not (isinstance(den,int) and den>0 and points and
            all(len(p)==3 and all(isinstance(x,int) and 0<=x<=den for x in p) for p in points) and
            len(set(map(tuple,points)))==len(points)):
        raise ValueError("points must be distinct integer triples in [0,den]^3")
    factor=10**precision
    lo=[];hi=[]
    for p in points:
        a=[];b=[]
        for q in points:
            sq=sum((x-y)**2 for x,y in zip(p,q))
            N=sq**3*factor**2
            s=isqrt(N)
            a.append(s);b.append(s+int(s*s<N))
        lo.append(a);hi.append(b)
    common=den**3*factor
    l=cycle(lo);u=cycle(hi)
    assert 0<=u-l<=len(points)
    status=('above' if l*l>128*common**2 else
            'below' if u*u<128*common**2 else 'threshold_in_interval')
    return dict(n=len(points),lower=l,upper=u,denominator=common,
                relation=status)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file',nargs='?',type=Path,default=Path(__file__).with_name('search.jsonl'))
    parser.add_argument('--precision',type=int,default=24)
    args=parser.parse_args()
    if args.precision<0:raise ValueError('negative precision')
    for line in args.file.read_text().splitlines():
        r=json.loads(line)
        print(json.dumps(certificate(r['points'],r['denominator'],args.precision),separators=(',',':')))

if __name__=='__main__':main()
