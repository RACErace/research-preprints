# Publication replay

A clean extraction was checked, then the exact curve verifier, all three finite-point certificates, the full 27-site grid certificate, and the integer Held–Karp bounds were replayed independently of the search. Logs matched. In particular, the 6-point proof covers 64,980 normalised chamber pairs using 11,043 representative roots and 25,731 leaves, and the grid proof has no unresolved mask among 134,217,728 subsets.

The continuous cover checks products of order simplices, using convex combinations of actual tour costs, not convexity of the minimum tour cost. The integer rounding is upward; a leaf bound is conclusive. Since all normalised configurations have fixed minimum coordinates, any two different configurations differ on at least one tour-edge displacement. This justifies strict convexity in the equality argument. The verifier bounds the largest possible integer weighted sum before its NumPy matrix products.

The curve is periodic: the state roots cover the seam as well as disjoint children inside the two prototypes. Any positive-time counterexample surviving recursive refinement would have a normalised time lag exceeding the maximum of the unresolved states, so the finite state revisit is sound. The corner formula uses nested time intervals of a cube, not a choice of one among multiple preimages of a boundary point. The Spring paper proposes the exact dilation radical for its open curves; the closed-ring construction and the transfer to TSP are separate. This does not claim that the previous numerical Spring dilation estimate was this work's result.

No strict counterexample and no general proof of the conjectured value result from the certificates.
