"""Typeset proof.md using local Pandoc, MathML, and Chromium.

The Chromium executable can be selected with --chromium.
"""
import argparse
import html
from pathlib import Path
import re
import shutil
import subprocess

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent

STYLE = """
@page {
  size: A4;
  margin: 16mm 17mm 16mm;
  @bottom-left { content: "MDS 2026   §4.1"; font: 8pt sans-serif; color: #52656d; }
  @bottom-right { content: counter(page); font: 8pt sans-serif; color: #52656d; }
}
* { box-sizing: border-box; }
html { color: #1d2e35; }
body { margin: 0; width: 176mm; font: 10pt/1.52 "Noto Serif CJK SC", serif; }
h1, h2, h3, th { font-family: "Noto Sans CJK SC", sans-serif; }
h1 { font-size: 19pt; line-height: 1.4; color: #123c50; margin: 0 0 5mm; font-weight: 700; }
h2 { font-size: 14pt; line-height: 1.45; color: #174c60; margin: 5mm 0 2mm; }
h3 { font-size: 11pt; line-height: 1.5; color: #255465; margin: 4mm 0 2mm; }
h1, h2, h3 { break-after: avoid; }
p { margin: 1.6mm 0; orphans: 2; widows: 2; }
strong { font-weight: 700; }
math { font-family: "Latin Modern Math", "DejaVu Math TeX Gyre", math; color: #172a32; }
.equation { display: flex; align-items: center; justify-content: center; position: relative;
  min-height: 7mm; margin: 2.2mm 0; padding: 0 8mm; break-inside: avoid; font-size: 11pt; }
.equation .formula { display: inline-block; width: max-content; flex: none; }
.eqtag { position: absolute; right: 0; font: 9pt Georgia, serif; color: #45565d; }
table { width: 100%; border-collapse: collapse; font-size: 9pt; line-height: 1.52; margin: 3mm 0; }
th { text-align: left; color: #164555; border-top: 1.5px solid #5c8290; background: #eef4f4; }
td, th { padding: 1.4mm 2mm; border-bottom: 1px solid #cbd8db; }
td:first-child, th:first-child { width: 40%; }
tr { break-inside: avoid; }
ol, ul { padding-left: 5.2mm; margin: 2mm 0; }
li { padding-left: 0.6mm; margin: 1.2mm 0; }
a { text-decoration: none; color: #075b72; }
figure { margin: 3mm auto; text-align: center; break-inside: avoid; }
figure img { width: 132mm; max-height: 56mm; }
code { font: 8.7pt "DejaVu Sans Mono", monospace; }
figcaption { font: 8.6pt/1.45 "Noto Sans CJK SC", sans-serif; color: #485d64; }
"""

def make_document():
    result = subprocess.run(
        ["pandoc", str(ROOT / "proof.md"), "-t", "html5", "--mathml"],
        text=True, capture_output=True, check=True,
    )
    if result.stderr.strip():
        raise RuntimeError(result.stderr)
    content = result.stdout
    def display(match):
        math = match.group(1)
        tag = re.search(r"\\tag\{([\w]+)\}", math)
        label = '<span class="eqtag">(' + html.escape(tag.group(1)) + ')</span>' if tag else ""
        return '<div class="equation"><span class="formula">' + math + "</span>" + label + "</div>"

    content = re.sub(r'<p>(<math display="block".*?</math>)</p>', display, content, flags=re.S)
    return ('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
            '<title>三维立方巡回的加权直径球与十一点定理</title><style>'
            + STYLE + "</style>" + (ROOT / "print-style.html").read_text() + "</head><body>" + content + "</body></html>")


def render(chromium, output):
    with sync_playwright() as pw:
        executable = chromium or shutil.which("chromium-headless-shell") or shutil.which("chromium")
        browser = pw.chromium.launch(
            executable_path=executable, headless=True,
            args=["--disable-background-networking", "--disable-dev-shm-usage", "--no-sandbox"],
        )
        context = browser.new_context(offline=True)
        page = context.new_page()
        page.set_content(make_document(), wait_until="load")
        page.evaluate("document.fonts.ready")
        page.emulate_media(media="print")
        page.evaluate("""() => {
          for (const row of document.querySelectorAll('.equation')) {
            const formula = row.querySelector('.formula');
            const available = row.clientWidth - 63;
            const ratio = available / formula.getBoundingClientRect().width;
            if (ratio < 1) formula.style.fontSize = (11 * ratio) + 'pt';
          }
        }""")
        page.pdf(path=str(output), print_background=True, prefer_css_page_size=True)
        browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chromium")
    parser.add_argument("--output", type=Path, default=ROOT / "cubic-tsp-cube-eleven-points.pdf")
    args = parser.parse_args()
    render(args.chromium, args.output)
