"""Stream and audit the continuous ten-point certificate. No third-party Python packages."""
import argparse
import concurrent.futures
import gzip
import hashlib
import json
import lzma
import shutil
import zipfile
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
MOD = 64


def audit_part(part, work, data, forest, archive, regenerate, export):
    root = work / "roots.txt"
    reference = data["parts"][part]
    name = f"{part}.gz"
    known = forest / name if forest else HERE / "explicit" / name
    gen = None
    decoded = None
    if archive and not regenerate:
        mode = "archived"
        decoded = work / f"part-{part}.bin"
        with zipfile.ZipFile(archive) as z:
            with z.open(f"part{part:02d}.bin.xz") as reserved:
                with lzma.LZMAFile(reserved) as inp, decoded.open("wb") as out:
                    shutil.copyfileobj(inp,out)
        with decoded.open("rb") as code:
            gen = subprocess.Popen([work/"forest_codec", "unpack"], stdin=code, stdout=subprocess.PIPE)
        raw = gen.stdout
    elif known.is_file() and not regenerate:
        mode = "explicit"
        raw = gzip.open(known, "rb")
    else:
        if forest and not regenerate:
            raise FileNotFoundError(known)
        mode = "regenerated"
        gen = subprocess.Popen([work/"generate_merge", work/"toll.txt", root,
                                str(part), str(MOD), "0", "400000"],
                               stdout=subprocess.PIPE)
        raw = gen.stdout
    checker = subprocess.Popen([work/"check_merge", root, str(part), str(MOD)],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    dst = export / name if export else None
    dst_tmp = None
    if dst and dst.exists():
        raise FileExistsError(f"export destination already exists: {dst}")
    if dst:
        dst_tmp = tempfile.NamedTemporaryFile(prefix=f".{part}-", dir=export, delete=False)
    encoded = gzip.GzipFile(filename="", mode="wb", fileobj=dst_tmp, compresslevel=1, mtime=0) if dst else None
    checksum = hashlib.sha256()
    length = 0
    try:
        with raw, checker.stdin:
            while chunk := raw.read(256*1024):
                checksum.update(chunk)
                length += len(chunk)
                checker.stdin.write(chunk)
                if encoded:
                    encoded.write(chunk)
        report = checker.stdout.read().decode().strip()
        if checker.wait() != 0:
            raise ValueError(f"independent checker rejected shard {part}")
        if gen and gen.wait() != 0:
            raise ValueError(f"generator or lossless decoder failed for shard {part}")
    finally:
        if encoded:
            encoded.close()
            dst_tmp.close()
        if gen and gen.poll() is None:
            gen.kill()
            gen.wait()
        if checker.poll() is None:
            checker.kill()
            checker.wait()
    if report != reference["audit"] or length != reference["bytes"] or checksum.hexdigest() != reference["sha256"]:
        raise ValueError(f"recorded hash, length, or statistics differ for {part}")
    if decoded:
        decoded.unlink()
    if dst:
        os.link(dst_tmp.name, dst)
        os.unlink(dst_tmp.name)
    print(f"{mode} {report}", flush=True)
    return reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--forest-dir", type=Path, help="use a directory of explicit numbered .gz streams")
    parser.add_argument("--archive", type=Path, help="check the delivered full explicit ZIP, without witness search")
    parser.add_argument("--shard", type=int, help="verify a single residue from 0 to 63")
    parser.add_argument("--export-forest", type=Path, help="save accepted explicit .gz streams to a new directory")
    parser.add_argument("--regenerate", action="store_true", help="generate even when a stream is provided")
    parser.add_argument("--analytic", action="store_true", help="run only constants, packing and independent root coverage")
    args = parser.parse_args()
    if args.jobs < 1 or (args.shard is not None and args.shard not in range(MOD)):
        parser.error("jobs must be positive; shard must be between 0 and 63")
    if args.archive and (args.regenerate or args.forest_dir):
        parser.error("use --archive, --forest-dir or --regenerate separately")
    if args.archive:
        with zipfile.ZipFile(args.archive) as z:
            if sorted(z.namelist()) != [f"part{i:02d}.bin.xz" for i in range(MOD)]:
                raise ValueError("explicit archive must contain all 64 distinct sections")
    if args.export_forest:
        args.export_forest.mkdir(parents=True, exist_ok=False)
    if not __debug__:
        parser.error("run Python without -O so all rational checks are active")
    data = json.loads((HERE/"reference.json").read_text())
    if len(data["parts"]) != MOD:
        raise ValueError("incomplete manifest")
    with tempfile.TemporaryDirectory(prefix="cube-tour-") as tmp:
        w = Path(tmp)
        subprocess.run([sys.executable, HERE/"constants.py"], check=True)
        compiler = os.environ.get("CXX", "g++")
        programs = ["generate_roots", "audit_roots", "packing"]
        if not args.analytic:
            programs.append("check_merge")
            programs.append("forest_codec" if args.archive else "generate_merge")
        for p in programs:
            subprocess.run([compiler, "-std=c++17", "-O3", HERE/(p+".cpp"), "-o", w/p], check=True)
        root = w/"roots.txt"
        with root.open("wb") as out:
            subprocess.run([w/"generate_roots"], stdout=out, check=True)
        if hashlib.sha256(root.read_bytes()).hexdigest() != data["roots_sha256"]:
            raise ValueError("regenerated root table differs")
        with root.open("rb") as inp:
            subprocess.run([w/"audit_roots"], stdin=inp, check=True)
        pack = subprocess.check_output([w/"packing"]).decode().strip()
        if pack != data["packing"]:
            raise ValueError("packing failed to match the reference")
        print(pack, flush=True)
        if args.analytic:
            return
        subprocess.run([sys.executable, HERE/"tolls.py", w/"toll.txt"], check=True)
        parts = [args.shard] if args.shard is not None else range(MOD)
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as ex:
            jobs = [ex.submit(audit_part,i,w,data,args.forest_dir,args.archive,args.regenerate,args.export_forest) for i in parts]
            rows = [j.result() for j in jobs]
        print("accepted",len(rows),"shard(s);",sum(x["nodes"] for x in rows),
              "nodes;",sum(x["leaves"] for x in rows),"leaves")
        if len(rows)==MOD:
            if sum(r["roots"] for r in rows)!=238996 or sum(r["nodes"] for r in rows)!=data["totals"]["nodes"]:
                raise ValueError("incorrect full-forest totals")

if __name__ == "__main__":
    main()
