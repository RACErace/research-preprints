// Packing feasibility audit. All coordinates scaled by D. Repeated bisection and necessary pair-distance propagation.
#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
constexpr int N=11,D=512,TH=3*D/4;
struct Interval{int lo,hi;};using Box=array<Interval,3>;using Boxes=array<Box,N>;
uint64_t nodes=0,leaves=0,initial=0;int deep=0,root_floor[3*D*D+1];
bool propagate(Boxes& b){
    for(int pass=0;pass<60;++pass){
        bool changed=false;
        for(int i=0;i<N;++i)for(int j=0;j<i;++j){
            int ss=0,axis[3];
            for(int k=0;k<3;++k){
                int v=max(b[i][k].hi-b[j][k].lo,b[j][k].hi-b[i][k].lo);
                axis[k]=v*v;ss+=v*v;
            }
            if(ss<=TH*TH)return false;
            for(int k=0;k<3;++k){
                int need=TH*TH-ss+axis[k];if(need<0)continue;
                int g=root_floor[need];auto& x=b[i][k];auto& y=b[j][k];
                bool plus=x.hi-y.lo>g,minus=y.hi-x.lo>g;
                if(!plus&&!minus)return false;
                if(plus&&minus)continue;
                auto& small=plus?y:x;auto& large=plus?x:y;
                int l=small.lo+g,h=large.hi-g;
                if(l>large.lo){large.lo=l;changed=true;}
                if(h<small.hi){small.hi=h;changed=true;}
                if(large.lo>large.hi || small.lo>small.hi)return false;
            }
        }
        if(!changed)break;
    }
    return true;
}
bool solve(Boxes b,int dep){
    if(++nodes>8000000 || dep>145)return false;
    deep=max(deep,dep);
    if(!propagate(b)){++leaves;return true;}
    int a=-1,k=-1,best=-1;
    for(int i=0;i<N;++i)for(int j=0;j<3;++j){int w=b[i][j].hi-b[i][j].lo;if(w>best){best=w;a=i;k=j;}}
    if(best<=1)return false;
    int h=b[a][k].hi,m=(b[a][k].lo+h)/2;
    b[a][k].hi=m;if(!solve(b,dep+1))return false;
    b[a][k].lo=m;b[a][k].hi=h;return solve(b,dep+1);
}
bool packing_roots(Boxes b,int oct,int nr){
    if(oct==8){if(nr!=N)return true;++initial;return solve(b,0);}
    if(nr+2*(8-oct)<N)return true;
    Box cell;
    for(int k=0;k<3;++k){int a=((oct>>k)&1)*D/2;cell[k]={a,a+D/2};}
    if(!packing_roots(b,oct+1,nr))return false;
    if(nr>=N)return true;
    b[nr]=cell;
    if(!packing_roots(b,oct+1,nr+1))return false;
    if(nr+2>N)return true;
    // For a pair >3/4 apart in a halfcube, all projection differences are >1/4.
    for(int dir=0;dir<4;++dir){
        int mask=dir*2;Box x,y;
        for(int k=0;k<3;++k){
            int mid=(cell[k].lo+cell[k].hi)/2;
            Interval a={cell[k].lo,mid},c={mid,cell[k].hi};
            if(mask>>k&1)swap(a,c);
            x[k]=a;y[k]=c;
        }
        b[nr]=x;b[nr+1]=y;
        if(!packing_roots(b,oct+1,nr+2))return false;
    }
    return true;
}
int main(){
    for(int i=0,z=0;i<=3*D*D;++i){if((z+1)*(z+1)<=i)++z;root_floor[i]=z;}
    bool ok=packing_roots({},0,0);
    cout<<"covered "<<ok<<" roots "<<initial<<" nodes "<<nodes<<" leaves "<<leaves<<" depth "<<deep<<"\n";return !ok;
}
