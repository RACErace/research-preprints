"""Certified upper toll for splitting a nearest pair. Writes one integer per input."""
import sys
from math import isqrt

D=128
P=2**20
U=2**16
def upper_root(a,b):
    low=isqrt(a//b)
    return low+int(low*low*b<a)

def generate(path):
    denom=12*D**2
    root8=isqrt(8*P**2)
    with open(path,'w',encoding='ascii') as out:
        for z in range(27*D**2//4+1):
            dl=isqrt((P**2*z)//denom)
            du=upper_root(P**2*z,denom)
            # V^2=3-sqrt(z/denom)+z/(4*denom); use the lower endpoint dl/P.
            v=upper_root(P*(12*denom*P-4*denom*dl+P*z),4*denom)
            a=U*z*(2*du+3*v);b=2*denom*root8
            print((a+b-1)//b,file=out)

if __name__=='__main__':generate(sys.argv[1])
