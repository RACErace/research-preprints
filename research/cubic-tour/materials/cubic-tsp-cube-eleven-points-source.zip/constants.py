"""Exact rational checks for the inequalities used in the analytic proofs."""
from fractions import Fraction as Q
from math import isqrt

P = 10**15

def sqrt_bounds(x):
    x = Q(x)
    n = isqrt((P*P*x.numerator)//x.denominator)
    return Q(n,P), Q(n+1,P)

def arctan_bounds(q):
    s = sum((-1)**j*Q(1, (2*j+1)*q**(2*j+1)) for j in range(32))
    return s, s + Q(1,65*q**65)

def pi_bounds():
    a,A = arctan_bounds(5)
    b,B = arctan_bounds(239)
    return 16*a-4*B, 16*A-4*b

def main():
    pi,Pi = pi_bounds()
    l2,u2 = sqrt_bounds(2)
    l3,u3 = sqrt_bounds(3)
    H = 8*l2
    t = Q(1,24)
    B = 30/pi*(1+4*t/3)**3
    assert B < Q(11231,1000) and H-B > Q(828,10000)
    e = 24*(1/t+Q(4,3))**2
    assert e/Pi > 4902 and e/pi < 4903
    assert 30/pi < Q(95493,10000) and 30/Pi > Q(95492,10000)
    assert Q(104,225) < Q(7,10)**2
    assert (1-Q(2,26))**2 > Q(17,20)  # cap packing < 26 directions
    assert (Q(67,8)-1)**3 > 8*50
    assert Q(67,2*804) == t
    R = Q(1,8)
    _,square_bound = sqrt_bounds(2+R*R)
    A = 4*l2*(1-R)/3 - R*square_bound/2
    M = 21*u3
    assert A-M*R**2 > Q(17,18)
    _,ratio = sqrt_bounds(Q(8,3))
    assert ratio*R + 3*u3/2 < Q(17,6)
    assert 3*square_bound**3+30*u3*R**3+Q(68,9)*R**2 < H
    assert (1+Q(4,3)*t)**3*30/Pi > Q(11230,1000)
    # An enclosing Euclidean ball of radius a costs at most 80 a^3.
    # Randomly reopening ten ball clusters adds another 8 S.
    alpha=Q(3,10)
    assert 88*alpha**3 > 1
    assert Q(9,4)**3 > 8*u2
    g=Q(3,4)+Q(3,2)*sqrt_bounds(3-Q(3,4)+Q(9,64))[0]
    assert 88*alpha**3*Q(3,4)+6*Q(9,4)*alpha**2 < g
    print("30/pi in (9.5492, 9.5493); B(1/24) in (11.230, 11.231)")
    print("slack > 0.0828; exceptional edges <= 4902; terminals <= 9804")
    print("midpoint core <= 50 labels; longest edge <= 67 times fill distance")
    print("four-cluster slack coefficient > 17/18; adaptive ten-ball expansion verified")
if __name__ == "__main__": main()
