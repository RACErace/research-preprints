// Standalone checker for the continuous ten-point forest. Read the decompressed certificate on stdin.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Perm=array<int,64>;
using XYZ=array<int,3>;
using Cube=array<pair<int,int>,3>;
using Wide=unsigned __int128;
constexpr int D=128, UNIT=65536;
int LIMIT;bool rigidity;vector<int> root_codes;
int n=10;
vector<vector<int>> tours;
vector<int> weight,floor_weight;
vector<Perm> sym;
set<uint64_t> proven_orbits;
uint64_t total_signatures=0,nodes=0,leaves=0,parity_leaves=0;
int max_depth=0;
void require(bool p){if(!p)throw runtime_error("certificate check failed");}
int pinmask(int code){
    int result=0;
    for(int k=0;k<3;++k){
        int d=(code>>(2*k))%4;
        if(d==0||d==3)result|=1<<(2*k+(d==3));
    }
    return result;
}
uint64_t expected_signatures(){
    // Multisets of n boxes. Each of six faces has precisely one marked extremum.
    vector<array<uint64_t,64>> counts(n+1);counts[0][0]=1;
    for(int code=0;code<64;++code){
        int f=pinmask(code);auto next=counts;
        for(int used=0;used<n;++used)for(int taken=0;taken<64;++taken){
            if(taken&f)continue;
            for(int copies=1;used+copies<=n;++copies){
                next[used+copies][taken|f]+=counts[used][taken];
                if(f)break;
            }
        }
        counts.swap(next);
    }
    return counts[n][63];
}
void make_group(){
    Perm id{},swap01{},swap12{},flip{};
    for(int code=0;code<64;++code){
        int x=code%4,y=(code/4)%4,z=code/16;
        id[code]=code;swap01[code]=y+4*x+16*z;
        swap12[code]=x+4*z+16*y;flip[code]=3-x+4*y+16*z;
    }
    set<Perm> found{id};sym={id};
    for(size_t i=0;i<sym.size();++i){
        for(const auto& f:{swap01,swap12,flip}){
            Perm h{};for(int c=0;c<64;++c)h[c]=f[sym[i][c]];
            if(found.insert(h).second)sym.push_back(h);
        }
    }
    require(sym.size()==48);
}
void register_root(const vector<int>& codes){
    int pins=0;
    for(int code:codes){
        require(0<=code&&code<64);
        int f=pinmask(code);require((pins&f)==0);pins|=f;
    }
    require(pins==63);
    set<uint64_t> ids;
    for(const auto& g:sym){
        auto r=codes;for(int& x:r)x=g[x];sort(r.begin(),r.end());
        uint64_t id=0;for(int x:r)id=(id<<6)|x;
        ids.insert(id);
    }
    require(proven_orbits.insert(*ids.begin()).second);
    total_signatures+=ids.size();
}

int main(){
    make_group();string line;int count=0;
    while(getline(cin,line)){
        istringstream stream(line);vector<int> row(10);
        for(int& v:row)require(bool(stream>>v));
        string extra;require(!(stream>>extra));register_root(row);++count;
    }
    require(count==238996&&proven_orbits.size()==238996);
    require(expected_signatures()==11295372&&total_signatures==11295372);
    cout<<"normalized ten signatures "<<total_signatures<<" disjoint cube orbits "<<count<<'\n';
}
