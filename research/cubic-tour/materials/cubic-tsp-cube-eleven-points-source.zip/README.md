# 三维立方巡回的加权直径球与十一点定理

工作论文，未经同行评审。AI 辅助研究。目标为 [MDS 2026 问题 4.1](https://arxiv.org/html/2611.03403v1#S4)，这里证明十一点情形及两个任意点数的部分结果，不声称解决一般情形。

## 复现

要求 Python 3.8+ 标准库与支持 `unsigned __int128` 的 C++17 编译器（默认 g++）。运行：

- `python3 replay.py --analytic`：验证有理常数、11 点距离装填和全部 238,996 个十点根的覆盖。
- `python3 replay.py --regenerate --shard 0`：重新生成并独立验算一个分片，与清单比对。
- `python3 replay.py --regenerate --jobs 8`：全部 64 片从头生成并逐叶独立验算。这比直接读取证书慢。分片编号为 0 到 63，可以独立并行，也可降低 `--jobs`。不需要旧卷的文件或网络。
- 添加 `--export-forest OUTPUT` 会将经核验的解码流保存为 64 个 gzip 文件；随后可用 `--forest-dir OUTPUT` 跳过生成。
- `--archive PATH` 接受原证书的无损压缩 ZIP（各片名为 `part00.bin.xz` 等，内为 C++ `forest_codec pack` 编码流）。这个大文件未打包在源码内，源码可重建全部见证。清单内的哈希针对展开后的文本，不受压缩实现影响。
- `python3 render_pdf.py --chromium /path/to/chromium-headless-shell`：使用 Pandoc、Python Playwright、Chromium、Noto CJK 与数学字体重建 PDF。

盒端点有理，点在盒内可任取实坐标。分盒证书须全量通过；未决节点、截断分片、错误圈编号或清单不符都不能视为定理。
