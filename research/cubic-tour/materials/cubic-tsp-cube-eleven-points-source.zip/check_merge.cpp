// Independent streamed verifier for the ten-variable nearest-pair extension certificate.
#include <fstream>
// Standalone checker for the continuous ten-point forest. Read the decompressed certificate on stdin.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Perm=array<int,64>;
using XYZ=array<int,3>;
using Cube=array<pair<int,int>,3>;
using Wide=unsigned __int128;
constexpr int D=128, UNIT=65536;
int LIMIT;vector<int> root_codes;
int n=10;
vector<vector<int>> tours;
vector<int> weight,floor_weight;
vector<Perm> sym;
set<uint64_t> proven_orbits;
uint64_t nodes=0,leaves=0,parity_leaves=0;
int max_depth=0;
void require(bool p){if(!p)throw runtime_error("certificate check failed");}
void make_costs(){
    Wide den=8;for(int k=0;k<6;k++)den*=D;
    for(int s=0;s<=3*D*D;++s){
        Wide num=Wide(UNIT)*UNIT*s*s*s;
        int low=0,high=4*UNIT;
        while(low<high){
            int m=(low+high)/2;
            if(Wide(m)*m*den>=num)high=m;else low=m+1;
        }
        require(Wide(low)*low*den>=num);
        require(low==0||Wide(low-1)*(low-1)*den<num);
        weight.push_back(low);floor_weight.push_back(low-(Wide(low)*low*den>num));
    }
    vector<int> t(n);
    for(int j=0;j<n;++j)t[j]=j;
    do{if(t[1]<t.back())tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));
}
vector<Cube> decode(const vector<int>& codes){
    vector<Cube> b(n);
    for(int i=0;i<n;++i)for(int a=0;a<3;++a){
        int s=(codes[i]>>(2*a))&3;
        if(s==0)b[i][a]={0,0};
        if(s==1)b[i][a]={0,D/2};
        if(s==2)b[i][a]={D/2,D};
        if(s==3)b[i][a]={D,D};
    }
    return b;
}
struct Section{array<XYZ,8> p;int size=0;};
Section vertices(const Cube& b){
    Section v{};
    for(int mask=0;mask<8;++mask){
        XYZ pt;bool use=true;
        for(int i=0;i<3;++i){
            auto [x,y]=b[i];bool upper=mask&(1<<i);
            if(x==y&&upper)use=false;
            pt[i]=upper?y:x;
        }
        if(use)v.p[v.size++]=pt;
    }
    return v;
}
int sqdistance(const XYZ& x,const XYZ& y){
    int q=0;for(int a=0;a<3;++a){int d=x[a]-y[a];q+=d*d;}return q;
}
bool strict_cycle(const vector<Cube>& b,const vector<int>& t){
    array<Section,10> v{};
    for(int i=0;i<n;++i)v[i]=vertices(b[t[i]]);
    int first=0;for(int i=1;i<n;++i)if(v[i].size<v[first].size)first=i;
    rotate(v.begin(),v.begin()+first,v.begin()+n);
    int w[10][8][8];
    for(int i=0;i<n;++i){int j=(i+1)%n;for(int a=0;a<v[i].size;++a)
        for(int k=0;k<v[j].size;++k)w[i][a][k]=weight[sqdistance(v[i].p[a],v[j].p[k])];}
    // For each fixed corner of the first cube, maximize over all other corners.
    for(int base=0;base<v[0].size;++base){
        int dp[8],next[8];
        for(int i=0;i<v[1].size;++i)dp[i]=w[0][base][i];
        for(int j=1;j+1<n;++j){
            for(int k=0;k<v[j+1].size;++k){
                next[k]=0;
                for(int i=0;i<v[j].size;++i)next[k]=max(next[k],dp[i]+w[j][i][k]);
            }
            copy(next,next+v[j+1].size,dp);
        }
        for(int k=0;k<v[n-1].size;++k)if(dp[k]+w[n-1][k][base]>=LIMIT)return false;
    }
    return true;
}
bool apply_label_order(vector<Cube>& b){
    // Labels in identical root boxes can initially be sorted on one common free axis.
    for(int i=0;i<n;++i){
        int k=0;for(;k<3;++k){int bit=root_codes[i]>>(2*k)&3;if(bit==1||bit==2)break;}
        if(k==3)continue;
        int lo=b[i][k].first,hi=b[i][k].second;
        for(int j=0;j<n;++j)if(root_codes[j]==root_codes[i]){
            if(j<i)lo=max(lo,b[j][k].first);
            if(j>i)hi=min(hi,b[j][k].second);
        }
        b[i][k]={lo,hi};
        if(lo>hi)return false;
    }
    return true;
}
int dist_sq(const Cube& a,const Cube& b,bool upper){
    int m=0;
    for(int j=0;j<3;++j){
        auto [a0,a1]=a[j];auto [b0,b1]=b[j];
        int g=upper?max(abs(a1-b0),abs(b1-a0)):max({0,b0-a1,a0-b1});
        m+=g*g;
    }return m;
}

constexpr int P=1<<22;
int surcharge[27*D*D/4+1];
int root_floor(Wide a,Wide b){
    uint64_t l=0,h=4ull*P;
    while(l+1<h){uint64_t x=(l+h)/2;if(Wide(x)*x*b<=a)l=x;else h=x;}
    require(Wide(l)*l*b<=a&&Wide(l+1)*(l+1)*b>a);return int(l);
}
int root_ceil(Wide a,Wide b){int s=root_floor(a,b);return s+int(Wide(s)*s*b<a);}
void make_extra(){
    const uint64_t q=12ull*D*D;
    int sqrt8=root_floor(Wide(8)*P*P,1);
    for(unsigned m=0;m<sizeof(surcharge)/sizeof(*surcharge);++m){
        int l=root_floor(Wide(P)*P*m,q),h=root_ceil(Wide(P)*P*m,q);
        Wide B=Wide(4)*q*P;
        Wide A=3*B-Wide(4)*q*l+Wide(m)*P;
        int v=root_ceil(A*P*P,B);
        Wide top=Wide(m)*UNIT*(2*h+3*v),bot=Wide(2)*q*sqrt8;
        surcharge[m]=int((top+bot-1)/bot);
    }
}
int toll_index(const vector<Cube>& b){
    int best=0,upper[10][10]{};
    for(int i=0;i<n;++i)for(int j=0;j<i;++j)upper[i][j]=dist_sq(b[i],b[j],true);
    for(int m=0;m<n;++m){
        int cap=27*D*D/4;
        for(int i=0;i<n;++i)for(int j=0;j<i;++j){
            const int coeff=(m==i||m==j)?16:12;
            cap=min(cap,coeff*upper[i][j]);
        }
        best=max(best,cap);
    }
    return best;
}
bool alternating(const vector<Cube>& b){
    int class0=-1;
    for(const auto& cell:b){
        int parity=0;
        for(auto [l,h]:cell){
            if(h<=D/8)continue;
            if(l<D-D/8)return false;
            parity^=1;
        }
        if(class0>=0 && class0!=parity)return false;
        class0=parity;
    }
    return true;
}
void audit(istringstream& row,vector<Cube> b,int depth){
    require(depth<=180);++nodes;max_depth=max(max_depth,depth);
    int code;require(bool(row>>code));
    bool valid=apply_label_order(b);
    if(code==200021){require(!valid);++leaves;return;}
    require(valid);
    if(code<0){
        require(code>=-30);
        int i=(-code-1)/3,k=(-code-1)%3;
        auto [l,h]=b[i][k];require(h-l>=2);
        b[i][k].second=(l+h)/2;audit(row,b,depth+1);
        b[i][k]={(l+h)/2,h};audit(row,b,depth+1);
    }else{
        ++leaves;
        if(code==0){require(alternating(b));++parity_leaves;}
        else{
            require(code>=1&&code<=int(tours.size()));
            LIMIT=4*UNIT-surcharge[toll_index(b)];
            require(strict_cycle(b,tours[code-1]));
        }
    }
}
int main(int argc,char** argv){
    if(argc!=4){cerr<<"usage: check roots.txt shard modulus\n";return 2;}
    unsigned part=stoul(argv[2]),mod=stoul(argv[3]);require(part<mod);
    ifstream expected(argv[1]);require(bool(expected));make_costs();make_extra();
    string line,rootline;unsigned count=0,index=0;
    while(getline(expected,rootline)){
        if(index++%mod!=part)continue;
        require(bool(getline(cin,line)));istringstream row(line),root(rootline);
        root_codes.resize(10);
        for(int& c:root_codes){int want;require(bool(row>>c)&&bool(root>>want)&&want==c);}
        audit(row,decode(root_codes),0);
        string token;require(!(row>>token)&&!(root>>token));++count;
    }
    require(!getline(cin,line)&&index==238996&&nodes==2*leaves-count);
    cout<<part<<" roots "<<count<<" nodes "<<nodes<<" leaves "<<leaves<<" parity "<<parity_leaves<<" depth "<<max_depth<<'\n';
}
