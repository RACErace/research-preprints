// Lossless codec for the explicit forest. This program only translates symbols.
// The independent geometric checker consumes the restored ASCII rows.
#include <algorithm>
#include <array>
#include <charconv>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;
void ensure(bool b){if(!b)throw runtime_error("invalid forest coding");}
struct History {
    array<int,64> tour{};
    int used=0;
    int position(int value) const {
        return int(find(tour.begin(),tour.begin()+used,value)-tour.begin());
    }
    void remember(int pos,int value){
        int last=min(pos,63);
        for(int i=last;i>0;--i)tour[i]=tour[i-1];
        tour[0]=value;
        if(pos==used&&used<64)++used;
    }
};
void write_byte(int x){cout.put(static_cast<char>(x));}
int read_byte(){int v=cin.get();ensure(v!=EOF);return v;}
int number(const char*& p,const char* last){
    while(p!=last&&*p==' ')++p;
    int n=0;auto v=from_chars(p,last,n);
    ensure(v.ec==errc()&&v.ptr!=p);p=v.ptr;return n;
}
void encode(){
    cout.write("M41B\1",5);
    string s;
    while(getline(cin,s)){
        const char *p=s.data(),*end=p+s.size();
        for(int i=0;i<10;++i){int c=number(p,end);ensure(c>=0&&c<64);write_byte(c);}
        History history;int pending=1;
        while(pending>0){
            int t=number(p,end);
            if(t<0){ensure(t>=-30);write_byte(-1-t);++pending;continue;}
            --pending;
            if(t==0){write_byte(30);continue;}
            if(t==200021){write_byte(31);continue;}
            ensure(t>=1&&t<=181440);
            int pos=history.position(t);
            if(pos<history.used){write_byte(32+pos);}
            else{
                write_byte(96);write_byte(t&255);write_byte((t>>8)&255);write_byte(t>>16);
            }
            history.remember(pos,t);
        }
        ensure(p==end);
    }
}
void decode(){
    char h[5];cin.read(h,5);ensure(cin.gcount()==5&&memcmp(h,"M41B\1",5)==0);
    while(cin.peek()!=EOF){
        for(int i=0;i<10;++i){
            int c=read_byte();ensure(c<64);if(i)cout.put(' ');cout<<c;
        }
        History history;int pending=1;
        while(pending>0){
            int op=read_byte();cout.put(' ');
            if(op<30){cout<<(-1-op);++pending;continue;}
            --pending;
            if(op==30){cout<<0;continue;}
            if(op==31){cout<<200021;continue;}
            int pos=op-32,t;
            if(op==96){
                t=read_byte();t|=read_byte()<<8;t|=read_byte()<<16;
                ensure(t>=1&&t<=181440);pos=history.used;
            }else{ensure(op<96&&pos<history.used);t=history.tour[pos];}
            cout<<t;history.remember(pos,t);
        }
        cout.put('\n');
    }
}
int main(int argc,char** argv){
    ios::sync_with_stdio(false);cin.tie(nullptr);
    if(argc!=2)return 2;
    if(string(argv[1])=="pack")encode();
    else if(string(argv[1])=="unpack")decode();else return 2;
    cout.flush();return cout?0:1;
}
