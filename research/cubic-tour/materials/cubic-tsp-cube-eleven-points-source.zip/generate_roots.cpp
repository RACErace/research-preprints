// Enumerate ten-box signatures directly and keep the least member of each cube orbit.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using Row=array<int,10>;
using Map=array<int,64>;
Row boxes{};
vector<Map> group;
int faces[64]{},suffix[65]{};
int roots=0;
uint64_t legal=0;
bool canonical(){
    for(const auto& g:group){
        Row img{};
        for(int i=0;i<10;++i)img[i]=g[boxes[i]];
        sort(img.begin(),img.end());
        if(img<boxes)return false;
    }
    return true;
}
void enumerate(int i,int low,int taken){
    if((taken|suffix[low])!=63)return;
    if(i==10){
        if(taken!=63)return;
        ++legal;
        if(canonical()){
            ++roots;
            for(int j=0;j<10;++j)cout<<boxes[j]<<(j==9?'\n':' ');
        }
        return;
    }
    for(int c=low;c<64;++c){
        if(taken&faces[c])continue;
        boxes[i]=c;
        enumerate(i+1,c+(faces[c]!=0),taken|faces[c]);
    }
}
int main(){
    array<int,3> axis{0,1,2};
    do{
        for(int f=0;f<8;++f){
            Map g{};
            for(int c=0;c<64;++c)for(int j=0;j<3;++j){
                int digit=c>>(2*axis[j])&3;
                g[c]|=((f>>j&1)?3-digit:digit)<<(2*j);
            }
            group.push_back(g);
        }
    }while(next_permutation(axis.begin(),axis.end()));
    for(int c=63;c>=0;--c){
        for(int j=0;j<3;++j){
            int digit=c>>(2*j)&3;
            if(digit==0||digit==3)faces[c]|=1<<(2*j+(digit==3));
        }
        suffix[c]=suffix[c+1]|faces[c];
    }
    enumerate(0,0,0);
    cerr<<"legal "<<legal<<" canonical "<<roots<<'\n';
    return legal!=11295372||roots!=238996;
}
