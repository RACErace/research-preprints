# 三维立方巡回的投影与覆盖

2026 年 11 月 27 日。证明稿见 `proof.md` 或仓库 PDF。对任意点数的严格反例，必有同轴投影三点，两道间隙均超过 2/7。任一最少点数反例的两个间隙均超过 5/16。该点集也不能被总半径立方和至多 1/620 的十个欧氏球覆盖。任意点数、任意簇内分布下，相应的十球排除预算为 1/750。半厚度正方薄层的任意点数上界为 8.495628452，4/7 厚度的上界为 11.224820587（均向上舍入）。本文使用边长立方和。全局范围仍是 8√2 至 16.10。

## 离线验证

在解压目录运行以下命令。需要 Bash、GNU sha256sum、diff、cmp 和 Python 3.10 或更新版本。新证书的检查不需联网或额外 Python 包。

```sh
bash reproduce.sh
```

公开包复核本轮五种结论。脚本先验证 SHA-256，把输出与参考日志逐字比较，并从端口规格重新枚举薄层闭环。

## 新代码与证书

- `generate_orders.py` 通过带列生成的线性规划搜索角簇的有向巡回分布。生成需要 NumPy、SciPy。浮点数只用于提议，导出结果是整数权重。`orders.json` 每个键是八位角码列，0、1、2 分别表示入口的标记轴，3 表示空角。两组记录先列全局内部常数，再列适用于已知较小内部常数的记录。每个权重与一个列出角码的字符串成对，每组权重和为 1048576。
- `verify_orders.py` 独立重建全部 65,536 种码列的对称轨道，用上取整弧势检查每个连续半径盒的所有顶点。成本分母为 70,368,744,177,664。它同时核验按占用数列表的界，以及统一半径 2/7 和 5/16 的界。
- `verify_parity.py` 穷尽四个交错角的标记与半径端点，向外包围端口平均和与线性余量。端口坐标如何严格消除见正文第 4 节。`verify_cover.py` 用整数根包围检查两种十球预算的所有严格不等式。
- `spring_base.py` 给出开原型、空间朝向、时间反转与有理角点时刻。`generate_slab.py` 搜索四块环及内部取等弦。`slab.json` 储存选定的四块、端点位置及其时刻。`verify_slab.py` 从这些规格重建参数对分枝与两端厚度的完整证明。`verify_variation.py` 验证在各可达状态中有界深度找到取等弦所需的覆盖关系。
- 同名 `.log` 记录本轮重放的完整输出。PDF 与可编辑 Markdown 都包含连续坐标归约、插值和固定次序总变差极限的证明。

可在新路径重新生成两份小证书，再用检查器独立验证。不同线性规划库版本可以选出不同的可行权重。

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B generate_orders.py rebuilt-orders.json
python3 -B verify_orders.py rebuilt-orders.json
python3 -B generate_slab.py rebuilt-slab.json
python3 -B verify_slab.py rebuilt-slab.json
```

## 前置定理和独立复核

本轮证书引用同一公开仓库中的 [十点上界和刚性](https://github.com/RACErace/research-preprints/blob/main/cubic-tsp-cube-ten-points.pdf) 与 [全局 16.10 上界](https://github.com/RACErace/research-preprints/blob/main/cubic-tsp-cube-reordering.pdf)。两篇的公开源码与生成器可重放全部前置结果。另有完整核验归档，含较大的预生成十点森林；为避免重复储存，公开源码包不内置这些前置森林。本轮代码和新证书全部在本包中。
