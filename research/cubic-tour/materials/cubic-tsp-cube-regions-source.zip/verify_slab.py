"""Exact covering of parameter pairs in a four-cell Spring ring, in two metrics."""
from collections import deque
from fractions import Fraction as F
from itertools import product
import json
import sys
from spring_base import (CORNERS, GATES, RULES, cell, check_gates, corner_time, gap,
                         gate_positions, parts)

T0=F(442,511)
LAYOUT=((0,0,0),(1,0,0),(1,1,0),(0,1,0))

def require(ok):
    if not ok:
        raise ValueError("invalid slab certificate")

def initial_states(ring):
    todo=set()
    def add(seq,i,j):
        v,a=seq[i];w,b=seq[j%len(seq)]
        todo.add((a,b,gap(v,w),j-i))
    for i in range(4):
        for q in range(1,5):add(ring,i,i+q)
    work=[s for _,s in ring]
    known=set()
    while work:
        state=work.pop()
        if state in known:continue
        known.add(state)
        seq=parts(state)
        work.extend(s for _,s in seq)
        for i in range(8):
            for j in range(i+1,8):add(seq,i,j)
    return todo,len(known)

def check_metric(ring,t):
    # Multiply squared distances by den(t)^2. K is the chord rate in cell units.
    weight=(t.denominator**2,)*2+((2*t.numerator)**2,)
    rate_sq=(2+16*t*t)**3/T0**2
    B=t.denominator**6*rate_sq.numerator
    A=rate_sq.denominator
    roots,nstates=initial_states(ring);queue=deque(roots)
    seen=set();boxes=corners=0;largest=0
    while queue:
        a,b,d,q=queue.popleft()
        S=sum(i*(abs(j)+1)**2 for i,j in zip(weight,d))
        S3A=S**3*A
        if q>=2 and S3A<=B*(q-1)**2:
            boxes+=1;continue
        m=min(i*abs(j) for i,j in zip(weight,d))
        if m and 4*m*m*S*A>=64*B:
            v=tuple(int(h<0) for h in d);w=tuple(1-i for i in v)
            T=q+corner_time(b,w)-corner_time(a,v)
            if T>0 and S3A*T.denominator**2<=B*T.numerator**2:
                corners+=1;continue
        key=(a,b,d,q)
        if key in seen:continue
        seen.add(key);largest=max(largest,q)
        require(len(seen)<=20000 and q<500)
        for i,(x,s) in enumerate(parts(a)):
            for j,(y,tstate) in enumerate(parts(b)):
                diff=tuple(2*k+yy-xx for k,xx,yy in zip(d,x,y))
                queue.append((s,tstate,diff,8*q+j-i))
    return nstates,len(roots),len(seen),largest,boxes,corners

def check_ring(raw):
    ring=tuple(cell(tuple(v),frame,kind) for v,frame,kind in raw)
    require(tuple(v for v,_ in ring)==LAYOUT)
    for k in range(2):check_gates(RULES[k],GATES[k])
    ports=[]
    for v,s in ring:
        ports.append([tuple(3*i+j for i,j in zip(v,p)) for p in gate_positions(s)])
    require(all(ports[i][1]==ports[(i+1)%4][0] for i in range(4)))
    return ring

def check_hit(ring,time,position):
    local=4*time
    v,s=ring[int(local)]
    local-=int(4*time)
    for _ in range(2):
        local*=8
        child,t=parts(s)[int(local)]
        v=tuple(2*x+y for x,y in zip(v,child))
        s=t;local-=int(local)
    corner=tuple(8*x-y for x,y in zip(position,v))
    require(corner in CORNERS and corner_time(s,corner)==local)

def main(path):
    with open(path,encoding='utf-8') as f:record=json.load(f)
    ring=check_ring(record['cells'])
    pts=[tuple(map(F,p)) for p in record['positions_at_half']]
    s,t=map(F,record['times'])
    check_hit(ring,s,pts[0]);check_hit(ring,t,pts[1])
    step=tuple(8*abs(x-y) for x,y in zip(*pts))
    require(step==(1,1,2) and (t-s)*256==T0)
    print("equality chord at",s,t,"; normalized lag",T0)
    for h in (F(1,2),F(2,3)):
        print("thickness",h,"frames roots expanded max-lag box corner",*check_metric(ring,h))
    require((2+16*F(4,7)**2)**3 < 128*(2*T0)**2)
    require((2+16*F(1,2)**2)**3 < (17*T0)**2)

if __name__=='__main__':main(sys.argv[1])
