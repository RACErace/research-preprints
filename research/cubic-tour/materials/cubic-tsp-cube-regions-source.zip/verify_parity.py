"""Rigorous cap and slope for the four alternating corner clouds."""
from fractions import Fraction as F
from itertools import combinations,product
from math import isqrt

S=(0,3,5,6)
SCALE=10**10

def require(ok):
    if not ok:raise ValueError("alternating-corner certificate")

def ceil_norm3(d2,D):
    a=SCALE**2*d2**3;b=D**6
    root=isqrt(a//b)
    return root+int(root*root*b<a)

def verify(R,M,slope):
    D=R.denominator
    Hlow=F(isqrt(128*SCALE**2),SCALE)
    worst=None
    for marks in product(range(3),repeat=4):
        for mask in range(1,16):
            clouds=[];m=mask.bit_count()
            for i,(c,j) in enumerate(zip(S,marks)):
                base=tuple(D*((c>>k)&1) for k in range(3));pin=list(base)
                if mask>>i&1:
                    pin[j]+=R.numerator*(1-2*((c>>j)&1))
                clouds.append((base,tuple(pin)))
            z=sum(ceil_norm3(sum((x-y)**2 for x,y in zip(a,b)),D)
                  for i,j in combinations(range(4),2) for a in clouds[i] for b in clouds[j])
            margin=(Hlow-M*m*R**3-F(z,6*SCALE))/(m*R)
            worst=margin if worst is None else min(worst,margin)
    require(worst>slope)
    print("cap",R,"internal",M,"claimed slope",slope,"verified slope >",int(worst*10**6),"/ 1000000")
def main():
    r=F(3,8)
    require(8*(1-2*r)**2*(2-3*r)**2>r*r*(2+r*r))
    for row in [(F(2,7),F(161,10),F(3,5)),(F(1,3),F(161,10),F(1,80)),
                (F(3,8),F(283,25),F(1,10))]:verify(*row)
if __name__=='__main__':main()
