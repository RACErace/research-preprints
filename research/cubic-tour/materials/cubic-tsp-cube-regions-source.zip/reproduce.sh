#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
sha256sum -c --quiet SHA256SUMS
scratch=$(mktemp -d)
trap 'rm -r -- "$scratch"' EXIT
for name in orders parity cover slab variation; do
    case "$name" in
        orders) args=(orders.json) ;;
        slab|variation) args=(slab.json) ;;
        *) args=() ;;
    esac
    python3 -B "verify_$name.py" "${args[@]}" > "$scratch/$name.log"
    diff -u "$name.log" "$scratch/$name.log"
    cat "$scratch/$name.log"
done
python3 -B generate_slab.py "$scratch/regenerated.json"
cmp slab.json "$scratch/regenerated.json"
echo 'All requested offline replays matched.'
