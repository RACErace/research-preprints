"""Outward rational bounds for heterogeneous ten-ball covers; no external modules."""
from fractions import Fraction as F
from math import isqrt

DEN=10**12
def roots(x,k):
    x=F(x);a=x.numerator*DEN**k;b=x.denominator
    if k==2:
        z=isqrt(a//b)
    else:
        lo,hi=0,1
        while hi**k*b<=a:hi*=2
        while hi-lo>1:
            m=(lo+hi)//2
            if m**k*b<=a:lo=m
            else:hi=m
        z=lo
    return F(z,DEN),F(z+int(z**k*b<a),DEN)
def require(ok):
    if not ok:raise ValueError("cover scalar certificate")
def main():
    L2,U2=roots(2,2);_,U3=roots(3,2)
    Hlo,Hhi=8*L2,8*U2
    eta_lo=125*L2/512
    u=F(1,8)
    def A(r):return 4*L2*(1-r)/3-r*roots(2+r*r,2)[1]/2
    require(A(F(1,4))>F(161,10)/16)
    for budget,M,radius_bound in [(750,F(161,10),F(19,40)),(620,F(283,25),F(2487,5000))]:
        S=F(1,budget)
        r3=roots(S,3)[1]
        p2=roots(4,3)[1];p4=roots(16,3)[1]
        require(u+2*p2*r3<radius_bound<F(1,2))
        require(2*(p2+p4)*r3<1)
        broad=(8*M+8)*S+6*roots(Hhi-eta_lo,3)[1]*r3**2
        E=(8*M+8)*S+6*U3*u*roots(10,3)[1]*r3**2
        require(broad<eta_lo)
        saving=min(r*(A(r)-Hhi*u*u) for r in (F(1,4),radius_bound))
        require(saving>E)
        z=2+radius_bound**2
        require(3*(z*roots(z,2)[1]+Hhi*u**3)+E < Hlo)
        require(roots(S,3)[0]>F(11,100) if budget==750 else roots(S,3)[0]>F(117,1000))
        def floor6(x):return (x*10**6).numerator//(x*10**6).denominator
        def ceil6(x):return -floor6(-x)
        print("denominator",budget,"broad error <",ceil6(broad),"/ 1000000; near cost <",ceil6(E),
              "/ 1000000; near saving >",floor6(saving),"/ 1000000")
if __name__=='__main__':main()
