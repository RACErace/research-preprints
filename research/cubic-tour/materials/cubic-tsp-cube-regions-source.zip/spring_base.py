"""Exact cubical certificate for the closed Spring construction. Python standard library."""
from collections import Counter, deque
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product

CORNERS=tuple(product((0,1),repeat=3))
ID=tuple(range(8))
ZERO=(0,0,0)
D_SQUARED=Q(6*1533**2,221**2)
GATES=(((1,1,0),(2,0,1)),((1,1,0),(3,1,1)))  # units of 1/3
PATH=("jikIJiK","jkJijKJ")
FRAMES=("KIJ KIj kji Jki JkI kIJ KJi JiK","KIJ ijK Ikj KJI kiJ Ijk IjK iKJ")
TYPES=("-b a b -a b a b b","-b -a -a -a -a -a a b")
# (octant, signed images of x,y,z, type; '-' means reversed time)
RING=(
    ((0,0,0),'iJK','-b'),((0,0,1),'iJk','a'),
    ((0,1,1),'ijk','-a'),((0,1,0),'ijK','b'),
    ((1,1,0),'IjK','-b'),((1,1,1),'Ijk','a'),
    ((1,0,1),'IJk','-a'),((1,0,0),'IJK','b'),
)

def require(p):
    if not p:
        raise ValueError('invalid geometric certificate')

def perm(word):
    result=[]
    for v in CORNERS:
        w=[0]*3
        for j,ch in enumerate(word):
            w['ijk'.index(ch.lower())]=v[j] if ch.islower() else 1-v[j]
        result.append(CORNERS.index(tuple(w)))
    require(sorted(result)==list(ID))
    return tuple(result)

def cell(c,h,t):
    return (c,(int(t[-1]=='b'),perm(h),t.startswith('-')))

def prototype(k):
    p=[0,0,0];path=[tuple(p)]
    for ch in PATH[k]:
        p['ijk'.index(ch.lower())]+=1 if ch.islower() else -1
        path.append(tuple(p))
    return tuple(cell(*s) for s in zip(path,FRAMES[k].split(),TYPES[k].split()))

RULES=tuple(prototype(k) for k in (0,1))
TOP=tuple(cell(*r) for r in RING)

@lru_cache(None)
def parts(state):
    k,h,rev=state
    res=[]
    for octant,(s,g,r) in RULES[k]:
        pos=CORNERS[h[CORNERS.index(octant)]]
        res.append((pos,(s,tuple(h[j] for j in g),r^rev)))
    return tuple(res[::-1] if rev else res)

def gate_positions(state):
    k,h,rev=state
    # Affine interpolation from the origin and its three neighbours.
    o=CORNERS[h[0]]
    basis=[CORNERS[h[CORNERS.index(tuple(int(i==j) for i in range(3)))]] for j in range(3)]
    def map_gate(v):
        return tuple(3*o[i]+sum((basis[j][i]-o[i])*v[j] for j in range(3)) for i in range(3))
    g=tuple(map_gate(v) for v in GATES[k])
    return g[::-1] if rev else g

def check_gates(seq,outer=None):
    require({v for v,_ in seq}==set(CORNERS))
    gates=[]
    for v,st in seq:
        gates.append(tuple(tuple(3*a+b for a,b in zip(v,e)) for e in gate_positions(st)))
    require(all(a[1]==b[0] for a,b in zip(gates,gates[1:])))
    if outer is None:
        require(gates[-1][1]==gates[0][0])
    else:
        require((gates[0][0],gates[-1][1])==tuple(tuple(2*x for x in p) for p in outer))

@lru_cache(None)
def corner_time(state,v):
    # Compute the base-8 address of the unique child containing the cube vertex.
    seen={};digits=[]
    while state not in seen:
        seen[state]=len(digits)
        seq=parts(state)
        (j,state),=((j,child) for j,(pos,child) in enumerate(seq) if pos==v)
        digits.append(j)
    k=seen[state]
    def value(word):
        n=0
        for a in word:n=8*n+a
        return n
    return (Q(value(digits[:k]),8**k)
            +Q(value(digits[k:]),8**k*(8**(len(digits)-k)-1)))

def gap(a,b):
    return tuple(y-x for x,y in zip(a,b))

def verify_reported_hit(t,p):
    # Both reported spatial points are vertices on the first dyadic grid.
    scaled=8*t
    idx=int(scaled)
    origin,state=TOP[idx]
    local=tuple(2*v-i for v,i in zip(p,origin))
    require(local in CORNERS)
    require(corner_time(state,local)==scaled-idx)

def verify():
    check_gates(TOP)
    verify_reported_hit(Q(145,2044),(Q(0),Q(1,2),Q(0)))
    verify_reported_hit(Q(183,1022),(Q(1,2),Q(0),Q(1)))
    for k in (0,1):
        check_gates(RULES[k],GATES[k])
    queue=deque()
    # Save actual addresses of one occurrence with each queued state. They are used
    # only to print a witness. The finite key uses translation, without axis symmetries.
    def root(seq,i,j,tag):
        v,a=seq[i];w,b=seq[j%8]
        queue.append((a,b,gap(v,w),j-i,(tag,1,i,v)))
    for i in range(8):
        for q in range(1,9):root(TOP,i,i+q,'ring')
    for k in (0,1):
        for i in range(8):
            for j in range(i+1,8):root(RULES[k],i,j,'ab'[k])
    seen=set();stats=Counter();max_lag=0;witness=None
    while queue:
        a,b,d,q,address=queue.popleft()
        L=sum((abs(x)+1)**2 for x in d)
        if q>=2 and L**3*D_SQUARED.denominator<=D_SQUARED.numerator*(q-1)**2:
            stats['box']+=1
            continue
        m=min(abs(x) for x in d)
        if 4*m*m*L*D_SQUARED.denominator>=64*D_SQUARED.numerator:
            v=tuple(int(x<0) for x in d);w=tuple(1-y for y in v)
            ta=corner_time(a,v);tb=corner_time(b,w)
            dt=q+tb-ta
            if dt>0 and L**3<=D_SQUARED*dt**2:
                stats['corner']+=1
                if L**3==D_SQUARED*dt**2 and witness is None:
                    tag,level,index,pos=address
                    p=tuple(Q(i+j,2**level) for i,j in zip(pos,v))
                    r=tuple(Q(i+j+k,2**level) for i,j,k in zip(pos,d,w))
                    u=(index+ta)/8**level;s=(index+q+tb)/8**level
                    require(sum((i-j)**2 for i,j in zip(p,r))**3==D_SQUARED*(s-u)**2)
                    witness=(tag,p,r,u,s)
                continue
        key=(a,b,d,q)
        if key in seen:continue
        seen.add(key);max_lag=max(max_lag,q)
        require(len(seen)<=100000)
        tag,level,index,pos=address
        for i,(x,sa) in enumerate(parts(a)):
            newpos=tuple(2*p+k for p,k in zip(pos,x))
            for j,(y,sb) in enumerate(parts(b)):
                diff=tuple(2*g+k-h for g,k,h in zip(d,y,x))
                queue.append((sa,sb,diff,8*q+j-i,(tag,level+1,8*index+i,newpos)))
    require(witness is not None)
    print('K^2',D_SQUARED,'expanded',len(seen),'max_lag',max_lag,'terminal_counts',dict(stats))
    tag,p,r,u,s=witness
    print('sharp chord in',tag,'from',tuple(map(str,p)),'at',u,'to',tuple(map(str,r)),'at',s)
    return witness

if __name__=='__main__':
    verify()
