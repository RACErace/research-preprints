"""Find rational mixtures of directed corner tours. Requires NumPy and SciPy."""
import json
import sys
from functools import lru_cache
from itertools import permutations, product

import numpy as np
from scipy.optimize import linprog

GLOBAL = [0, 0, 1/2, 2/5, 3/8, 3/10, 2/7, 2/7, 2/7]
PROPER = [0, 0, 1/2, 9/20, 2/5, 1/3, 5/16, 5/16, 5/16]
WEIGHT = 2**20


def representatives():
    used = set()
    for p in product(range(4), repeat=8):
        if p in used:
            continue
        for pi in permutations(range(3)):
            for flip in range(8):
                image = [3]*8
                for v, j in enumerate(p):
                    w = flip ^ sum(((v >> i) & 1) << pi[i] for i in range(3))
                    image[w] = 3 if j == 3 else pi[j]
                used.add(tuple(image))
        yield p


@lru_cache(None)
def combinatorics(n):
    u, v = np.where(~np.eye(n, dtype=bool))
    edge = np.zeros((n,n), dtype=int)
    edge[u,v] = np.arange(len(u))
    tours = np.array([(0,)+t for t in permutations(range(1,n))], dtype=int)
    edges = edge[tours, np.roll(tours,-1,axis=1)]
    masks = np.array(list(product((0,1), repeat=n)), dtype=int)
    return u,v,tours,edges,masks


def matrix(profile, radius, internal):
    sites = [v for v,j in enumerate(profile) if j != 3]
    u,v,tours,edges,masks = combinatorics(len(sites))
    bits = np.array([sites[i] ^ sites[j] for i,j in zip(u,v)])
    hamming = np.array([b.bit_count() for b in bits])
    incoming = (bits >> np.array([profile[sites[j]] for j in v])) & 1
    outgoing = (bits >> np.array([profile[sites[i]] for i in u])) & 1
    ru,rv = radius*masks[:,u],radius*masks[:,v]
    m = np.maximum(ru,rv)
    pinned = np.maximum(rv, np.abs(rv-ru))
    square = (hamming + incoming*(rv**2-2*rv) + (3-hamming)*m**2
              - (1-incoming)*(m*m-pinned*pinned))
    costs = square**1.5 + internal*rv**3 - outgoing*ru**3
    return sites,tours,edges,costs


def solve(profile, radius, internal):
    sites,tours,edges,costs = matrix(profile,radius,internal)
    columns = list(dict.fromkeys(int(c[edges].sum(axis=1).argmin()) for c in costs[[0,-1]]))
    for _ in range(120):
        a = np.stack([costs[:,edges[k]].sum(axis=1) for k in columns], axis=1)
        lin = linprog([0]*len(columns)+[1],
                      A_ub=np.column_stack([a,-np.ones(len(a))]),b_ub=np.zeros(len(a)),
                      A_eq=[[1]*len(columns)+[0]],b_eq=[1],method='highs')
        if not lin.success:
            raise RuntimeError(lin.message)
        expected = (-lin.ineqlin.marginals @ costs)[edges].sum(axis=1)
        best = int(expected.argmin())
        if best in columns or expected[best] >= lin.fun-1e-8:
            weights = np.rint(WEIGHT*lin.x[:-1]).astype(int)
            weights[int(weights.argmax())] += WEIGHT-int(weights.sum())
            return [[int(w),''.join(str(sites[i]) for i in tours[k])]
                    for k,w in zip(columns,weights) if w]
        columns.append(best)
    raise RuntimeError("column iteration bound")


def main(path):
    result = {}
    for profile in representatives():
        sites = [v for v,j in enumerate(profile) if j != 3]
        n = len(sites)
        if n < 2 or (n == 4 and len({v.bit_count()%2 for v in sites}) == 1):
            continue
        name = ''.join(map(str,profile))
        result[name] = [solve(profile,GLOBAL[n],16.1), solve(profile,PROPER[n],11.32)]
    with open(path,'w',encoding='utf-8') as f:
        json.dump(result,f,separators=(',',':'),sort_keys=True)
        f.write('\n')
    print(f"{len(result)} profiles, two rational mixtures per profile")

if __name__ == '__main__':
    main(sys.argv[1])
