"""Verify every continuous corner configuration using integer arithmetic. No SciPy."""
import json
import sys
from collections import Counter, defaultdict
from functools import lru_cache
from fractions import Fraction as F
from itertools import permutations, product
from math import isqrt

UNIT = 2**26
MASS = 2**20
RADII = [
    [0,0,F(1,2),F(2,5),F(3,8),F(3,10),F(2,7),F(2,7),F(2,7)],
    [0,0,F(1,2),F(9,20),F(2,5),F(1,3),F(5,16),F(5,16),F(5,16)]
]
INTERNAL = (F(161,10), F(283,25))
TARGET100 = [[0,0,1078,1071,1084,1116,1092,1105,1087],
             [0,0,1040,1077,1054,1121,1093,1109,1095]]

def require(ok):
    if not ok:
        raise ValueError("corner certificate failed")

def ceil_div(a,b):
    return -((-a)//b)

def isqrt_ceil_fraction(a,b):
    x = isqrt(a//b)
    return x + int(x*x*b < a)

@lru_cache(None)
def arc(u,v,mark_in,mark_out,ru,rv,D,M):
    # Outward lattice-corner maxima; each free scalar ranges over its two endpoints.
    square = 0
    for i in range(3):
        left = (0,ru)
        right = (rv,) if i == mark_in else (0,rv)
        opposite = ((u^v)>>i)&1
        square += max((D-a-b if opposite else a-b)**2 for a in left for b in right)
    refund = ((u^v)>>mark_out)&1
    num = M.numerator*rv**3 - M.denominator*refund*ru**3
    return (isqrt_ceil_fraction(UNIT**2*square**3,D**6)
            + ceil_div(UNIT*num,M.denominator*D**3))

def read_records(pairs):
    answer={}
    for k,v in pairs:
        require(k not in answer)
        answer[k]=v
    return answer

def verify_one(p,mixture,kind,r=None,target100=None):
    sites=[v for v,d in enumerate(p) if d!=3]
    n=len(sites)
    if r is None:r=RADII[kind][n]
    if target100 is None:target100=TARGET100[kind][n]
    M=INTERNAL[kind]
    arcs=Counter(); total=0
    for w,word in mixture:
        require(type(w) is int and 0<w<=MASS)
        seq=list(map(int,word))
        require(sorted(seq)==sites)
        total+=w
        for u,v in zip(seq,seq[1:]+seq[:1]):
            arcs[u,v]+=w
    require(total==MASS)
    index={v:i for i,v in enumerate(sites)}
    # A binary pair potential decomposes into a constant, singleton and pair terms.
    constant=0;linear=[0]*n;quadratic=defaultdict(int)
    for (u,v),w in arcs.items():
        h=[[w*arc(u,v,p[v],p[u],a*r.numerator,b*r.numerator,r.denominator,M)
            for b in range(2)] for a in range(2)]
        i,j=index[u],index[v]
        constant+=h[0][0]
        linear[i]+=h[1][0]-h[0][0];linear[j]+=h[0][1]-h[0][0]
        quadratic[tuple(sorted((i,j)))]+=h[1][1]-h[1][0]-h[0][1]+h[0][0]
    maximum=constant
    for bits in product(range(2), repeat=n):
        z=constant+sum(v for b,v in zip(bits,linear) if b)
        z+=sum(v for (i,j),v in quadratic.items() if bits[i] and bits[j])
        maximum=max(maximum,z)
    require(100*maximum <= target100*UNIT*MASS)
    return maximum

def orbit(profile):
    # Columns indexed by the output axis, in contrast with the generator's input-axis map.
    result=set()
    for order in permutations(range(3)):
        renamed=[order.index(x) for x in range(3)]+[3]
        for flips in product(range(2), repeat=3):
            p=[3]*8
            for v,mark in enumerate(profile):
                dest=sum((flips[i]^((v>>order[i])&1))<<i for i in range(3))
                p[dest]=renamed[mark]
            result.add(tuple(p))
    return result

def main(path):
    with open(path,encoding='utf-8') as f:
        records=json.load(f,object_pairs_hook=read_records)
    used=set();orbits=Counter();categories=Counter();maxima=defaultdict(int)
    uniform=[0,0]
    for p in product(range(4),repeat=8):
        if p in used:continue
        images=orbit(p)
        require(not used.intersection(images))
        used.update(images)
        sites=[v for v,j in enumerate(p) if j<3];n=len(sites);orbits[n]+=1
        if n<2:categories['zero or one']+=1;continue
        if n==4 and len({v.bit_count()%2 for v in sites})==1:
            categories['alternating four']+=1;continue
        mixtures=records.pop(''.join(map(str,p)))
        require(len(mixtures)==2)
        for k,mix in enumerate(mixtures):
            bound=verify_one(p,mix,k)
            maxima[k,n]=max(maxima[k,n],bound)
            cap,target=[(F(2,7),1105),(F(5,16),1109)][k]
            if cap!=RADII[k][n]:bound=verify_one(p,mix,k,cap,target)
            require(100*bound<=target*UNIT*MASS)
            uniform[k]=max(uniform[k],bound)
        categories['verified profiles']+=1
    require(len(used)==4**8 and not records)
    print("all 65536 profiles; orbit counts by occupancy",sorted(orbits.items()))
    print("orbit classes",sorted(categories.items()))
    print("uniform caps 2/7 and 5/16, upper numerators",uniform)
    for k in range(2):
        print("case",k,"certified cost hundredths",TARGET100[k][2:])
        print("worst upper numerators, denominator",UNIT*MASS, [maxima[k,n] for n in range(2,9)])
if __name__=='__main__':
    main(sys.argv[1])
