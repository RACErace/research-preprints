"""Bounded access to an interior equality chord from each reachable orientation."""
from fractions import Fraction as F
import json
import sys
from spring_base import RULES,D_SQUARED,parts
from verify_slab import T0,check_ring,check_hit,require

def main(path):
    record=json.load(open(path,encoding='utf-8'))
    ring=check_ring(record['cells'])
    times=list(map(F,record['times']))
    pts=[tuple(map(F,v)) for v in record['positions_at_half']]
    for t,p in zip(times,pts):check_hit(ring,t,p)
    require(0<times[0]<times[1]<F(1,4))
    first=ring[0][1]
    require(first[0]==1 and 4*(times[1]-times[0])==T0/64)
    require(D_SQUARED==F(6**3)/T0**2)
    states=set();todo=[s for _,s in ring]
    while todo:
        s=todo.pop()
        if s in states:continue
        states.add(s);todo.extend(t for _,t in parts(s))
    hit={first};history=[len(hit)]
    for _ in range(3):
        hit.update({s for s in states if any(t in hit for _,t in parts(s))})
        history.append(len(hit))
    require(hit==states)
    require(all(any(s[0]==1 for _,s in children) for children in RULES))
    print("reachable from slab cells",len(states),"reverse layers toward marked B",history)
    print("relative equality interval",T0/64,"; guaranteed fractions per cell, slab and cube",
          T0/(64*8**3),T0/(64*8))
if __name__=='__main__':main(sys.argv[1])
