"""Build the four-cell slab ring from face gates. Python standard library."""
from itertools import permutations,product
from fractions import Fraction as F
import json
import sys
from spring_base import cell,gate_positions
from verify_slab import LAYOUT,T0,check_ring,check_metric

def candidates():
    allowed=[]
    for i,origin in enumerate(LAYOUT):
        prev=LAYOUT[i-1];nxt=LAYOUT[(i+1)%4]
        d=next(k for k in range(3) if origin[k]!=prev[k])
        e=next(k for k in range(3) if origin[k]!=nxt[k])
        options=[]
        for axes in permutations('ijk'):
            for flip in product(range(2),repeat=3):
                frame=''.join(c.upper() if f else c for c,f in zip(axes,flip))
                for kind in ('a','-a','b','-b'):
                    _,state=cell(origin,frame,kind)
                    g,h=gate_positions(state)
                    if g[d]!=3*prev[d] or h[e]!=3*nxt[e]:continue
                    ports=[tuple(3*x+y for x,y in zip(origin,p)) for p in (g,h)]
                    options.append(((origin,frame,kind),*ports))
        allowed.append(options)
    def extend(prefix):
        if len(prefix)==4:
            if prefix[-1][2]==prefix[0][1]:
                yield [t[0] for t in prefix]
            return
        for t in allowed[len(prefix)]:
            if not prefix or t[1]==prefix[-1][2]:yield from extend(prefix+[t])
    return list(extend([]))

def find_hit(ring):
    from spring_base import CORNERS,corner_time,parts
    cells=list(ring)
    for level in range(4):
        for i,(v,s) in enumerate(cells[:-1]):
            w,t=cells[i+1]
            for a in CORNERS:
                b=tuple(1-q for q in a)
                p=tuple(x+y for x,y in zip(v,a));q=tuple(x+y for x,y in zip(w,b))
                if tuple(abs(x-y) for x,y in zip(p,q))!=(1,1,2):continue
                ta,tb=corner_time(s,a),corner_time(t,b)
                if 1+tb-ta==T0:
                    pos=[[str(F(x,2**(level+1))) for x in h] for h in (p,q)]
                    times=[str((i+ta)/len(cells)),str((i+1+tb)/len(cells))]
                    return pos,times
        cells=[(tuple(2*i+j for i,j in zip(v,w)),t) for v,s in cells for w,t in parts(s)]
    raise ValueError("no witness")

def main(out):
    rings=candidates()
    if len(rings)!=68:raise ValueError("gate enumeration")
    for raw in rings:
        ring=check_ring(raw)
        try:
            for h in (F(1,2),F(2,3)):check_metric(ring,h)
        except ValueError:
            continue
        p,t=find_hit(ring)
        with open(out,'w',encoding='utf-8') as f:
            json.dump({'cells':raw,'positions_at_half':p,'times':t},f,indent=2)
            f.write('\n')
        print("68 gate-compatible rings; saved first accepted ring and equality chord")
        return
    raise RuntimeError("no verified ring")
if __name__=='__main__':main(sys.argv[1])
