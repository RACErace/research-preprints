#!/usr/bin/env bash
# Run every supporting check for the manuscript, using only the local bundle.
set -euo pipefail
cd -- "$(dirname -- "$0")"
checkdir=$(mktemp -d)
trap 'rm -r -- "$checkdir"' EXIT
sha256sum -c --quiet SHA256SUMS
xz -dc margin9.boxes.xz > "$checkdir/margin9.boxes"
srcdir="$PWD"
(cd "$checkdir" && sha256sum -c --quiet "$srcdir/MARGIN-SHA256.txt")
python3 -B spring_base.py > "$checkdir/curve.log"
python3 -B verify_global.py global.json > "$checkdir/global.log"
python3 -B verify_global.py rediscovered.json > "$checkdir/rediscovered.log"
python3 -B verify_structures.py > "$checkdir/structures.log"
c++ -O2 -std=c++17 verify9.cpp -o "$checkdir/check9"
"$checkdir/check9" < "$checkdir/margin9.boxes" > "$checkdir/nine.log"
python3 -B small/verify_finite.py > "$checkdir/finite.log"
c++ -O2 -std=c++17 small/verify_boxes.cpp -o "$checkdir/check78"
for n in 7 8; do
    gzip -dc "small/n$n.boxes.gz" | "$checkdir/check78" > "$checkdir/boxes$n.log"
    diff -u "small/boxes$n.log" "$checkdir/boxes$n.log"
    cat "$checkdir/boxes$n.log"
done
for check in curve global rediscovered structures nine; do
    diff -u "$check.log" "$checkdir/$check.log"
    cat "$checkdir/$check.log"
done
diff -u small/finite.log "$checkdir/finite.log"
cat "$checkdir/finite.log"
echo "All certificate replays match."
