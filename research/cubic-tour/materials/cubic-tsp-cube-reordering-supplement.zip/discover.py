"""Find and certify probes for an endpoint partition.
Usage: python3 -B discover.py partition.json out.json
"""
import json
import sys
from functools import lru_cache
from math import isqrt
from pathlib import Path
import partners as v
from curve_windows import expand


class Single:
    def __init__(self, settings):
        self.settings=settings
        self.check=v.Checker(dict(settings,leaves=[]))
        self.hints={}
        self.failures=[]
        self.memo={}

    @lru_cache(None)
    def samples(self,cell):
        # Spatial centers only guide which times to try first.
        cells=expand(v.refine(cell))
        S,T=self.check.S,self.check.T
        return tuple((tuple((2*a+1)*(S//8) for a in p),(2*i+1)*(T//128))
                     for i,(p,_) in enumerate(cells))

    def candidates(self,word,depth,i,j):
        c=self.check
        q=len(word)-2*c.radius-1
        scale=8**depth
        unit=c.T//scale
        side=c.S//(2**depth)
        lower=max(c.T//2,(j-i-1)*unit)
        a=v.lower_corner(v.subcell(word[c.radius],i,depth),side)
        b=v.lower_corner(v.subcell(word[c.radius+q],j-q*scale,depth),side)
        result=[]
        for slot in range(-c.radius,1):
            for z,t in self.samples(word[c.radius+slot]):
                w=slot*c.T+t
                if w>=i*unit or 100*((i+1)*unit-w)>c.a*lower:
                    continue
                za=sum((2*x-2*y-side)**2 for x,y in zip(z,a))
                zb=sum((2*x-2*y-side)**2 for x,y in zip(z,b))
                score=isqrt(za**3)+isqrt(zb**3)+2*((i+1)*unit-w)
                result.append((score,w))
        return result

    def choose(self,word,h,i,j):
        c=self.check
        q=len(word)-2*c.radius-1
        size=(q+1)*8**h
        rev=v.normalize(v.reverse(word),c.radius)
        views=((word,i,j),(rev,size-1-j,size-1-i))
        options=sorted((score,d,w) for d,(seq,lo,hi) in enumerate(views)
                       for score,w in self.candidates(seq,h,lo,hi))
        tried=([],[])
        for clearance,cap in ((c.T//14,8),(c.T//48,18),(0,len(options)+1)):
            for _,d,w in options:
                if len(tried[0])+len(tried[1])>=cap:
                    break
                if any(abs(w-x)<=clearance for x in tried[d]):
                    continue
                tried[d].append(w)
                seq,lo,hi=views[d]
                try:
                    c.partner(seq,h,lo,hi,w)
                except ValueError as exc:
                    if str(exc)!="unproved partner inequality":
                        raise
                    continue
                self.memo[(rev,h,size-1-j,size-1-i)]=(1-d,w)
                return d,w
        return None

from itertools import combinations,product
from verify_global import validate,verify_policy,viewed,second_works
from reconnect import minperiod,turn,co_certify,original
def reverse_view(core,h,i,j,c):
    q=len(core)-2*c.radius-1
    end=(q+1)*8**h-1
    return v.normalize(v.reverse(core),c.radius),end-j,end-i


class Finder(Single):
    def __init__(self,spec):
        self.settings=spec
        self.check=v.Checker(dict(spec,leaves=[]))
        self.hints={}
        self.memo={}
        self.failures=[]

    def options(self,word,h,i,j,limit):
        choices=sorted(self.candidates(word,h,i,j))
        picked=[]
        for clearance,cap in ((self.check.T//12,6),(self.check.T//32,14),(self.check.T//96,limit),(0,limit)):
            for _,w in choices:
                if len(picked)>=cap:break
                if all(abs(w-y)>clearance for y in picked):picked.append(w)
        return picked

    def search_multi(self,core,h,i,j,profile=None):
        c=self.check
        views=[(core,i,j),reverse_view(core,h,i,j,c)]
        choices=[self.options(word,h,l,r,32) for word,l,r in views]
        q=len(core)-2*c.radius-1
        span=(q+1)*c.T
        for stop,cap in ((1,25),(2,38),(3,64)):
            bad=[{},{}]
            for d,(seq,l,r) in enumerate(views):
                for w in choices[d]:
                    try:
                        data=c.partner(seq,h,l,r,w,stop=stop,cap=cap)
                    except ValueError as e:
                        if str(e)=="residual cap":continue
                        raise
                    if not data:return (d,w)
                    bad[d][w]=data
            if profile:
                print("residual",stop,[(len(t),sorted(len(b) for b in t.values())[:12]) for t in bad],flush=True)
            # Small residual Cartesian products are checked first.
            tests=[]
            for d,t in enumerate(bad):
                for w,z in combinations(sorted(t),2):
                    tests.append((len(t[w])*len(t[z]),d,0,w,z))
            for w,z in product(bad[0],bad[1]):
                if span-w-z<minperiod(core,h,i,j,c):
                    tests.append((len(bad[0][w])*len(bad[1][z]),0,1,w,z))
            converted={}
            for _,d,op,w,z in sorted(tests):
                seq,l,r=views[d]
                I=original(seq,h,l,r,c)
                A=bad[d][w]
                if op:
                    if z not in converted:
                        converted[z]=[turn(a,span,seq[c.radius+q],c.S) for a in bad[1-d][z]]
                    B=converted[z]
                else:B=bad[d][z]
                if co_certify(c,I,A,B,op):
                    return (d,w,op,z,stop)
        return None

    def choose(self,word,h,i,j):
        got=super().choose(word,h,i,j)
        if got is not None:return got
        return self.search_multi(word,h,i,j)


class Adaptive(Finder):
    def policy(self,s,h,i,j):
        c=self.check;q=len(s)-2*c.radius-1;span=(q+1)*c.T
        views=[(s,i,j),viewed(c,s,h,i,j,1)]
        options=[self.options(w,h,l,r,42) for w,l,r in views]
        tables=[{},{}]
        for stop,cap in ((1,100),(2,120),(3,220)):
            for d,(seq,lo,hi) in enumerate(views):
                for w in options[d]:
                    try:lst=c.partner(seq,h,lo,hi,w,stop=stop,cap=cap)
                    except ValueError as ex:
                        if str(ex)=="residual cap":continue
                        raise
                    if not lst:return (d,w)
                    tables[d][(w,stop)]=lst
            conv={}
            for d,(seq,lo,hi) in enumerate(views):
                A=tables[d];R=tables[1-d];I=original(seq,h,lo,hi,c)
                for (w,k),lst in sorted(A.items(),key=lambda z:len(z[1]))[:35]:
                    remaining=set(lst);acc=[]
                    trials=sorted([(len(vv),0,zz,p) for (zz,p),vv in A.items() if zz!=w]+
                                  [(len(vv),1,zz,p) for (zz,p),vv in R.items() if span-zz-w<minperiod(seq,h,lo,hi,c)])
                    for _,op,zz,p in trials:
                        if op:
                            key=d,zz,p
                            if key not in conv:conv[key]=[turn(a,span,seq[c.radius+q],c.S) for a in R[(zz,p)]]
                            B=conv[key]
                        else:B=A[(zz,p)]
                        hit={arc for arc in remaining if second_works(c,seq,h,lo,hi,w,arc,op,zz,B)}
                        if not hit:continue
                        remaining-=hit;acc.append((op,zz,p))
                        if not remaining:return ("C",d,w,k,acc)
        return None



def discover(template,outfile):
    # The topological partition can be supplied independently of the probes. Every branch is recertified.
    search=Adaptive(template)
    c=search.check; results=[]; cached={}
    for item in template.get("candidates",[]):
        lag,tip=item[0],item[1:]
        cached.setdefault(lag,[]).append(tip)
    for q,k,h,i,j in template["partition"]:
        seq=v.small_words(q,c.radius)[k]
        hit=None
        for hint in cached.get(q,[]):
            try:ok=(verify_policy if hint[0]=="C" else validate)(c,seq,h,i,j,hint)
            except ValueError:ok=False
            if ok:hit=hint;break
        if hit is None:hit=search.choose(seq,h,i,j)
        if hit is None:hit=search.policy(seq,h,i,j)
        if hit is None:raise ValueError(("no probe at this search budget",q,k,h,i,j))
        results.append([q,k,h,i,j]+list(hit))
        if len(hit)>2 and hit not in cached.setdefault(q,[]):cached[q].append(hit)
    data={key:value for key,value in template.items() if key not in ("partition","candidates")}
    data.update(leaves=results,unresolved=[])
    Path(outfile).write_text(json.dumps(data,separators=(",",":"))+"\n")

if __name__=="__main__":
    discover(json.loads(Path(sys.argv[1]).read_text()),sys.argv[2])
