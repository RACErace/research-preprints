# 三维立方巡回的局部重排与删点约束

2026-11-26 的研究预印本配套材料。总成本是闭巡回各欧氏边长立方的和。任意有限点集都有总成本至多 16.10 的巡回，交错四角给出下界 8√2。本包同时给出九点的近取等刚性和两个推论。含距离至多 3/14 点对的互异十点构型严格低于 8√2，任意点数的严格反例必含十个两两距离大于 1/33 的点。十点其余情形以及全局猜想仍未决。

## 离线重放

请先按仓库数据目录的说明合并分卷，将得到的 `margin9.boxes.xz` 放入解压目录，再运行下列命令。需要 Bash、Python 3.10 或更新版本、GNU sha256sum、gzip、diff 、xz 和支持 unsigned __int128 的 C++17 编译器。小点数单纯形证书另用 NumPy。全局验证程序只依赖 Python 标准库。建议预留数 GiB 内存；运行时使用系统临时目录。

```sh
bash reproduce.sh
```

脚本先检查源码、证书和参考输出的 SHA-256，再重建 Spring 单弦常数、全局端点覆盖、几何不等式、局部重排实例、九点严格余量以及四至八点辅助上界。每种输出都与归档记录逐行相等才成功。核心整数核验与候选搜索分开，重放无须联网或重新搜索。单独核验全局界可运行 `python3 -B verify_global.py global.json`。

## 各文件做什么

- `proof.md` 为完整中文证明稿源文件，含曲线规格、兼容性引理、预算推导、删点证明和障碍实例。配套 PDF 单独交付，`PDF-SHA256.txt` 记录其摘要。`print-style.html` 为排版样式。
- `spring_base.py` 用有理数与整数计算 Spring 闭环的单弦常数。`curve_windows.py` 生成连续窗口，`budget.py` 计算各阈值的时间并集上界，`partners.py` 处理单个探测点，`reconnect.py` 对最多三个切口核对重连和预算，`verify_global.py` 遍历全部端点盒。
- `global.json` 中 `coefficients` 的前三项是放大 100 倍的基准率、目标率、探测距离因子，末项是长伴随间隙阈值 86。`rate_thresholds` 也放大 100 倍。每个记录前五项为块编号差、规范窗口编号、细分层数、两端子块编号。单探测记录的后缀为 `[d,w]`，固定双探测为 `[d,w,op,z,k]`，条件探测为 `["C",d,w,k,[[op,z,p],...]]`。方向由 d 表示，op 区分同侧和异侧，两次时间位置使用每基本块 8⁶ 单位的有符号整数；k 和 p 给出伴随矩形细分深度。核验器重新覆盖每个矩形内所有连续弦。拒绝缺失、多余和未解的端点记录。
- `margin9.boxes.xz` 是独立的九点有界分枝森林，首行为 `MDS41MARGIN9 9`。每一后续行先给九个根盒编码，随后为二叉树的前序记号。负数 −1−3i−k 沿第 i 点第 k 轴二等分；0 调用奇偶角盒论证；正整数是固定巡回的一基编号。`verify9.cpp` 独立重建等距轨道、根盒总数、巡回表及其向上取整边权，再对固定巡回和整盒顶点做最大值动态规划。它验证 4,898,208 种根签名、103,991 个互不相交的根轨道和 2,129,077 个全覆盖叶；其中 664 个由角盒解析不等式完成。
- `verify_structures.py` 验证刚性余量、近双点及九簇的常数比较、两点插入半径、同时换边的小规模交叉检查，以及 `trap.json` 和 `trap4.json` 两个八点例子的单调区间界。相容性对任意规模的保证由正文第 2 节证明。`small/` 包含四至六点单纯形证书、七至八点闭盒森林和对应的整数核验器。
- `global.log`、`curve.log`、`structures.log`、`nine.log`、`small/finite.log` 是独立核验记录。`strengthen.log` 记录九点证书构造中的替换叶数。`SHA256SUMS` 覆盖本包内除清单本身外的全部材料。

## 可选的重新构造

`partition.json` 仅给出端点划分以及按块编号差共用的 34 个候选提示。它没有为 338 个端点记录逐项指定操作。用以下命令重新分配或搜索探测点，再核验所得策略。以这条命令另行生成并已完整重放的第二张策略表见 `rediscovered.json` 及 `rediscovered.log`。两份策略表使用不同的探测点分配，得到同一个上界。

```sh
python3 -B discover.py partition.json new-global.json
python3 -B verify_global.py new-global.json
```

从旧九点森林重建加强版时可运行下列命令。旧森林可从上一份多尺度预印本的数据目录合并 `n9.boxes.xz.part-*` 取得，只供加速构造，完整验证直接读取 margin9.boxes.xz。每条管道均应在启用 pipefail 的 Bash 中执行。

```sh
set -o pipefail
c++ -O2 -std=c++17 strengthen9.cpp -o ./build-nine
c++ -O2 -std=c++17 verify9.cpp -o ./check-nine
xz -dc n9.boxes.xz | ./build-nine | gzip -1 -n > rebuilt-nine.gz
gzip -dc rebuilt-nine.gz | ./check-nine
```

`find_three_cut_example.py` 和 `find_four_cut_example.cpp` 是两个局部障碍的有限候选搜索。前者接收候选 JSON 输出路径；后者从标准输入读取按四层 Spring 块顺序排列的 4,096 个中心坐标分子（公分母 32）。搜索的浮点比较仅用于挑选候选。两份交付实例的结论完全由 `verify_structures.py` 的整数根式区间与全排列枚举验证。
