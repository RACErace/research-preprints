"""Outward rational comparisons, the Spring-sorted witness, and a reconnection regression."""
from fractions import Fraction as Q
from math import isqrt
from itertools import product, combinations
from pathlib import Path
import json
import curve_windows as curve
from reconnect import MOVES


def need(condition):
    if not condition:raise ArithmeticError("verification failed")


def bounds(x,n=10**12):
    x=Q(x)
    k=isqrt(x.numerator*n*n//x.denominator)
    return Q(k,n),Q(k+(k*k*x.denominator<x.numerator*n*n),n)


def constants():
    rt2,rt2hi=bounds(2)
    delta=725*rt2/8192
    dhi=725*rt2hi/8192
    for R in [Q(2,25),Q(1,4)]:
        s=bounds(2+R*R)[1]
        simp=(Q(4,3)*R*(1-R)-8*R**3)*rt2-R**2*s/2
        need(simp>dhi)
    R=Q(1,4)
    need(3*((2+R*R)*bounds(2+R*R)[1]+17*R**3)<8*rt2-dhi)
    stable=Q(4,3)*(1-R)*rt2-R*bounds(2+R*R)[1]/2-17*R**2
    need(stable>Q(1,6))
    d=Q(3,14)
    merge=d**3+Q(3,2)*d*d*bounds(3-d+d*d/4)[1]
    need(merge<delta)
    r=Q(1,33)
    cluster=9*17*(2*r)**3+18*(3*bounds(3)[1]+4*r)*r*r
    need(cluster<delta and Q(2,25)+4*r<R)
    q=Q(17,100)
    need(Q(1,4)+3*q*q+Q(82,5)*(2*q)**3<1)
    for x,direction in [(Q(39299675,10**8),-1),(Q(39299676,10**8),1)]:
        cost=4*(Q(1,4)+x*x)**3-(1-8*x**3)**2
        need(1-8*x**3>0 and direction*cost>0)
    print("margin > 0.12515928", "pair increase < 0.12503608", "nine-cloud increase < 0.12194994")
    need(delta>Q(12515928,10**8) and merge<Q(12503608,10**8) and cluster<Q(12194994,10**8))
    print("sharp two-point ball radius in (0.39299675, 0.39299676)")


def trap():
    data=json.loads(Path(__file__).with_name("trap.json").read_text())
    cells=curve.spring.TOP
    for k in range(1,data["depth"]):cells=curve.expand(cells)
    ids=data["slots"];p=data["points"];den=data["denominator"]
    need(den==2**(data["depth"]+1) and sorted(set(ids))==ids)
    need(p==[[2*q+1 for q in cells[i][0]] for i in ids])
    n=len(p);precision=10**10
    def edge(i,j):
        m=sum((a-b)**2 for a,b in zip(p[i],p[j]))
        low,high=bounds(m**3,precision)
        return low/den**3,high/den**3
    min_change=Q(1000);moves=0
    for a,b in combinations(range(n),2):
        c,e=(a+1)%n,(b+1)%n
        if c==b or e==a:continue
        increase=edge(a,b)[0]+edge(c,e)[0]-edge(a,c)[1]-edge(b,e)[1]
        min_change=min(increase,min_change);moves+=1
    cuts=data["cut"];added=data["added"];need(len(set(cuts))==3)
    edges=[(i,(i+1)%n) for i in range(n) if i not in cuts]+added
    need(tour(n,edges))
    gain=sum(edge(i,(i+1)%n)[0] for i in cuts)-sum(edge(i,j)[1] for i,j in added)
    need(moves==20 and min_change>Q(149,10000) and gain>Q(6782,10000))
    print("Spring order witness: 20 strict two-edge increases > 0.0149, three-edge gain > 0.6782")


def four_cut_trap():
    from itertools import permutations
    d=json.loads(Path(__file__).with_name("trap4.json").read_text())
    cells=curve.spring.TOP
    for level in range(1,d["depth"]):cells=curve.expand(cells)
    ids=d["slots"];p=d["points"];n=len(p);den=d["denominator"]
    need(den==2**(d["depth"]+1) and sorted(set(ids))==ids)
    need(p==[[2*x+1 for x in cells[i][0]] for i in ids])
    def edges(a):return {tuple(sorted((x,y))) for x,y in zip(a,a[1:]+a[:1])}
    old=edges(list(range(n)))
    weights={}
    for i,j in combinations(range(n),2):
        ds=sum((a-b)**2 for a,b in zip(p[i],p[j]))
        lo,hi=bounds(ds**3,10**10)
        weights[(i,j)]=(lo/den**3,hi/den**3)
    counts={2:0,3:0}
    for t in permutations(range(1,n)):
        if t[0]>t[-1]:continue
        e=edges((0,)+t);cnt=len(old-e)
        if cnt not in counts:continue
        rise=sum(weights[x][0] for x in e-old)-sum(weights[x][1] for x in old-e)
        need(rise>Q(499,10000));counts[cnt]+=1
    target=d["order"];need(sorted(target)==list(range(n)))
    e=edges(target);need(len(old-e)==4)
    gain=sum(weights[x][0] for x in old-e)-sum(weights[x][1] for x in e-old)
    need(counts=={2:20,3:96} and gain>Q(3447,10000))
    print("second Spring order: all 20 two- and 96 three-edge neighbors cost > 0.0499 more; four-cut gain > 0.3447")


def secondary_chord():
    # At level 2, the eight-block word begins at index 3; the pivot is its third block.
    seq=curve.normalize(curve.expand(curve.spring.TOP)[3:11],2)
    need(seq==curve.small_words(3,2)[8])
    i,j=1771,14612
    a=curve.subcell(seq[2],i,4)
    b=curve.subcell(seq[5],j-3*4096,4)
    disp=tuple(y-x for x,y in zip(a[0],b[0]))
    u=tuple(int(x<0) for x in disp);v=tuple(1-z for z in u)
    t1=(i+curve.spring.corner_time(a[1],u))/4096
    t2=(j+curve.spring.corner_time(b[1],v))/4096
    dist2=Q(sum((abs(x)+1)**2 for x in disp),256)
    need(t1==Q(221,511) and t2==Q(1823,511) and dist2==14)
    rsq=dist2**3/(t2-t1)**2
    need(rsq==Q(179129006,641601))
    print("lag-three chord rate squared",rsq)


def tour(n,edges):
    neighbors=[[] for _ in range(n)]
    for i,j in edges:neighbors[i].append(j);neighbors[j].append(i)
    seen={0};q=[0]
    while q:
        for t in neighbors[q.pop()]:
            if t not in seen:seen.add(t);q.append(t)
    return all(len(v)==2 for v in neighbors) and len(seen)==n


def partitions(ids):
    if not ids:
        yield ()
        return
    yield from partitions(ids[1:])
    for k in (1,2):
        for selected in combinations(range(1,len(ids)),k):
            pos=(0,)+selected
            cuts=tuple(ids[j] for j in pos)
            parts=[ids[f+1:g] for f,g in zip(pos,selected+(len(ids),))]
            for rest in product(*(partitions(x) for x in parts)):
                yield (cuts,)+tuple(b for a in rest for b in a)


def compatibility():
    count=0
    need(len(MOVES)==4)
    for n in range(4,10):
        for blocks in partitions(tuple(range(n))):
            used={a for block in blocks for a in block}
            edges=[(i,(i+1)%n) for i in range(n) if i not in used]
            alternatives=[]
            for cuts in blocks:
                points=[a for i in cuts for a in (i,(i+1)%n)]
                choices=MOVES if len(cuts)==3 else [((0,2),(1,3))]
                alternatives.append([[(points[a],points[b]) for a,b in opt] for opt in choices])
            for moves in product(*alternatives):
                need(tour(n,edges+[e for m in moves for e in m]))
                count+=1
    print("supplemental simultaneous noncrossing two/three-cut checks",count)


if __name__=="__main__":
    constants();trap();four_cut_trap();secondary_chord();compatibility()
