// Bounded discovery of a three-exchange local minimum of the Spring order.
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <random>
#include <vector>
using namespace std;
struct Move { int size;array<int,4> del{},add{};vector<int> order; };
struct Result {vector<Move> small,four;};
Result routes(int n) {
  Result r; vector<int> ids(n); for(int i=0;i<n;++i)ids[i]=i;
  auto eid=[](int i,int j){return min(i,j)*10+max(i,j);};
  bool old[100]{};for(int i=0;i<n;++i)old[eid(i,(i+1)%n)]=true;
  do {
    if(ids[1]>ids.back())continue;
    bool e[100]{};for(int i=0;i<n;++i)e[eid(ids[i],ids[(i+1)%n])]=true;
    Move m;m.size=0;int plus=0;
    for(int k=0;k<100;++k){
      if(old[k]&&!e[k]){if(m.size<4)m.del[m.size]=k;++m.size;}
      if(e[k]&&!old[k]){if(plus<4)m.add[plus]=k;++plus;}
    }
    if(m.size==0||m.size>4)continue;
    m.order=ids;
    if(m.size<4)r.small.push_back(m);else r.four.push_back(m);
  }while(next_permutation(ids.begin()+1,ids.end()));
  stable_sort(r.small.begin(),r.small.end(),[](auto&a,auto&b){return a.size<b.size;});
  return r;
}
int main(){
  vector<array<int,3>> points;int x,y,z;while(cin>>x>>y>>z)points.push_back({x,y,z});
  if(points.size()!=4096)return 2;
  Result all[10];all[8]=routes(8);all[9]=routes(9);
  mt19937 gen(892241);double best=0;
  for(int round=0;round<240000;++round){
    int n=8+gen()%2;vector<int> slots(n);
    for(int i=0;i<n;i++){int id;do{id=gen()%4096;}while(find(slots.begin(),slots.begin()+i,id)!=slots.begin()+i);slots[i]=id;}
    sort(slots.begin(),slots.end());double w[100]{};
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
      int sq=0;for(int k=0;k<3;k++){int d=points[slots[i]][k]-points[slots[j]][k];sq+=d*d;}
      w[i*10+j]=sq*sqrt((double)sq);
    }
    auto gain=[&](const Move&m){double v=0;for(int i=0;i<m.size;i++)v+=w[m.del[i]]-w[m.add[i]];return v/32768.;};
    bool ok=true;for(auto&m:all[n].small)if(gain(m)>-0.00008){ok=false;break;}
    if(!ok)continue;
    for(auto&m:all[n].four){
      double g=gain(m);if(g>best){
        best=g;cout<<"sample "<<round<<" n "<<n<<" gain "<<g<<" slots";
        for(int i:slots)cout<<' '<<i;cout<<" order";for(int i:m.order)cout<<' '<<i;cout<<'\n';
      }
    }
    if(best>.32)break;
  }
}
