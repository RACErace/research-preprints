"""Find a rational Spring-sorted local minimum under two-edge exchanges."""
import itertools,random,sys
import spring_base as curve
import curve_windows as v
from math import isqrt
from pathlib import Path
import json
rng=random.Random(4831)
word=curve.TOP
for _ in range(3):word=v.expand(word)
points=[tuple(2*c+1 for c in p) for p,state in word] # denominator 32
best=0
for case in range(110000):
    n=rng.randrange(6,10)
    ids=sorted(rng.sample(range(len(word)),n))
    P=[points[i] for i in ids]
    w=[[sum((a-b)**2 for a,b in zip(x,y))**1.5 for y in P] for x in P]
    gain=0
    for a in range(n):
        for b in range(a+2,n):
            c,d=(a+1)%n,(b+1)%n
            if d==a:continue
            gain=max(gain,w[a][c]+w[b][d]-w[a][b]-w[c][d])
    if gain>1.e-7:continue
    for i,j,k in itertools.combinations(range(n),3):
        cuts=(i,j,k)
        paths=[((s+1)%n,t) for s,t in zip(cuts,(j,k,i))]
        old=sum(w[s][(s+1)%n] for s in cuts)
        for f in itertools.product((0,1),repeat=3):
            block=[pair[::-1] if b else pair for pair,b in zip(paths,f)]
            added=[(block[h][1],block[(h+1)%3][0]) for h in range(3)]
            d=old-sum(w[s][t] for s,t in added)
            if d/32**3>best:
                best=d/32**3
                data=dict(depth=4,denominator=32,slots=ids,points=P,cut=cuts,added=added)
                Path(sys.argv[1]).write_text(json.dumps(data,separators=(",",":"))+"\n")
    if best>.42:break
print("searched",case+1,"best saving",best)
