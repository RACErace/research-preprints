#set document(title: "The dimension scale of equal-demand Gilbert–Steiner stars")
#set page("a4", margin: (x: 24mm, top: 17mm, bottom: 17mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 10.4pt)
#set par(justify: true, leading: .59em, spacing: .62em)
#set heading(numbering: none)
#show heading.where(level: 2): set text(fill: rgb("#19354a"))
#align(center)[
  #text(19pt, weight: "bold", fill: rgb("#19354a"))[The dimension scale of equal-demand #linebreak() Gilbert–Steiner stars]
  #v(.5em)
  #text(9pt)[Research note · 26 November 2026]
]
#v(.75em)
#block(inset: 11pt, fill: rgb("#eef4f7"), radius: 3pt)[
  *Abstract.* In dimension $d$, the maximal number of sinks in a minimum-cost single-source Gilbert–Steiner star with equal demands, allowing the power $p in (0,1)$ to vary, is $exp(Theta(d))$. The upper bound applies more generally whenever the largest sink demand is at most a fixed multiple of the smallest. The lower bound uses balanced sign vectors in a narrow cone and powers approaching one. The star has a genuine nonterminal branch, with degree one greater than its number of sinks.
]
== Setting.
<setting.>
An edge carrying mass $m$ has cost $m^p$ times its Euclidean length. We
consider a star from one source to $n$ sinks, all edges of positive
length. Normalize total demand to $1$ and denote the individual demands
by $q_i > 0$. Let $u_i$ be the unit direction from the center to sink
$i$, and $- e$ the direction to the source. The balance and no-splitting
criterion for optimality is
$ sum_(i = 1)^n q_i^p u_i = e , #h(2em) norm(sum_(i in I) q_i^p u_i) lt.eq (sum_(i in I) q_i)^p quad (I subset.eq { 1 , dots.h , n }) . quad (1) $
This is the one-sink criterion of Volz et al. [1] with all
flows reversed. The necessity also follows by moving the center or
splitting off any subset at a nearby branch. To see sufficiency, root a
competing tree at the source $x_0$ and let $I$ be the downstream sinks
along an edge of displacement $h$. Its cost is at least
$h dot.op sum_(i in I) q_i^p u_i$. These linear lower bounds telescope
to $sum_i q_i^p u_i dot.op (x_i - x_0)$, exactly the star’s cost by
balance. It is enough to compare to trees by concavity of the edge cost
[1].

Let $N_K (d)$ be the supremum of the sink count in such optimal stars in
$bb(R)^d$ over all powers $0 < p < 1$ and mass ratios
$max_i q_i \/ min_i q_i lt.eq K$.

#block[
*Theorem 1.* #emph[For $K gt.eq 1$,
$ N_K (d) lt.eq lr([2 K (1 + 8 sqrt(K))^d])^(6 \/ 5) . $
For all sufficiently large $d$, $N_1 (d)$ is at least the largest even
integer not exceeding $exp ((d - 1) \/ 1024)$. Consequently, for each
fixed $K gt.eq 1$, $N_K (d) = exp (Theta_K (d))$.]

]
== Upper bound.
<upper-bound.>
Set $epsilon = 1 - p$, $A = sum_i q_i^p$, and $w_i = q_i^p \/ A$.
Jensen’s inequality gives $A lt.eq n^epsilon$. By
(1) the weighted mean is $e \/ A$,
so
$ sum_i w_i norm(u_i - e)^2 = 2 (1 - 1 \/ A) lt.eq 2 epsilon log n . $
Each $w_i gt.eq 1 \/ (K n)$ since the ratio of the powered demands is at
most $K^p lt.eq K$. For $n gt.eq 2$ at least half the $u_i$ therefore
lie within distance $R = min (2 , 2 sqrt(K epsilon log n))$ of $e$: this
follows by counting those outside the untruncated radius, and at radius
$2$ all directions are included.

Cover that ball by at most $(1 + 2 R \/ r)^d$ balls of radius
$r = R \/ (4 sqrt(K))$ by taking a maximal $r$-separated set and
comparing the volumes of its disjoint radius-$r \/ 2$ balls to the
ambient radius-$R + r \/ 2$ ball. If one cover ball contains $k$
directions, normalize their sink masses to $s_i$ with $sum s_i = 1$, and
let $v$ be the mean of those directions using weights proportional to
$s_i^p$. The weighted variance about $v$ is $1 - norm(v)^2$
and is at most the variance about the ball center, hence at most $r^2$.
But no-splitting gives $norm(v) lt.eq 1 \/ sum s_i^p$. Since
$s_i lt.eq K \/ k$ for all $i$, we have
$sum s_i^p gt.eq (k \/ K)^epsilon$. It follows that
$ log (k \/ K) lt.eq frac(- log (1 - r^2), 2 epsilon) lt.eq frac(2 r^2, 3 epsilon) lt.eq frac(log n, 6) . $
Here $r^2 lt.eq 1 \/ 4$ and $r^2 lt.eq epsilon log n \/ 4$. The cover
accommodates at most $(1 + 8 sqrt(K))^d K n^(1 \/ 6)$ directions and
must accommodate at least $n \/ 2$. Rearrangement gives the upper bound;
the case $n = 1$ is immediate.

#pagebreak()
== Lower bound: balanced directions.
<lower-bound-balanced-directions.>
Put $m = d - 1$ and let $n$ be the largest even integer at most
$exp (m \/ 1024)$. In $bb(R)^m$ choose $n \/ 2$ independent random sign
vectors divided by $sqrt(m)$ and adjoin their antipodes, giving a
labeled family $v_1 , dots.h , v_n$. We show that for large $m$ there is
an outcome such that every subset $I$ of size $2 lt.eq k < n$ satisfies
$ norm(frac(1,k) sum_(i in I) v_i)^2 < frac(log (n \/ k), log n) . quad (2) $
Concentration for a sum of independent signs implies that any two
independently sampled representatives have absolute inner product above
$1 \/ 4$ with probability at most $2 e^(- m \/ 32)$. Indeed
$bb(E) e^(t xi) lt.eq e^(t^2 \/ 2)$ for a random sign $xi$, and applying
this to the $m$ coordinate products and optimizing $t$ gives the bound.
Thus except with probability $2 n^2 e^(- m \/ 32)$, all pairs of
distinct labels \(including the antipodal pairs) have inner product at
most $1 \/ 4$, and no two directions coincide. For $2 lt.eq k < 256$ the
squared mean is at most $1 \/ 4 + 3 \/ (4 k) lt.eq 5 \/ 8$, strictly
less than $frac(3,4) frac(log(n \/ k), log n)$ for sufficiently large $m$.

For $256 lt.eq k lt.eq n \/ 2$, fix a particular labeled subset and
write $S = sum_(i in I) v_i$. Complete pairs cancel; in any unit
direction $z$, the remaining independent signs give
$ bb(E) e^(t z dot.op S) lt.eq e^(t^2 k \/ (2 m)) . $ A Euclidean
$1 \/ 2$-net of the unit sphere of size at most $5^m$ detects at least
half the norm by a positive projection. Such a net follows from the same
disjoint-ball volume argument used above. For $L = log (n \/ k)$, the
probability that $norm(S \/ k)^2 gt.eq 3 L \/ (4 log n)$ is
at most $ 5^m exp(- frac(3 m k L, 32 log n)) . $ There are at
most $exp (k (1 + L))$ subsets to test at size $k$. Half the negative
exponent is at least $48 k L$ because $log n lt.eq m \/ 1024$. Its other
half is at least $6 m$ for sufficiently large $m$: the concave function
$k log (n \/ k)$ has its minimum on $[256 , n \/ 2]$ at an endpoint, and
both endpoint values eventually exceed $128 log n$. The summed failure
probability is thus at most
$e^(- (6 - log 5) m) sum_(k gt.eq 256) e^(- k (47 log 2 - 1))$, tending
to zero. Together with the small-size event this proves
(2) for every $2 lt.eq k lt.eq n \/ 2$ in
a single outcome.

For $n \/ 2 < k < n$, put $j = n - k$ and $t = j \/ k in (0 , 1)$. The
complement sum is minus the subset sum, so that the squared mean is at
most $t^2 log (n \/ j) \/ log n$. For $j = 1$ this uses the exact
singleton norm $1$. The strict inequality
$ t^2 log (1 + 1 \/ t) < log (1 + t) $ follows by integrating
$t^2 \/ (t + x) < t \/ (1 + t x)$ for $0 < x lt.eq 1$. This proves
(2) also in the remaining range.

#pagebreak()
== Lower bound: the star.
<lower-bound-the-star.>
For $epsilon = 1 - p > 0$ let $a = n^(- epsilon)$ and lift each $v_i$ to
$u_i = (a , sqrt(1 - a^2) v_i)$ in $bb(R)^d$. Give every sink
demand $1 \/ n$, place it at $u_i$, and place the source at $- e_1$.
Balance holds exactly by antipodality. For a subset of size $k$,
(1) is equivalent to
$ norm(frac(1,k) sum_(i in I) v_i)^2 lt.eq frac(k^(- 2 epsilon) - n^(- 2 epsilon), 1 - n^(- 2 epsilon)) . $
For $2 lt.eq k < n$, the right hand side tends to
$log (n \/ k) \/ log n$ as $epsilon arrow.b 0$. By strictness in
(2) and finiteness of the family, all such
inequalities hold at once for some $epsilon > 0$. The singleton, empty
and full sets satisfy the original criterion with equality. Thus the
star is a global optimum, with degree $n + 1$ at the origin.

== Scope.
<scope.>
The cost power $p$ may depend on $d$ in the construction. This is different
from the fixed-power question in [3, 4]. The
comparability restriction is substantive: allowing arbitrary demand
ratios and varying the power yields unbounded branch degrees even in
dimension three [5], answering the dimension-only question in [2]. The present bounds
concern single-source stars, not arbitrary many-source configurations
with equal terminal demands.

== Disclosure.
<disclosure.>
AI assistance was used in proving, checking and preparing this note.


== References
[1] Volz, Brazil, Ras, Swanepoel and Thomas. #link("https://arxiv.org/html/0909.4270v2")[The Gilbert Arborescence Problem], §3 (2012 version).

[2] Cherkashin. #link("https://arxiv.org/html/2507.13532v1#S6")[On branching points in the Gilbert–Steiner problem], §6 (2025).

[3] Teplitskaya. #link("https://arxiv.org/html/2611.03403v1#S1")[Open problems from the Length Optimization event at MDS 2026], §1 (2026).

[4] #link("https://github.com/RACErace/research-preprints/blob/main/gilbert-steiner-degrees.pdf")[Branching degrees in high-dimensional Gilbert–Steiner problems] (2026).

[5] #link("https://github.com/RACErace/research-preprints/blob/main/gilbert-steiner-unbounded.pdf")[Unbounded branching degree in three-dimensional Gilbert–Steiner flows] (2026).
