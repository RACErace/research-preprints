# The dimension scale of equal-demand Gilbert–Steiner stars

`main.typ` is the complete source. To build, run `typst compile main.typ paper.pdf` with Typst and its Libertinus fonts. The result is an analytic proof; no numerical or randomized execution is required to verify it. The random-sign argument is an existence proof.

Scope: single-source stars, cost power free to vary in (0,1). The comparable-demand upper bound is uniform in the power. The lower bound uses equal demands. This is not a fixed-power estimate or a bound for arbitrary demand ratios.
