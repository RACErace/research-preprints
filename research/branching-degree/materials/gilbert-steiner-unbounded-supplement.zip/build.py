import typst
typst.compile("main.typ", output="gilbert-steiner-unbounded.pdf")
