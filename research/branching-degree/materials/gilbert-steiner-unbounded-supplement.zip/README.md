# Unbounded branching degree: editable source

This is a self-contained analytic proof with no numerical inputs. The audit independently checks its key expansion and records the scope and prior literature.

With Typst 0.15.2, run:

    typst compile main.typ gilbert-steiner-unbounded.pdf

Alternatively install the Python package typst==0.15.2 and run python build.py.
