# Proof and priority checks

## Proof reread

The quantifier is: for each finite N, choose the distinct transverse directions, then fix p in a sufficiently small left neighborhood of 1, then choose the positive light mass. The limit in the proof is at fixed p, never uniform in p.

An independent check of the expansion uses the Gram formula. With weighted light vectors w_i=t^p v_i, their dot products satisfy w_i·w_j/t^(2p)→u_i·u_j, while each e·w_i=p t+(b−α_i)t^(2p) exactly. Therefore the squared norm of e+Σ_{i∈I} w_i is 1+2p|I|t+t^(2p)[2|I|b−2Σ_{i∈I}α_i+Σ_{i,j∈I}u_i·u_j+o(1)]. The Taylor remainder in the squared budget is O(t²), negligible at fixed p<1. The mass-one sink does not contribute to the transverse Gram term, and the full sum's coefficient vanishes at b=0. The bound is uniform for b in [-1,1], so the sign change gives an exact zero. A proper nonempty light subset has a strictly positive cut sum; all these finite inequalities survive the chosen balance perturbation. The separate light-only constraints follow from the strict triangle inequality before perturbation. This accounts for all subsets, including the empty set and the heavy-only set.

For global rather than local optimality, delete cycles by concavity and root an arbitrary feasible tree at the only source. Each edge carries exactly the sum of the masses of descendant sinks. Dot the weighted sum of the descendants' star directions with that oriented edge displacement and apply the subset norm criterion. Sum and regroup by sink. With balance, the result is the cost of the original star, so all competitors cost at least this much.

The ratio-dependent proposition uses Jensen's inequality for A≤N^(1−p), the pointwise weight lower bound 1/(KN), and Euclidean volume comparison after using both balance and the two-sink inequalities.

## Source and novelty

- [Cherkashin, §6, picture in high dimensions](https://arxiv.org/html/2507.13532v1#S6): explicitly asks for an upper bound depending only on dimension, and does not settle this. His earlier degree d+1 example at p≥1/2 is not unbounded at fixed d.
- [MDS 2026 length optimization problem list, §1](https://arxiv.org/html/2611.03403v1#S1): repeats that separate question after Question 1.2, which is the fixed-power question. The previous paper in this archive treated fixed powers only.
- [Volz et al., Theorem 1 and §5](https://arxiv.org/html/0909.4270v2): prior source for the star criterion and three-dimensional degree-four examples for their cost family, not arbitrarily large branching degrees in fixed dimension for pure power costs.
- [Cherkashin and Petrov](https://arxiv.org/abs/2309.04202): the planar result remains degree three; the construction needs a two-dimensional plane transverse to the heavy direction.
- Checked by source IDs and versions, author pages, model names, the two quantifier orders, the high-imbalance/single-source variant and public GitHub references on 26 November 2026 (UTC). No matching proof or counterexample was found. This is a preprint, not an independent priority guarantee.
