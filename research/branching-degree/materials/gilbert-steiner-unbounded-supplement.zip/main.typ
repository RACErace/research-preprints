#set document(title: "Unbounded branching degree in three-dimensional Gilbert–Steiner flows")
#set page(paper: "a4", margin: (x: 25mm, y: 24mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: .62em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#align(center)[
#text(size: 21pt, weight: "semibold")[Unbounded branching degree in \ three-dimensional Gilbert–Steiner flows]
#v(3pt)
#text(size: 9pt, fill: luma(95))[26 November 2026 · Research preprint, version 1.0]
]

*Abstract.* There is no upper bound depending only on dimension for the degree of an interior branching point in Euclidean Gilbert–Steiner transport with power costs $m^p$, $0<p<1$. Already in three dimensions an optimal single-source star can have arbitrarily many edges incident at its center, with one large sink and arbitrarily many sinks of an identical small mass. For each requested degree the construction works for every $p<1$ sufficiently close to one, with the small mass then chosen in terms of $p$. In contrast, a bound depending only on dimension and the sink-mass ratio holds for single-source stars whose sink masses are comparable.

= Setting and statement

For a finite flow the cost of an edge of length $L$ carrying mass $m$ is $L abs(m)^p$. The cost of the flow is the sum of its edge costs. A branching point here is not a prescribed source or sink. Cherkashin asks if an upper bound on the branching degree can depend only on dimension, uniformly over the power parameter \[1, §6\]. The question is repeated in the 2026 Sofia length-optimization problem list \[2, §1\]. It is distinct from Question 1.2 in that list, which asks for asymptotic estimates at a _fixed_ power.

*Theorem 1.* For every integer $n>=2$, and every $p<1$ sufficiently close to $1$ in terms of $n$, there are a source and $n+1$ sinks in $bb(R)^3$ for which the Gilbert–Steiner problem admits an optimal star of degree $n+2$. All terminals are distinct, and exactly $n$ sinks have the same small mass. In particular, no dimension-only bound exists, even in the single-source class.

We use the optimal-star criterion of Volz et al. \[3, Theorem 1\] with source and sink interchanged. If the sinks have masses $m_i$, unit directions $v_i$ from the center, and the source direction is $v_*$ with mass $M=sum_i m_i$, the required conditions are
$ sum_i m_i^p v_i + M^p v_* = 0, quad
  norm(sum_(i in I) m_i^p v_i) <= (sum_(i in I) m_i)^p
  quad "for every sink subset" I. $ <criterion>
They guarantee global optimality, not merely stability under a small movement of the center. One can see sufficiency by rooting any cycle-free competitor at its source, then applying the subset inequality to the descendant sinks on each edge. The resulting lower bounds telescope to the cost of the star by the balance identity. A competitor can be taken cycle-free since cost along a cycle is concave in the signed circulation on the interval up to the next vanishing edge, so some endpoint has no greater cost.

= A large sink and tiny sinks

Let $e$ be a unit vector in $bb(R)^3$. Choose $n$ distinct transverse unit vectors $u_1,dots,u_n$ in $e^perp$ in an arc of angular width less than $pi/2$. Thus $chevron.l u_i,u_j chevron.r>0$ for all $i,j$. For each subset $I$ put $U_I=sum_(i in I)u_i$; write $U=sum_i u_i$ and $alpha_i=chevron.l u_i,U chevron.r/2$. In particular $2sum_i alpha_i=norm(U)^2$.

For $2<=abs(I)<=n$, strict triangle inequality gives $norm(U_I)<abs(I)$. There are finitely many such subsets. Therefore there exists $p_0 in (1/2,1)$ such that for every $p in (p_0,1)$,
$ norm(U_I)<abs(I)^p quad (2<=abs(I)<=n). $ <light-limit>

Fix any such $p$. Put a mass-one sink in direction $e$ and $n$ mass-$t$ sinks in unit directions
$ A_i=p t^(1-p)+(b-alpha_i)t^p, quad
  v_i=A_i e+sqrt(1-A_i^2)u_i, $ <direction>
where $t>0$ is small and $b in [-1,1]$ will enforce exact balance. All quantities below are for fixed $p,n$, with estimates uniform in that bounded interval of $b$. Then $A_i=o(1)$ as $t arrow.r 0$.

For a subset incorporating the large sink and the tiny sinks indexed by $I$, write $k=abs(I)$. The axial component of $e+t^p sum_(i in I)v_i$ is exactly $1+p k t+t^(2p)(k b-sum_(i in I)alpha_i)$; its transverse component is $t^p(U_I+o(1))$. Consequently
$ (norm(e+t^p sum_(i in I)v_i)^2-(1+k t)^(2p))/t^(2p)
  =2 k b-2sum_(i in I)alpha_i+norm(U_I)^2+o(1). $ <expansion>
Indeed the quadratic terms in the axial expansion and the second-order remainder in $(1+k t)^(2p)$ are $O(t^2)=o(t^(2p))$. Square-root continuity gives the uniform transverse estimate.

For the full set $I=[n]$ the right hand side of @expansion is $2 n b+o(1)$. For small $t$ it has opposite signs at $b=-1$ and $b=1$. Continuity thus gives an exact zero $b=b(t)$; the same uniform estimate forces $b(t)=o(1)$. Define the source direction to be
$ v_*=- (e+t^p sum_(i=1)^n v_i)/(1+n t)^p. $
The zero condition makes this a unit vector and verifies balance.

For a nonempty proper $I subset [n]$, the right hand side of @expansion now tends to
$ norm(U_I)^2-chevron.l U_I,U chevron.r = -chevron.l U_I,U-U_I chevron.r < 0. $
The inequality is strict because all the cross inner products are positive. Thus the squared norm is below the squared cost for every subset containing the large sink along with a proper, nonempty set of tiny sinks when $t$ is sufficiently small. The heavy-only and full subsets give equality. For a subset of just the tiny sinks, divide the subset inequality in @criterion by $t^p$; inequality @light-limit and $v_i arrow.r u_i$ settle every nonsingleton, and each singleton gives equality. The empty subset is automatic. Finiteness gives one choice of small $t$ valid for all subsets at once. The source approaches $-e$, the large sink is at $e$, and the tiny sink directions approach the distinct transverse directions. Take all terminals at distance one from the center. They are distinct for small $t$, so the center is a genuine interior branching point. This proves the theorem.

#pagebreak()
= Why comparable demands behave differently

*Proposition 2.* For single-source stars with $N$ sinks of positive masses having ratio at most $K>=1$, $1/2<=p<1$, the sink count satisfies
$ N/2 <= (1+2sqrt(K log(N)/log(1+1/K)))^d. $
In particular it is bounded in terms of $d,K$ alone. For equal masses the stronger $N/2<=(1+2sqrt(log(N)))^d$ holds.

Normalize sink masses to $q_i$ with $sum_i q_i=1$, put $epsilon=1-p$, $A=sum_i q_i^p<=N^epsilon$, and let $W_i=q_i^p/A>=1/(K N)$. Balance gives $sum_i W_i v_i=e'/A$ for a unit vector $e'$. Hence $sum_i W_i norm(v_i-e')^2=2(1-1/A)<=2epsilon log(N)$. At least half the directions are in the ball about $e'$ of radius $2sqrt(K epsilon log(N))$.

For two sinks put $x=q_i/(q_i+q_j)$, $S=x^p+(1-x)^p$. Since $x,1-x<=K/(K+1)$, expansion of each exponential gives $S>=1+epsilon log(1+1/K)$. The two-sink subset condition implies
$ norm(v_i-v_j)^2 >= (S^2-1)/(x^p(1-x)^p)
 >= 4epsilon log(1+1/K), $
using $(x(1-x))^p<=1/2$. The balls of radius $sqrt(epsilon log(1+1/K))$ about those nearer directions are disjoint in their interiors; compare their total volume to that of the enlarged ball about $e'$. For $K=1$, the pair bound improves to $4(1-2^(-2epsilon))>=4epsilon$ by concavity on $[0,1/2]$, giving the sharper claim. Exponential growth in $log(N)$ beats any fixed power of $sqrt(log(N))$, so both implicit bounds are finite.

*Scope.* The theorem varies $p$ towards one and allows the mass ratio to diverge. It does not contradict bounds for any fixed $p$, or planar degree three \[4\]. All arguments are analytic. AI assistance was used in developing and checking this preprint; it has not received external peer review.

#heading(numbering: none)[References]

\[1\] D. Cherkashin, _On branching points in the Gilbert–Steiner problem_, #link("https://arxiv.org/html/2507.13532v1#S6")[arXiv:2507.13532], 2025.

\[2\] Y. Teplitskaya (ed.), _Open problems from the Length Optimization event at MDS 2026_, #link("https://arxiv.org/html/2611.03403v1#S1")[arXiv:2611.03403], 2026.

\[3\] M. G. Volz et al., _The Gilbert arborescence problem_, Networks 61 (2013), 238–247, #link("https://arxiv.org/html/0909.4270v2#S3")[arXiv:0909.4270].

\[4\] D. Cherkashin and F. Petrov, _Branching points in the planar Gilbert–Steiner problem have degree 3_, Pure and Applied Functional Analysis 10 (2025), 331–338, #link("https://arxiv.org/abs/2309.04202")[arXiv:2309.04202].
