# 零长度 Farey 端点集的逆恢复
工作论文，未经同行评审。AI 辅助研究。原问题见 [MDS §5.7](https://arxiv.org/html/2611.03403v1#S5.SS7)。

- `proof.md`：完整可编辑证明，包括无穷尾项的分离界。
- `python3 verify.py --depth 13`：标准库，使用精确有理数重放 16,383 个胞的有限检查。不代替定理证明。
- `python3 render_pdf.py --chromium /path/to/chromium-headless-shell --output proof.pdf`：重建 PDF；需要 Pandoc、Python Playwright、Chromium、Noto CJK 字体与数学字体。
