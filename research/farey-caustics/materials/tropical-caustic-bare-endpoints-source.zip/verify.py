"""Exact checks for the MDS 5.7 bare endpoint supplement. Python standard library only."""
import argparse
from fractions import Fraction as F
from itertools import combinations, product
from math import gcd, log

RHO = F(1, 16)
GAMMA = RHO ** 2
EPS = F(1, 1024)
HIGH = F(5, 4)
LOW = F(3, 4)
ROOT = ((0, 1), (1, 0))
WORDS = ("LL", "LR", "RL", "RR")
MATRICES = {
    "LL": ((1, 2), (0, 1)),
    "LR": ((2, 1), (1, 1)),
    "RL": ((1, 1), (1, 2)),
    "RR": ((1, 0), (2, 1)),
}


def add(p, q):
    return p[0] + q[0], p[1] + q[1]


def sub(p, q):
    return p[0] - q[0], p[1] - q[1]


def scale(factor, p):
    return factor * p[0], factor * p[1]


def rot(p):
    return -p[1], p[0]


def dot(p, q):
    return p[0] * q[0] + p[1] * q[1]


def norm(p):
    return max(abs(x) for x in p)


def t(u):
    return F(u[0], sum(u))


def digits(alpha, left, right):
    return {
        "LL": (alpha + left, 0),
        "LR": (alpha - left, -left),
        "RL": (right, right - alpha),
        "RR": (0, -alpha - right),
    }


def actual_two_steps(word, alpha, left, right, u, v):
    common_parent = (F(0), F(0))
    for step, turn in enumerate(word):
        amount = alpha if step == 0 else (left if word[0] == "L" else right)
        w = add(u, v)
        if turn == "L":
            common_parent = add(common_parent, scale(amount, rot(u)))
            v = w
        else:
            common_parent = sub(common_parent, scale(amount, rot(v)))
            u = w
    return common_parent, u, v


def check_blocks():
    for matrix in MATRICES.values():
        assert max(sum(map(abs, row)) for row in matrix) <= 3
    bound = 4 * EPS + 6 * (F(9, 4) + 2 * EPS) / 253
    assert bound < F(1, 16)
    assert F(1353, 55) < 25 and F(27, 5) < 6
    assert 2 * (LOW - EPS) > 1 + EPS and HIGH - EPS > 1 + EPS
    for kappa in (LOW, HIGH):
        ideal = digits(1, kappa, kappa)
        for errors in product((-EPS, EPS), repeat=3):
            alpha, left, right = (1 + errors[0], kappa + errors[1], kappa + errors[2])
            coordinates = digits(alpha, left, right)
            for word in WORDS:
                assert norm(sub(coordinates[word], ideal[word])) <= 2 * EPS
                matrix = MATRICES[word]
                for u, v in (ROOT, ((1, 13), (1, 12)), ((9, 7), (4, 3))):
                    position, a, b = actual_two_steps(word, alpha, left, right, u, v)
                    assert a == add(scale(matrix[0][0], u), scale(matrix[1][0], v))
                    assert b == add(scale(matrix[0][1], u), scale(matrix[1][1], v))
                    c, d = coordinates[word]
                    assert position == rot(add(scale(c, u), scale(d, v)))
        for i, j in combinations(WORDS, 2):
            c, d = sub(ideal[i], ideal[j])
            assert min(abs(c), abs(d)) >= F(1, 4)
            assert max(abs(c), abs(d)) <= F(5, 2)
            if c * d < 0:
                assert kappa == HIGH and {abs(c), abs(d)} == {1, F(1, 4)}
                # At these corners, the balanced-cone denominator estimate
                # 15U-5V >= 5U (or its symmetric counterpart) is sharpest.
                for dc, dd, ratio in product((-F(1, 16), F(1, 16)),
                                             (-F(1, 16), F(1, 16)), (F(1, 2), F(2))):
                    C, D = c + dc, d + dd
                    assert abs(C) * ratio + abs(D) <= F(27, 5) * abs(C * ratio + D)
    return bound


def potency(n):
    return GAMMA ** (n // 2) * (HIGH if n % 2 else 1)


def tail(n):
    block_scale = GAMMA ** (n // 2)
    first_tail = (1 + HIGH) / (1 - GAMMA)
    return block_scale * (first_tail if n % 2 == 0 else HIGH + GAMMA * first_tail)


def check_nodes(depth):
    # G is derived by signed translations; c(u), c(v) evolve separately.
    level = [(ROOT[0], ROOT[1], (F(2), F(2)), F(2), F(2))]
    checked = 0
    for n in range(depth + 1):
        children = []
        a, total, following = potency(n), tail(n), tail(n + 1)
        assert total == a + following
        for u, v, G, cu, cv in level:
            w = add(u, v)
            cw = cu + cv - a
            assert dot(u, G) == cu and dot(v, G) == cv
            U, V = sum(u), sum(v)
            assert v[0] * U - u[0] * V == 1 and gcd(U, V) == 1
            assert t(v) - t(u) == F(1, U * V)
            gl, gr = add(G, scale(a, rot(u))), sub(G, scale(a, rot(v)))
            false_left = add(G, scale(total, rot(u)))
            false_right = sub(G, scale(total, rot(v)))
            true_left = sub(gl, scale(following, rot(w)))
            true_right = add(gr, scale(following, rot(w)))
            assert len({false_left, false_right, true_left, true_right}) == 4
            assert dot(w, false_left) == dot(w, false_right) == cw - following
            assert dot(w, true_left) == dot(w, true_right) == cw
            assert sub(true_right, true_left) == scale(2 * following - a, rot(w))
            assert sub(false_right, false_left) == scale(-total, rot(w))
            if n == 0:
                assert total == F(192, 85)
                assert false_left == (-F(22, 85), 2)
                assert false_right == (2, -F(22, 85))
                assert true_left == (F(192, 85), F(63, 85))
                assert true_right == (F(63, 85), F(192, 85))
            if n % 2 == 0:
                # For either choice in (9), every even node has a reverse jump.
                kappa = HIGH if F(1, 2) <= F(U, V) <= 2 else LOW
                assert 2 * (kappa - EPS) > 1 + EPS
                # LR is an explicit future balanced witness from any even cell.
                assert 1 < F(2 * U + V, U + V) < 2
                assert F(1, 2) < F(U + V, U + 2 * V) < 1
            if n < depth:
                children.extend(((u, w, gl, cu, cw), (w, v, gr, cw, cv)))
            checked += 1
        level = children
    return checked


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--depth", type=int, default=12)
    depth = parser.parse_args().depth
    if depth < 0:
        parser.error("--depth must be nonnegative")
    error = check_blocks()
    count = check_nodes(depth)
    print(f"Exact vertex and parallel-pair checks passed for {count} cells (depths 0 to {depth}).")
    print(f"Certified coefficient error: {error} < 1/16.")
    print("Root offsets for w=(1,1): true 3, spurious 148/85.")
    print(f"Exceptional-direction dimension upper bound: 2 log(4)/log(256/3) = {2*log(4)/log(256/3):.9f}.")
