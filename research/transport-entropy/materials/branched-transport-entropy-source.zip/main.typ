#set document(title: "Quantized entropy and the near-linear branched transport cost")
#set page("a4", margin: (x: 23mm, top: 20mm, bottom: 21mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt)
#set par(justify: true, leading: .62em, spacing: .72em)
#set heading(numbering: "1.")
#show heading: set text(fill: rgb("#173c52"))
#align(center)[
  #text(23pt, weight: "bold", fill: rgb("#173c52"))[Quantized entropy and the \
    near-linear branched transport cost]
  #v(.4em)
  #text(10pt)[Research preprint (AI-assisted) · 27 November 2026]
]
#block(inset: 10pt, fill: rgb("#edf3f7"), radius: 3pt)[
  *Abstract.* Transport any probability law on the unit sphere from its center, or between identical parallel copies of a transverse law at distance one. As the price power $p$ tends to $1$, put $epsilon=1-p$. The optimal energy is $1+epsilon H(floor(Y \/ sqrt(epsilon)))+O(epsilon)$, with natural-log entropy and an error uniform over the endpoint law on a fixed support box. The coefficient of $epsilon log(1/epsilon)$ is half the information dimension when it exists. For uniform parallel slices this determines the coefficient beyond the previously known scaling order.
]

= Setting and statement
Use the Lagrangian cost of a traffic plan $bb(P)$, a probability measure on paths with prescribed endpoint laws. Let $theta(x)$ be the probability of visiting $x$ and $mu$ the mean arclength occupation, counting repeated visits. The energy is $cal(E)_p(bb(P))=integral theta^(-epsilon) dif mu$ and its infimum is $E_p$. Write $Q_h(Y)=floor(Y \/ h)$ for the coordinatewise grid index of $Y$ at spacing $h$, and $H_h(nu)=H(Q_h(Y))$ for its Shannon entropy in nats, when $Y$ has law $nu$.

- *Sphere.* The source is the origin and $nu$ is supported on $S^(d-1) subset bb(R)^d$, $d>=2$.
- *Parallel slices.* In $bb(R)^(k+1)$, $k>=1$, the endpoint laws are copies of $nu$ at heights zero and one, with $nu$ supported in a fixed bounded box in $bb(R)^k$. The plan need not pair the copies pointwise.

*Theorem.* Put $h=sqrt(epsilon)$. For sufficiently small $epsilon>0$, in either geometry
$ E_p=1+epsilon H_h(nu)+O(epsilon). $
Constants can depend on the fixed box and dimension but not on $nu$. For every fixed $M>=0$, all plans within $M epsilon$ of the infimum have mean length between $1$ and $1+C_M epsilon$ with the same uniformity. No uniform positive lower bound on the excess length is possible; a single atom travels straight.

= Upper bound
The construction uses hierarchical layers as in Brancolini and Wirth [1], retaining the coarse-cell probabilities in the estimate. In grid dimension $q$ ($d$ for the sphere, $k$ for the slices), let $p_i$ be the positive masses of grid cells of side $h$. Refine each cell dyadically. For each occupied cell choose a representative on the endpoint set in the closure of the cell. In the sphere case put level-$j$ representatives on the shell of radius $1-2^(-j-1)$, connect to their parents, and precede by radial trunks of length $1/2$. In the slices case put copies at distance $2^(-j-2)$ from each bounding plane and connect the coarse copies by vertical trunks of length $1/2$. Follow the lower tree in reverse and the upper tree forward to send each endpoint to its translated copy. The chains are measurable by the Borel assignment of cells and convergence of their polygonal tails.

The transverse displacement on an edge at depth $j$ is at most $C h$ times its nominal vertical spacing; the spherical case follows from $|r u-s v|^2=(r-s)^2+r s |u-v|^2$ for unit $u,v$. Thus edge lengths are at most $(1+C h^2)$ times their layer spacing, which sums with the trunks to baseline one. Actual multiplicity along an edge is at least its cell mass, so summing represented edge costs gives an upper bound even with overlap. Concavity bounds the sum of powered masses at level $j$ by $2^(j q epsilon) sum_i p_i^(1-epsilon)$. Summing the geometric series, for $q epsilon<1$ near zero,
$ E_p <= (1+C(epsilon+h^2)) sum_i p_i^(1-epsilon). $

There are at most $N<=C h^(-q)$ coarse cells. Under their law put $I=-log p_i$. Then $bb(P)(I>log N+t)<=e^(-t)$ for $t>=0$, by counting the at most $N$ cells with $p_i<e^(-t)/N$. Taylor's inequality gives a remainder at most $epsilon^2 bb(E)(I^2 e^(epsilon I))/2$ in the expansion of $bb(E)e^(epsilon I)$. Writing $I<=log N+(I-log N)_+$ and integrating the tail above shows that the moment is $O(e^(epsilon log N)(1+log^2 N))$ for $epsilon<=1/2$. Thus at $h=sqrt(epsilon)$ the sum is $1+epsilon H_h(nu)+O(epsilon)$ uniformly. Multiplication by the prefactor preserves this bound, since $epsilon H_h(nu)=O(epsilon log(1/epsilon))$.

= Lower bound
Let $D$ be the mean length minus one in any finite-energy plan. Length is at least one on each path. By finite-energy rectifiability [2], occupation is carried on a countably rectifiable set $S$ of sigma-finite length. For an unrestricted plan that leaves the bounded region one can obtain the same carrier directly: sampling $N$ independent path images misses at most a fraction $(1-a)^N$ in expectation of the occupation where $theta>=a$. A countable collection of finite samples with misses tending to zero, followed by the union over $a=1/n$, gives a countably rectifiable carrier. Where $theta=0$ the occupation vanishes because the energy is finite.

Let $X_r$ be the first point on a path at radius $r$ or height $r$, for $0<r<1$. This is measurable because first hitting times are specified by the running coordinate maximum on compact time intervals. The values $r$ whose first selected point lands in a fixed Borel portion of a path lie in its image under the $1$-Lipschitz radius or height map. Their Lebesgue measure is at most that portion's one-dimensional Hausdorff measure, and hence at most its arclength occupation. Thus the integrated first-crossing law is dominated by $mu$ and carried by $S$.

Coarea on $S$ gives countable sections $S_r$ for almost every $r$. The discrete law $alpha_r$ of $X_r$ satisfies $alpha_r(x)<=theta(x)$. Write $s_r=sum_(x in S_r) theta(x)$. Weighted coarea and the bound on each path's image length give
$ s_r>=1, quad integral_0^1 s_r dif r <= integral_S theta dif cal(H)^1 <= 1+D. $
Nonnegative relative entropy against the probability $theta/s_r$ on the slice gives
$ H(X_r) <= bb(E) log(1 \/ theta(X_r)) + log s_r. $
The right side is finite for almost every $r$ by finite energy and first-crossing domination; for a countable slice, aggregate the tail into one atom and use the finite inequality, then pass to the limit. Aggregating can only decrease the cross-entropy bound. Jensen bounds $integral_0^1 log s_r dif r <= log(1+D)$.

Decode the terminal point $Y$ from the crossing by $W_r=X_r/r$ for the sphere, and by the transverse coordinate of $X_r$ projected to the fixed box for the slices. For the sphere the path length excess is at least
$ r+|Y-X_r|-1=frac(r |Y-W_r|^2,|Y-X_r|+1-r)>=frac(r,2)|Y-W_r|^2. $
For slices the prefix length is at least $r$ and the suffix at least $sqrt((1-r)^2+|Y-W_r|^2)$: projection only reduces the distance to a point of the box. Their sum minus one is at least $c|Y-W_r|^2$, with $c>0$ depending only on the box diameter. Therefore, in either case, the integer error $U_r=Q_h(Y)-Q_h(W_r)$ satisfies $bb(E)|U_r|^2<=C(1+D/(r h^2))$; in the slice case the factor $r$ can be omitted.

For an integer vector $U$ in dimension $q$, compare its law to a discrete Gaussian with weights $exp(-|u|^2/T)$ where $T=max(1,bb(E)|U|^2)$. Its normalizing sum is at most $C_q T^(q/2)$ by the product of one-dimensional sum bounds. Relative entropy gives $H(U)<=C_q+frac(q,2)log(1+bb(E)|U|^2)$. Because $Q_h(W_r)$ is known given $X_r$, $H(Q_h(Y)|X_r)=H(U_r|X_r)<=H(U_r)$. Consequently
$ H(X_r)>=H_h(nu)-C-frac(q,2)log(1+D/(r h^2)). $
Integrate the crossing estimates, using $log(1+a/r)<=log(1+a)+log(1/r)$ and $integral_0^1 log(1/r) dif r=1$. From $theta^(-epsilon)>=1+epsilon log(1 \/ theta)$ and crossing domination, we obtain
$ cal(E)_p(bb(P))>=1+D+epsilon H_h(nu)-epsilon [C+frac(q,2)log(1+D/h^2)+log(1+D)]. $
For $h^2=epsilon$ and $epsilon<=1/2$, use $D-epsilon log(1+D)>=D/2$. The function $x/2-frac(q,2)log(1+x)$ is bounded below and tends to infinity as $x$ tends to infinity. Substitution $x=D/epsilon$ proves the lower bound and, combined with the upper bound, the claimed length control for near optimizers.

#pagebreak()
= Consequences
For a uniform transverse law on a fixed bounded measurable region of positive $k$-volume $M$, $H_h=k log(1/h)+O(1)$. The number of cells gives the upper bound, and every cell has probability at most $h^k/M$, giving the lower bound. Restoring unit density multiplies the power-law cost by $M^p$. Thus the minimum for the uniform hypersquares of Brancolini and Wirth [1, Theorem 2.4.2], and for general fixed bounded regions in this normalization, is
$ M+frac(M k,2)epsilon log(1/epsilon)+O(epsilon). $
The earlier theorem bounds the excess at the same logarithmic order with unspecified multiplicative constants. Its distinct urban-planning cost is not treated here. Branched quantization [4] instead studies a growing number of sites at fixed power.

For normalized surface measure, the number of cells meeting the sphere and the bound on the surface mass of a cell give $H_h=(d-1)log(1/h)+O(1)$, recovering [5]. For a bounded law with information dimension $s$ in the sense of [3], $H_h/log(1/h)$ tends to $s$, and the leading scaled energy correction tends to $s/2$. The same relation holds separately for lower and upper limits when the dimension does not exist. A mixture of weight $b$ on uniform surface measure and weight $1-b$ on an atom has coefficient $b(d-1)/2$, since mixing adds at most binary entropy to the weighted component entropies.

This result concerns optimal values and mean lengths, not the shape of the minimizing network or its degree at the origin. This preprint has not undergone peer review.

#heading(numbering: none)[References]
[1] Alessio Brancolini and Benedikt Wirth. #link("https://arxiv.org/abs/1511.08467")[Optimal energy scaling for micropatterns in transport networks], _SIAM J. Math. Anal._ 49 (2017), DOI 10.1137/15M1050227.

[2] Paul Pegon. #link("https://arxiv.org/abs/1709.01414")[On the Lagrangian branched transport model and the equivalence with its Eulerian formulation], §§1–2.

[3] Yihong Wu and Sergio Verdú. #link("https://web.mit.edu/~6.454/www/papers/renyidim.pdf")[Rényi information dimension: fundamental limits of almost lossless analog compression], _IEEE Trans. Inf. Theory_ 56 (2010), 3721–3748.

[4] Paul Pegon and Mircea Petrache. #link("https://epubs.siam.org/doi/10.1137/24M1650193")[Optimal quantization with branched optimal transport distances].

[5] #link("https://github.com/RACErace/research-preprints/blob/main/sphere-irrigation-asymptotics.pdf")[The leading energy correction for irrigation of a sphere], research preprint (2026).

