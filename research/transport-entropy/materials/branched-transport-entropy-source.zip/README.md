# Quantized entropy and the near-linear branched transport cost

`main.typ` contains the complete proof. Build using Typst 0.15.2:

```sh
SOURCE_DATE_EPOCH=1795739400 typst compile main.typ branched-transport-entropy.pdf
```

No data or numerical verification is needed. See `AUDIT.md` on the proof and relation to published results.
