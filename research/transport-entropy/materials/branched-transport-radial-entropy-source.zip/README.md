# Radius-weighted angular entropy in near-linear branched transport

Working paper, AI-assisted and not peer reviewed. `main.typ` is the complete proof, including the radius-weighted reduction. No dataset or computational certificate is required.

To render, use Typst with Libertinus Serif installed: `typst compile main.typ branched-transport-radial-entropy.pdf`. The archived PDF was built with compiler timestamp 1795743600.

Source problem: Prouff's irrigation question in [MDS §2.2](https://arxiv.org/html/2611.03403v1#S2.SS2). This note proves the asymptotic energy for a fixed origin and arbitrary target law in the ball, not the topology of minimizing networks.
