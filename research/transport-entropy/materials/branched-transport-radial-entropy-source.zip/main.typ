#set document(title: "Radius-weighted angular entropy in branched transport")
#set page("a4", margin: (x: 23mm, top: 19mm, bottom: 20mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt)
#set par(justify: true, leading: .6em, spacing: .65em)
#set heading(numbering: "1.")
#show heading: set text(fill: rgb("#173c52"))
#align(center)[
  #text(23pt, weight: "bold", fill: rgb("#173c52"))[Radius-weighted angular entropy     in near-linear branched transport]
  #v(.4em)
  #text(10pt)[Working paper (AI-assisted, not peer reviewed) · 27 November 2026]
]
#block(inset: 10pt, fill: rgb("#edf3f7"), radius: 3pt)[
  *Abstract.* Consider irrigation from the origin to any probability law supported in the unit ball of $bb(R)^d$. For $Y=R U$ with $|U|=1$, let $m=bb(E)R$ and let $nu_(star)$ be the direction law weighted by distance, so $m nu_(star)(A)=bb(E)[R bold(1)_(U in A)]$. As the price power $p$ tends to one, put $epsilon=1-p$. The minimal energy is
  $ E_p = m + epsilon m H(floor(U_(star) / sqrt(epsilon))) + O_d(epsilon), quad U_(star) tilde nu_(star). $
  The error is uniform over the destination law. For uniform volume in the ball the coefficient of $epsilon log(1/epsilon)$ is $d(d-1)/(2(d+1))$. All plans within a fixed multiple of $epsilon$ of optimality have mean detour of order at most $epsilon$.
]

= More precise shell formula
Let $d>=2$. Use the Lagrangian energy $cal(E)_p=integral theta^(-epsilon) dif mu$, where $theta(x)$ is the probability of visiting $x$ and $mu$ is mean arclength occupation, counting repeated visits. Terminal law is unrestricted in the closed unit ball; the atom at the origin needs no transport. The zero-mean-radius case is trivial. Put $h=sqrt(epsilon)$, $Z=floor(U/h)$ (coordinatewise), $M(r)=bb(P)(R>=r)$ and $q_i(r)=bb(P)(Z=i,R>=r)$. All logarithms are natural. The main estimate is
$ E_p=m+epsilon A_h+O_d(epsilon), quad A_h=integral_0^1 M(r) H(Z | R>=r) dif r, $
with zero integrand when $M=0$. Moreover $0<=m H(floor(U_(star)/h))-A_h<=1/e$. Both assertions are uniform for all laws at sufficiently small $epsilon$.

= Lower bound
For a finite-energy plan, let $D=bb(E)["length"-R]$. For $0<r<1$ take the first radial hit $X_r$ only on eligible paths with $R>=r$. Hitting times are measurable by the running maximum of radius. The integrated selected occupation is dominated by $mu$: for a fixed path and a Borel subset of its image, the eligible radii for which the selected point belongs to that subset have Lebesgue measure at most the subset's image length under the $1$-Lipschitz radius map, hence at most its arclength occupation.

By finite-energy rectifiability [1], occupation is carried by a countably rectifiable set $S$ of sigma-finite length. Equivalently, sample finitely many independent path images; for points with $theta>=a>0$ the probability of missing a point is at most $(1-a)^N$ with $N$ samples. Taking a countable union of finite samples with errors tending to zero, and then the union over $a=1/n$, gives such a carrier; occupation where $theta=0$ vanishes. Coarea gives countable slices $S_r$ for a.e. $r$. Put $s_r=sum_(x in S_r)theta(x)$. Weighted coarea and Fubini give $integral s_r dif r<=integral_S theta dif cal(H)^1<=m+D$. Conditional cross-entropy against $theta/s_r$, followed by integration using $M<=1$ and $log^+s<=s$, gives
$ integral_0^1 M H(X_r | R>=r) dif r <= integral log(1/theta) dif mu + m+D. $
For countable slices the entropy bound follows by finite aggregation and monotone convergence. Finite energy bounds the integral of $log(1/theta)$ via $e^x>=1+x$.

Write $v=X_r/r$. On eligible paths, the detour is at least
$ r+|R U-r v|-R = frac(R r |U-v|^2, |R U-r v|+R-r) >= frac(r,2)|U-v|^2, $
including the zero numerator case by continuity. The grid-decoding error $Z-floor(v/h)$ has conditional second moment at most $C_d(1+D/(M r h^2))$. Discrete Gaussian comparison (normalizing sum at scale $T>=1$ bounded by $C_d T^(d/2)$) bounds the entropy of that integer error, hence $H(Z | X_r,R>=r)$, by $C_d+(d/2)log(1+D/(M r h^2))$. Using the entropy chain rule, monotonicity of $M log(1+a/(M r))$ in $M$, and $integral_0^1 log(1/r) dif r=1$, we obtain
$ cal(E)_p >= m+D+epsilon A_h - epsilon [C_d+(d/2)log(1+D/h^2)+D]. $
Indeed $log(1+a/r)<=log(1+a)+log(1/r)$. Since $D-epsilon D>=D/2$ near $epsilon=0$, the bounded-below, coercive function $x/2-(d/2)log(1+x)$ at $x=D/epsilon$ gives the energy lower bound and, once the upper bound holds, the uniform detour estimate.

= A radially monotone upper construction
Use the occupied coarse angular grid cells of side $h$. Assign each occupied cell a representative unit direction, and draw a radial trunk in that direction. Take radial slabs $(a,2a]$, $a=2^(-j-1)$, $j>=0$. The slab subtree leaves its coarse trunk at radius $a/2$. Within each slab recursively bisect the radial intervals and halve each side of the angular cells. At an occupied cell with radial interval $(b,b+w]$, put a node at radius $b-w/2$ in a representative unit direction of the angular cell. At the slab root this is the common coarse direction. The child advances by $w/4$ or $3w/4$, by direct substitution of the two child intervals. Its direction differs by $O_d(h 2^(-ell))$ from the parent when the parent's depth is $ell$. Interpolate between the two directions by normalizing their linear interpolation as radius advances. The radius never exceeds $2a$, and its increment is comparable to $a 2^(-ell)$, so the transverse speed is $O_d(h)$. The radial and transverse velocities are orthogonal. Thus arclength per unit radius is at most $1+C_d h^2$ for small $h$. Nested intervals and cells force convergence to the specified endpoint. Paths defined by these countable Borel assignments are measurable. For a physical point on a represented edge, its multiplicity is at least the edge's assigned flow, so intersections do not increase the resulting upper estimate.

Integrate over $(Y,r)$ with $0<r<R$, under terminal law times Lebesgue measure; the resulting measure has mass $m<=1$. At almost every fixed $r$, the represented edges associated to coarse cell $i$ partition its eligible paths, of mass $q_i(r)$. The trunk label at radius $r$ carries only the paths not yet assigned to a slab edge at that radius. The current edge of such a path has mass $q_i(r) v_e$, with $v_e$ its conditional probability given $i,r$. Set $B=-log q_i(r)$ and $I=-log v_e$. The energy is bounded by $(1+C_d h^2)integral exp(epsilon(B+I))$. There are at most $N<=C_d h^(-d)$ coarse cells, so the integrated measure of $B>log N+t$ is at most $e^(-t)$.

Within one coarse cell assign reference weight $1/2$ to its trunk, and weight $g_e=2^(-j-3-(d+2)ell)$ to each possible nontrunk edge at slab $j$ and child depth $ell>=1$. There are at most $2^((d+1)ell)$ such edges at $(j,ell)$, so the total assigned weight is at most one. Conditional on $i,r$, the event $I>-log g_e+t$ has probability at most $e^(-t)$ by summing $v_e<g_e e^(-t)$. Under the integrated measure, $J=-log g_e$ itself has a dimension-dependent exponential tail: slab indices at least $j$ occur only where $R<=2^(-j)$, and the total radial span of edges of child depth at least $ell$ on one path is at most $3a 2^(-ell)$. The latter bound holds because the parent at depth $ell-1$ has width $a 2^(-(ell-1))$, and the endpoint lies at most $3/2$ widths above that node. Thus $integral I=O_d(1)$, and $B+I$ is bounded above by $log N$ plus a nonnegative quantity with uniform exponential tail, by a union bound on $(B-log N)_+$, $J$ and $(I-J)_+$.

Taylor's inequality now gives $integral e^(epsilon(B+I))=m+epsilon integral B+O_d(epsilon)$ for $h^2=epsilon$: the Taylor remainder is bounded by $C_d epsilon^2 e^(epsilon log N)(1+(log N)^2)=O_d(epsilon)$. Also,
$ integral B = integral_0^1 [M(r)H(Z | R>=r)+M(r)log(1/M(r))] dif r. $
The second term is at most $1/e$. This proves the upper bound and completes the shell formula.

= Reduction to a single weighted direction law
Normalize the measure of $(Y,r)$ just used by $m$. Its marginal on $Y$ is length-biased by $R/m$, and given $Y$ its conditional law on $r$ is uniform on $(0,R)$ with probability one that $R>0$. Its conditional law of $Z$ given $r$ is the eligible law. Therefore $A_h=m H(floor(U_(star)/h))-m I(Z;r)$, with $I$ mutual information for this normalized measure. Relative entropy with respect to uniform Lebesgue measure on $(0,1)$ gives
$ I(Z;r)<=I(Y;r)<=bb(E)_"biased" log(1/R). $
The last inequality follows by subtracting the nonnegative relative entropy of the marginal law of $r$ from the expected conditional relative entropy. Multiplying by $m$ makes the right side $bb(E)[R log(1/R)]<=1/e$. This gives the claimed radius-weighted formula.

= Examples and scope
For uniform volume, direction is independent of radius, $m=d/(d+1)$, and the surface law has $H(floor(U/h))=(d-1)log(1/h)+O_d(1)$: the number of occupied grid cells is $O_d(h^(-(d-1)))$ and every cell's surface mass is $O_d(h^(d-1))$. More generally, if the radius-weighted angular law has information dimension $s$, the coefficient at scale $epsilon log(1/epsilon)$ is $m s/2$, with separate lower and upper versions when the dimension does not exist. If the destination law is entirely on one ray, the whole angular correction vanishes even for a diffuse radial law. The equal-radius result [2] is recovered by setting $R=1$. This concerns energy and mean detour, not optimizer topology.

[1] P. Pegon, _On the Lagrangian branched transport model and the equivalence with its Eulerian formulation_, #link("https://arxiv.org/abs/1709.01414")[arXiv:1709.01414]. [2] _Quantized entropy and the near-linear branched transport cost_, #link("https://github.com/RACErace/research-preprints/blob/main/branched-transport-entropy.pdf")[companion preprint]. [3] P. Pegon, F. Santambrogio and Q. Xia, _A fractal shape optimization problem in branched transport_, #link("https://math.ucdavis.edu/~qlxia/Research/shape.pdf")[author PDF]. This optimizes the shape of a target at fixed exponent rather than the near-linear cost for a prescribed law. [4] P. Pegon and M. Petrache, _Optimal quantization with branched optimal transport_, #link("https://epubs.siam.org/doi/10.1137/24M1650193")[DOI]. This quantizes at fixed cost power. [5] Prouff's irrigation question in #link("https://arxiv.org/html/2611.03403v1#S2.SS2")[MDS §2.2].
