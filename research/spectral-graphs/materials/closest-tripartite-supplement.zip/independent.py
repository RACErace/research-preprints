"""Independent rational-inertia replay for small n and integer finite differences for large n."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from collections import Counter

def inertia(M):
    M=[r[:] for r in M]
    neg=zero=0
    while M:
        n=len(M)
        d=next((i for i in range(n) if M[i][i]),None)
        if d is not None:
            p=M[d][d]
            neg+=p<0
            ids=[i for i in range(n) if i!=d]
            M=[[M[i][j]-M[i][d]*M[d][j]/p for j in ids] for i in ids]
        else:
            ij=next(((i,j) for i in range(n) for j in range(i) if M[i][j]),None)
            if ij is None:
                zero=n
                break
            i,j=ij
            p=M[i][j]
            neg+=1
            ids=[k for k in range(n) if k not in ij]
            M=[[M[k][l]-(M[k][i]*M[j][l]+M[k][j]*M[i][l])/p for l in ids] for k in ids]
    return neg,zero

def encl(A,w):
    order=sum(w)
    D=10**5
    cnt={}
    def below(k):
        if k not in cnt:
            t=F(k,D)
            neg,zero=inertia([[F(A[i][j])-(t/w[i] if i==j else 0) for j in range(len(w))] for i in range(len(w))])
            cnt[k]=neg+zero
        return cnt[k]
    roots=[]
    for i in range(len(w)):
        lo,hi=-order*D,order*D
        assert below(lo)<=i<below(hi)
        while hi>lo+1:
            m=(hi+lo)//2
            if below(m)<=i:lo=m
            else:hi=m
        roots.append((F(lo,D),F(hi,D)))
    return roots

def distances(n,x,a,b,c):
    A=[[0,1,1],[1,0,1],[1,1,0]] if x==0 else [[0,1,1,0],[1,0,1,0],[1,1,0,1],[0,0,1,0]]
    weights=[a,b,c]+([x] if x else [])
    ref=[-n,-n]+([0] if x else [])+[2*n]
    al=[(l-v,h-v) for (l,h),v in zip(encl(A,weights),ref,strict=True)]
    al=[(0 if l<=0<=h else min(abs(l),abs(h)),max(abs(l),abs(h))) for l,h in al]
    return tuple(tuple(sum(t[i]**p for t in al) for i in (0,1)) for p in (1,2))

def small():
    count=Counter()
    for n in range(3,35):
        R=distances(n,1,n,n,n-1)
        assert R[0][1]<F(11,9) and R[1][1]<F(29,50)
        # Loop over non-triangle vertices first, independently of the main loop.
        for u in range(3*n-2):
            for x in range(u+1):
                length=3*n-u
                for c in range(1,length-1):
                    for a in range(1,(length-c)//2+1):
                        b=length-c-a
                        if (x,a,b,c) in ((0,n,n,n),(1,n,n,n-1)):continue
                        if 10*(3*n*n-(a*b+a*c+b*c+c*x))>=19*n:continue
                        m,h=sorted((a,b,c))[1:]
                        if 25*m*h>=(5*n+4)**2:continue
                        d=distances(n,x,a,b,c)
                        assert all(ds[0]>rs[1] for ds,rs in zip(d,R))
                        count[n]+=1
    print("Independent small-order tuples certified:",sum(count.values()),flush=True)
def large():
    s=F(11,20)
    count=0
    for leaf in (0,1):
        for a,b in combinations_with_replacement(range(-13,7),2):
            c=-leaf-a-b
            if not -13<=c<=6 or not (a or b or c+leaf):continue
            for d in (-s,s):
                v=[]
                for n in range(35,40):
                    A,B,C=n+a,n+b,n+c
                    x=-n+d
                    S=A*B+A*C+B*C
                    P=A*B*C
                    v.append(x**3-S*x-2*P if leaf==0 else -(x**4-(S+C)*x*x-2*P*x+P))
                assert v[0]>0
                while len(v)>1:
                    v=[r-l for l,r in zip(v,v[1:])]
                    assert v[0]>=0
                count+=1
    print("Independent integer polynomial sign checks:",count,flush=True)

if __name__=='__main__':
    large()
    small()
