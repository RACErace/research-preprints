"""Exact finite certificates for closest balanced complete tripartite spectra."""
import itertools as it
from fractions import Fraction as F
import networkx as nx
import sympy as sp

X=sp.Symbol('x')
D=sp.Rational
def roots(poly, N):
    intervals=sp.Poly(poly,X).intervals(eps=D(1,10**6))
    ans=sorted((lo,hi) for (lo,hi),k in intervals for j in range(k))
    assert len(ans)==N
    return ans

def abs_range(lo,hi):
    return (min(abs(lo),abs(hi)) if lo*hi>0 else 0, max(abs(lo),abs(hi)))
def bounds(r,vals,p):
    aa=[abs_range(l-v,h-v) for (l,h),v in zip(r,vals,strict=True)]
    return tuple(sum(t[k]**p for t in aa) for k in (0,1))

def cores(r):
    output=[]
    for G in nx.graph_atlas_g():
        if len(G)!=r:continue
        A=sp.Matrix([[int(G.has_edge(i,j)) for j in range(r)] for i in range(r)])
        if not A.det():continue
        C=A.inv()
        base=[tuple(A[:,j]) for j in range(r)]
        V=[a for a in it.product((0,1),repeat=r) if any(a) and (sp.Matrix([a])*C*sp.Matrix(a))[0]==0 and a not in base]
        h={a:sp.Matrix([a])*C for a in base+V}
        N=nx.Graph()
        N.add_nodes_from(V)
        for a,b in it.combinations(V,2):
            if (h[a]*sp.Matrix(b))[0] in (0,1):N.add_edge(a,b)
        for ext in it.chain([[]],nx.enumerate_all_cliques(N)):
            W=base+ext
            H=nx.Graph()
            H.add_nodes_from(range(len(W)))
            H.add_edges_from((i,j) for i,j in it.combinations(range(len(W)),2) if (h[W[i]]*sp.Matrix(W[j]))[0]==1)
            if any(len(Q)==len(H) and nx.is_isomorphic(Q,H) for Q in output):continue
            output.append(H)
    return output
def key(G):return nx.to_graph6_bytes(G,header=False).decode().strip()
def core_roots(G,w):
    A=sp.Matrix([[int(G.has_edge(i,j))*w[j] for j in range(len(G))] for i in range(len(G))])
    return roots(A.charpoly(X).as_expr(),len(G))
def check_cores():
    d1_pass,d2_pass=[],[]
    for r,expected in ((2,1),(3,1),(4,9),(5,25)):
        fam=cores(r)
        assert len(fam)==expected
        for G in fam:
            if nx.is_bipartite(G):continue # exclude by spectral radius
            R=core_roots(G,[1]*len(G))
            T=R[2:-1]
            z=max(sum(max(0,lo) for lo,hi in T),sum(max(0,-hi) for lo,hi in T))
            if z<=D(11,18):d1_pass.append(key(G))
            t=bounds(T,[0]*len(T),2)[0]
            if t>=D(29,50):continue
            if r==4:
                # Exactly two negative and two positive eigenvalues in cases reaching this point.
                assert sum(1 for lo,hi in R if hi<0)==2
                assert sum(1 for lo,hi in R if lo>0)==2
                lam=R[-2][0]
                if 4*lam**2/3>=D(29,50):continue
            d2_pass.append(key(G))
    assert sorted(d1_pass)==['Bw','CN'], d1_pass
    assert sorted(d2_pass)==['Bw','CN','Dko'], d2_pass
    G=nx.from_graph6_bytes(b'Dko')
    for i in range(4):
        w=[1]*len(G);w[i]=2
        lam=core_roots(G,w)[-2][0]
        assert 4*lam**2/3>D(29,50),(i,lam)
    print("Core checks:",d1_pass,d2_pass,"(Dko eliminated by duplications/spectral radius)",flush=True)

def H(x,a,b,c):
    if not x:return X**3-(a*b+a*c+b*c)*X-2*a*b*c
    return X**4-(a*b+a*c+b*c+c*x)*X**2-2*a*b*c*X+a*b*c*x
def pair(n,x,a,b,c):
    N=3+bool(x)
    S=roots(H(x,a,b,c),N)
    return tuple(bounds(S,[-n,-n]+([0] if x else [])+[2*n],p) for p in (1,2))
def check_finite():
    for n in range(3,35):
        target=pair(n,1,n,n,n-1)
        assert target[0][1]<D(11,9) and target[1][1]<D(29,50)
        nn=3*n
        passed=0
        for a in range(1,nn-1):
            for b in range(a,nn-a):
                for c in range(1,nn-a-b+1):
                    s=nn-a-b-c
                    edge0=a*b+a*c+b*c
                    m,h=sorted((a,b,c))[1:]
                    if 25*m*h>=(5*n+4)**2:continue
                    if 10*(3*n*n-edge0-c*s)>=19*n:continue
                    for x in range(s+1):
                        if (x,a,b,c) in ((0,n,n,n),(1,n,n,n-1)):continue
                        if 10*(3*n*n-edge0-c*x)>=19*n:continue
                        est=pair(n,x,a,b,c)
                        for p in (0,1):
                            assert est[p][0]>target[p][1],(n,x,a,b,c,p,est,target)
                        passed+=1
        print(n,"nontrivial candidate tuples",passed,flush=True)
if __name__=='__main__':
    check_cores()
    check_finite()
