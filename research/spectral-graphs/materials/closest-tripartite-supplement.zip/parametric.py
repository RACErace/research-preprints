"""Exact symbolic exclusion of the bounded integer part offsets for all n >= 35."""
from itertools import combinations_with_replacement
import sympy as sp

n,s=sp.symbols('n s')
r=sp.Rational(11,20)
count=0
for leaf in (0,1):
    for a,b in combinations_with_replacement(range(-13,7),2):
        c=-leaf-a-b
        if not -13<=c<=6 or not (a or b or c+leaf):
            continue
        A,B,C=n+a,n+b,n+c
        E=A*B+A*C+B*C
        P=A*B*C
        for d in (-r,r):
            x=-n+d
            # These chosen signs are positive exactly between the two negative roots.
            value=x**3-E*x-2*P if leaf==0 else -(x**4-(E+C)*x*x-2*P*x+P)
            coeffs=sp.Poly(value.subs(n,35+s),s).all_coeffs()
            assert min(coeffs)>=0 and coeffs[-1]>0,(leaf,a,b,c,d,coeffs)
            count+=1
assert count==416
print('Exact polynomial coefficient tests for all real n >= 35:',count)
