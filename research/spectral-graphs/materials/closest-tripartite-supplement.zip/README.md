# The unique spectrally closest competitor to a balanced complete tripartite graph

This preprint answers Conjecture 20 of Jovanović, Sedlar and Škrekovski, arXiv:2610.18636v2. For every n >= 3 the proposed graph H_n is the unique nearest nonisomorphic graph in both Manhattan and squared Euclidean adjacency spectral distance. Disconnected competitors are included.

## Replay

Use Python 3.12 (tested with 3.12.14). Install requirements.txt in a virtual environment, then run:

    python -B verify.py
    python -B parametric.py
    python -B independent.py

Do not disable assertions. The first command checks all rank-at-most-five cores and the 598 small-order tuples using exact characteristic polynomial root isolation. The second checks 416 polynomial signs for all orders above the finite cutoff. The third has no third-party dependencies: its finite checks use rational matrix inertia rather than polynomial root isolation, and its large-order check uses forward differences on integer inputs. The reduction from rank at least six is proved in the accompanying earlier paper `spectral-rank-six.pdf`, whose separate supplement contains its exact verifiers.

Rebuild the PDF with Typst 0.15.2:

    typst compile main.typ closest-tripartite-graph.pdf

This is a preprint, not a peer-reviewed publication. The publication repository also provides the root literature audit.
