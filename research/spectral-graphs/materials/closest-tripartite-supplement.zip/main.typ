#set document(title: "The unique spectrally closest competitor to a balanced complete tripartite graph")
#set page(paper: "a4", margin: (x: 25mm, y: 23mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.57em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#let rk = math.op("rank")
#let diag = math.op("diag")
#let boxnote(body) = block(inset: 9pt, fill: luma(246), width: 100%, body)
#align(center)[
  #text(size: 21pt, weight: "semibold")[The unique spectrally closest competitor \ to a balanced complete tripartite graph]
  #v(5pt)
  A solution to Conjecture 20 of Jovanović, Sedlar and Škrekovski
  #v(4pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(6pt)
#boxnote[
  *Abstract.* We prove that for every $n>=3$, among graphs of order $3n$ not isomorphic to $K_(n,n,n)$, the same graph uniquely minimizes both the Manhattan and squared Euclidean distances between ordered adjacency spectra. The minimizer is the graph proposed by Jovanović, Sedlar and Škrekovski in Conjecture 20: a complete tripartite graph with parts of sizes $n,n,n-1$, plus a single vertex adjacent precisely to the part of size $n-1$. We reduce to adjacency rank at most five and then to two weighted core graphs. For large orders, spectral and edge-count constraints leave a fixed finite set of integer offsets, which is ruled out by polynomial signs. The remaining small orders are verified by exact rational enclosures. Disconnected competitors are included.
]

*Keywords:* graph cospectrality; spectral distance; complete tripartite graph; graph blow-up. *MSC 2020:* 05C50.

= Main result and conventions

Let $lambda_1(G)<=dots<=lambda_N(G)$ denote the adjacency eigenvalues of a simple graph on $N$ vertices. For graphs of the same order, write
$ D_p(G,H)=sum_(i=1)^N |lambda_i(G)-lambda_i(H)|^p quad (p=1,2). $
In this notation $D_2$ is squared Euclidean distance, as in @jss. Fix $B_n=K_(n,n,n)$. Its only nonzero eigenvalues are $-n,-n,2n$. Define $P(a,b,c,x;z)$ by starting from $K_(a,b,c)$, adding $x$ pairwise nonadjacent vertices adjacent to every vertex in the third part and to no other vertices, and adding $z$ isolates. We use $a,b,c>=1$, $x,z>=0$. The graph proposed by @jss is $H_n=P(n,n,n-1,1;0)$.

#boxnote[
  *Theorem 1.* For every integer $n>=3$ and $p in {1,2}$, if $G$ has order $3n$ and is not isomorphic to $B_n$, then
  $ D_p(B_n,G) >= D_p(B_n,H_n), $
  with equality only for graphs isomorphic to $H_n$.
]

The bounds in @jss, Theorem 6 and Remark 7, imply $D_1(B_n,H_n)<1+2/(3n)<=11/9$. The proof of their Theorem 15(i) implies $D_2(B_n,H_n)<=1/2+1/(3n)+2/(9n^2)<29/50$ for $n>=5$. For $n=3,4$, the exact check below gives the same strict $29/50$ bound. We only have to consider graphs at most as far as $H_n$ in at least one of the two distances. Call these *candidates*.

= Reduction to the triangle and paw
The rank-six spectral-tail bounds in @rank give $rk A(G)<=5$ for every candidate. Indeed, deleting the first two and last coordinates from the ordered spectrum of $G$ gives the trimmed part whose $p$-power sum is at most $D_p(B_n,G)$; if the rank is at least six, that sum exceeds $1.47$ for $p=1$ and $0.79$ for $p=2$. The same interlacing argument in @rank shows that under induced extension the trimmed squared sum, the trimmed positive sum and the trimmed absolute negative sum cannot decrease: match each negative entry to the lower interlacing bound and each positive entry to the upper one. The matched positions are distinct.

If a graph is bipartite, its adjacency spectral radius is at most $3n/2$. In fact, the all-ones matrix dominates the rectangular bipartite incidence block with part sizes summing to $3n$, and that all-ones block has norm at most $3n/2$. The discrepancy from $2n$ at the largest eigenvalue alone rules out bipartite candidates. In particular we may discard rank zero and rank two (the sole rank-two core is a single edge, as verified below); rank one is incompatible with zero trace.

== Enumerating twin-free cores
Delete isolates and identify classes of vertices having identical adjacency rows. Such vertices are pairwise nonadjacent within a class; between two classes all edges are present or all are absent. Representatives induce a graph $Q$. With class sizes $w_i$, the nonzero adjacency eigenvalues agree with those of $W^(1/2) A(Q) W^(1/2)$, where $W=diag(w_i)$. This follows by restricting to the span of the normalized class indicators; the orthogonal complement has eigenvalue zero. In particular, the ranks agree.

For clarity, we describe an exhaustive enumeration of the possible $Q$ without using a low-rank classification. Let $r$ be its rank. Its adjacency matrix has an invertible principal block $M$ of order $r$: the sum of the order-$r$ principal minors is the product of the nonzero eigenvalues. For every vertex, let $u$ be its binary column restricted to the block. Rank $r$ forces the adjacency entry for vertices of types $u,v$ to equal $u^top M^(-1)v$ by the Schur complement. Thus distinct non-isolated twin classes give distinct nonzero types. Each type has $u^top M^(-1)u=0$, and two distinct types can coexist only if their pairing is zero or one. One enumerates the invertible order-$r$ adjacency matrices up to isomorphism, includes their column types, and adds every clique of compatible extra types. Every allowed type pairs integrally with the mandatory types because these are columns of $M$. Deduplicating the resulting graphs gives the counts below, including disconnected cores. All pairings in the enumeration are exact.
#align(center)[
  #table(columns: (auto, auto, auto, auto, auto), align: center, inset: 5pt,
    [Adjacency rank], [2], [3], [4], [5],
    [Non-isolated twin-free cores], [1], [1], [9], [25])
]

== Excluding the other cores
For Manhattan candidates, the total of the positive differences of eigenvalues equals the total magnitude of the negative differences, since the difference of traces is zero. Thus each of those totals is $D_1/2<11/18$. The two trimmed sign sums of an induced core must therefore be less than $11/18$. Checking the finitely many non-bipartite cores leaves only the triangle and the paw. Here a paw is a triangle plus a vertex adjacent to exactly one of its vertices.

For the squared distance, first discard cores with trimmed squared sum at least $29/50$. The only remaining non-bipartite cores are the triangle, the paw, and two other rank-four cores. With two positive and two negative eigenvalues, a graph of rank four has its second-largest positive eigenvalue $t$ matched to zero, and all other nonzero discrepancies occur in the three extremal positions. Those discrepancies sum to $-t$. Consequently
$ D_2(B_n,G)>=t^2+t^2/3. $
By interlacing $t$ cannot decrease when passing from a core, or a smaller blow-up, to the full graph. The exact certificate applies this bound to the two extra cores. It eliminates the first, a triangle sharing an edge with a four-cycle. In the second, a triangle with a leaf attached to each of two different vertices, it eliminates every doubling except at the third vertex of the triangle. If only that vertex is allowed to grow, to multiplicity $w$, the graph has $2w+3<=6n-5$ edges. Its largest eigenvalue is at most $sqrt(12n-10)<2n-4/5$ for $n>=3$ by the second spectral moment. This again contradicts $D_2<29/50$.

These finite exclusions are certified by isolating the real roots of integer characteristic polynomials. For a blow-up one can use the characteristic polynomial of the integral matrix $A(Q)W$, which is similar to the symmetric weighted matrix. The script stores rational intervals for the ordered roots and tests lower bounds against the cutoffs. Thus each candidate is a blow-up of the triangle or paw with possible isolates, as described by $P$.

= Necessary bounds on the parameters
Let $e$ denote the number of edges of a candidate and $delta$ the vector of ordered eigenvalue differences $lambda(G)-lambda(B_n)$. The trace of the square gives
$ 3n^2-e=-sum_i lambda_i(B_n) delta_i-1/2 norm(delta)_2^2. $
If $D_2<29/50$, Cauchy–Schwarz bounds the right-hand side above by $n sqrt(6 dot 29/50)<19n/10$. If $D_1<11/9$, the positive and negative masses of $delta$ are equal to $D_1/2$. Because the maximum and minimum coordinates of $lambda(B_n)$ differ by $3n$, the right-hand side is at most $3n D_1/2<19n/10$. In either case, $|lambda_1(G)+n|<4/5$: for $D_2$ this follows by squaring, and for $D_1$ every individual discrepancy is at most $D_1/2$.

Let $m,h$ be the middle and largest of $a,b,c$. The induced $K_(m,h)$ gives $lambda_1(G)<=-sqrt(m h)$. We have proved the two necessary inequalities
$ 3n^2-e<19n/10, quad m h<(n+4/5)^2, quad e=a b+a c+b c+c x. $ <prune>

For $n>=9$, every Manhattan candidate also has $D_2<29/50$. Indeed for a zero-sum vector the squared norm is at most half the square of its absolute sum, by bounding the sum of squares separately on each sign. Here $D_1<1+2/(3n)$ and $(1+2/27)^2/2<29/50$. Thus we may use the squared distance cutoff for all large-order candidates.

= Uniform exclusion for large orders
We treat $n>=35$. Suppose first that $x+z=q>=2$. Adding edges from every isolate to the third class only increases the number of edges, so
$ e<=a b+a c+b c+c q, quad a+b+c=3n-q=S. $
Maximizing over reals with nonnegative $a,b,c$ gives the upper bound
$ e <= max_(0<=c<=S) ((S-c)^2/4 +c(S-c+q)). $
For $q<=3n/2$, the maximum is at most $3n^2-n q+q^2/3<=3n^2-2n+4/3$, since this expression decreases on $[2,3n/2]$. For $q>3n/2$, the quadratic is increasing on $[0,S]$, giving $e<=q(3n-q)<=9n^2/4$. Both bounds violate @prune for $n>=35$. With one isolate but no leaf, $e<=(3n-1)^2/3$ also violates @prune. It follows that $z=0$ and $x in {0,1}$.

To bound deviations of the triangle sizes from $n$, set $t=-n+4/5$. Both negative eigenvalues of the weighted core lie below $t$. In the case $x=1$, eliminating the positive leaf pivot $-t$ in the matrix of the weighted quotient minus $t I$ leaves
$ u u^top-diag(a+t,b+t,c+t+c/(-t)), quad u=(sqrt(a),sqrt(b),sqrt(c))^top. $
For $x=0$ the same expression has no $c/(-t)$ term. The displayed matrix has two negative eigenvalues, so at least two of its diagonal parameters (the entries subtracted from $u u^top$) are positive. Otherwise adding the positive semidefinite rank-one matrix cannot produce two negative eigenvalues. Since $c/(-t)<4$ for $n>=35$, at least two of $a,b,c$ exceed $n-4.8$, hence $m>=n-4$. By @prune,
$ h<(n+4/5)^2/(n-4)=n+5.6+23.04/(n-4)<n+7. $
As $h$ is integral, $h<=n+6$, and $a+b+c=3n-x$ gives a lower bound $n-13$ for the smallest part.

We have reduced to $a=n+i,b=n+j,c=n+k$ where $i,j,k in {-13,dots,6}$ and $i+j+k=-x$. We may assume $i<=j$. The exceptional triples $(0,0,0)$ when $x=0$ and $(0,0,-1)$ when $x=1$ produce $B_n$ and $H_n$. For all other offset choices the two points $-n-11/20$ and $-n+11/20$ lie strictly between the two negative eigenvalues. The certificate for this last fact uses the characteristic polynomials
$ Q_0(y)=y^3-(a b+a c+b c)y-2a b c, $
$ Q_1(y)=y^4-(a b+a c+b c+c)y^2-2a b c y+a b c. $
At both points $Q_0>0$ or $Q_1<0$, respectively. These signs characterize the interval between the negative roots on the negative half-line, since the triangle has one positive root and the paw has two positive roots. To certify the signs for all integer $n>=35$, substitute $n=35+s$ and verify nonnegative coefficients and a strictly positive constant term for $Q_0$ and $-Q_1$ after each evaluation. An independent integer finite-difference test checks the same signs. There are 416 such tests. The two negative discrepancies then contribute more than $2(11/20)^2>29/50$, a contradiction.

= Exact finite check and conclusion
For each $n$ from 3 to 34, list all $a,b,c>=1$ and $x,z>=0$ with $a+b+c+x+z=3n$, retaining $a<=b$. Discard $B_n$ and $H_n$ and apply @prune. For each of the 598 surviving tuples, isolate the roots of the integral weighted-core characteristic polynomial, convert differences to rational intervals, and verify that the lower bound exceeds the upper bound for $H_n$ for each $p$. When $x>=1$ the paw polynomial has the extra factor $x$ in the leaf terms: the coefficient of $y^2$ is $-(a b+a c+b c+c x)$ and the constant term is $a b c x$. Added isolates only contribute zero eigenvalues. The supplied independent verifier uses congruence inertia of $A(Q)-t W^(-1)$ instead of polynomial root isolation for the same finite comparisons.

All candidates other than $B_n$ and $H_n$ have thus been excluded, establishing Theorem 1 in both distances and with no connectedness assumption.

*Reproducibility.* The supplement includes the two exact finite checks, the parametric sign check, replay logs, dependency versions and the editable manuscript. The finite iteration over offsets and the root enclosures are part of the proof rather than numerical extrapolations.

*Development disclosure.* OpenAI models were used to develop the argument, implement the certificates and prepare this manuscript.

#bibliography("references.bib", title: "References", style: "ieee")
