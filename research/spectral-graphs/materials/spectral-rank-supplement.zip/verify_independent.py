#!/usr/bin/env python3
"""Independent atlas plus exact rational inertia, not Sturm isolation."""
from fractions import Fraction as F
from collections import Counter
import networkx as nx

def inertia_less(A, t):
    M=[[F(A[i][j])-t*(i==j) for j in range(len(A))] for i in range(len(A))]
    neg=zero=0
    while M:
        d=next((i for i,row in enumerate(M) if row[i]),None)
        if d is not None:
            p=M[d][d]; rest=[i for i in range(len(M)) if i!=d]
            neg+=p<0
            M=[[M[i][j]-M[i][d]*M[d][j]/p for j in rest] for i in rest]
        else:
            pair=next(((i,j) for i,row in enumerate(M) for j in range(i) if row[j]),None)
            if pair is None:
                zero=len(M)
                break
            i,j=pair; p=M[i][j]
            rest=[k for k in range(len(M)) if k not in pair]
            neg+=1
            M=[[M[k][l]-(M[k][i]*M[j][l]+M[k][j]*M[i][l])/p for l in rest] for k in rest]
    return neg,zero

def encl(A):
    D=10**5
    N=len(A)
    out=[]
    cache={}
    def counts(k):
        if k not in cache:
            cache[k]=inertia_less(A,F(k,D))
        return cache[k]
    # Every eigenvalue lies in [-(N-1),N-1] by the maximum row sum.
    for i in range(N):
        lo,hi=-N*D,N*D
        while lo+1<hi:
            mid=(lo+hi)//2
            n,z=counts(mid)
            if n+z<=i:
                lo=mid
            else:
                hi=mid
        nl,zl=counts(lo)
        nh,zh=counts(hi)
        assert nl+zl<=i<nh+zh
        out.append((F(lo,D),F(hi,D)))
    return out

def lsq(a,b):
    return 0 if a<=0<=b else min(a*a,b*b)

def main():
    count=Counter(); near=[]; near1=[]
    for g in nx.graph_atlas_g():
        n=len(g)
        if n not in (6,7):
            continue
        A=[[int(g.has_edge(i,j)) for j in range(n)] for i in range(n)]
        if n-inertia_less(A,F(0))[1]<6:
            continue
        count[n]+=1
        roots=encl(A)
        lo=sum(lsq(a,b) for a,b in roots[2:-1])
        assert lo>F(79,100)
        lo1=sum(0 if a<=0<=b else min(abs(a),abs(b)) for a,b in roots[2:-1])
        assert lo1>F(147,100)
        if lo1<F(148,100):
            hi1=sum(max(abs(a),abs(b)) for a,b in roots[2:-1])
            assert hi1<F(148,100)
            near1.append((n,nx.to_graph6_bytes(g,header=False).strip().decode(),lo1,hi1))
        if lo<F(791,1000):
            hi=sum(max(a*a,b*b) for a,b in roots[2:-1])
            assert hi<F(791,1000)
            near.append((n,nx.to_graph6_bytes(g,header=False).strip().decode(),lo,hi))
    assert count=={6:57,7:779}
    assert len(near)==2
    small=nx.from_graph6_bytes(next(g for n,g,_,_ in near if n==6).encode())
    large=nx.from_graph6_bytes(next(g for n,g,_,_ in near if n==7).encode())
    large.remove_nodes_from(list(nx.isolates(large)))
    assert nx.is_isomorphic(small,large)
    assert len(near1)==2
    small1=nx.from_graph6_bytes(next(g for n,g,_,_ in near1 if n==6).encode())
    large1=nx.from_graph6_bytes(next(g for n,g,_,_ in near1 if n==7).encode())
    large1.remove_nodes_from(list(nx.isolates(large1)))
    assert nx.is_isomorphic(small1,large1)
    assert sorted(small1.edges())==[(0,1),(0,3),(0,4),(0,5),(1,2),(1,5),(2,3),(3,4),(3,5)]
    assert sorted(small.edges())==[(0,1),(0,4),(1,2),(1,3),(1,4),(1,5),(2,3),(3,4)]
    for _,_,lo,hi in near1:
        assert F('1.47431')<lo<=hi<F('1.47441')
    for _,_,lo,hi in near:
        assert F('0.79042')<lo<=hi<F('0.79052')
    print('Only exceptions to absolute tail >=1.48:',near1,flush=True)
    print('Six-vertex minimizing absolute-tail edge list:',sorted(small1.edges()),flush=True)
    print('Exact rational inertia: rank >=6 counts',dict(count),flush=True)
    print('Only exceptions to tail >=0.791:',near,flush=True)
    print('Six-vertex minimizing edge list, zero-based:',sorted(small.edges()),flush=True)

if __name__=='__main__':
    main()
