#set document(title: "Sharp adjacency spectral-tail bounds at rank six")
#set page(paper: "a4", margin: (x: 26mm, y: 24mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.63em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#let boxnote(body) = block(inset: 9pt, fill: luma(246), width: 100%, body)
#let rk = math.op("rank")

#align(center)[
  #text(size: 22pt, weight: "semibold")[Sharp adjacency spectral-tail \ bounds at rank six]
  #v(5pt)
  #text(size: 11pt)[A solution to a rank problem for complete tripartite graphs]
  #v(4pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(7pt)
#boxnote[
  *Abstract.* Jovanović, Sedlar and Škrekovski asked whether a connected graph at squared adjacency spectral distance less than $2/3$ from a balanced complete tripartite graph must have adjacency rank at most five. We answer affirmatively, without assuming connectedness. For every simple graph of rank at least six, the sum of squares of the adjacency eigenvalues after omitting the two smallest and the largest is at least an explicit sharp constant greater than $0.79$. The corresponding sum of absolute values is at least another sharp constant greater than $1.47$. Cauchy interlacing reduces both bounds to graphs on six or seven vertices, and two exact computational checks verify the remaining comparisons. As a consequence, every nearest competitor to a balanced complete tripartite graph has rank at most five, in either distance.
]

*Keywords:* adjacency spectrum; spectral distance; graph rank; induced subgraphs. *MSC 2020:* 05C50.

= Notation and main result
All graphs are finite, undirected and simple. Write the eigenvalues of the adjacency matrix $A(G)$ in increasing order as $lambda_1(G) <= dots <= lambda_N(G)$. For $p in {1,2}$ let
$ D_p(G,H) = sum_(i=1)^N |lambda_i(G)-lambda_i(H)|^p, quad T_p(G) = sum_(i=3)^(N-1) |lambda_i(G)|^p. $ <def>
The two graphs in $D_p$ have the same order. Thus $D_1$ is Manhattan spectral distance and $D_2$ is squared Euclidean spectral distance, with no square root. These agree with the quantities denoted by $sigma^((p))$ in @jss.

Let $W_1,W_2$ be the graphs on vertices $0, dots, 5$ with the following edges (for example, $01$ denotes the unordered edge with endpoints $0$ and $1$):
$ E(W_1) = {01,03,04,05,12,15,23,34,35}, $
$ E(W_2) = {01,04,12,13,14,15,23,34}. $
Put $c_1=T_1(W_1)$ and $c_2=T_2(W_2)$.

#boxnote[
  *Theorem 1.* If $rk A(G) >= 6$, then $T_1(G) >= c_1$ and $T_2(G) >= c_2$. Both bounds are attained. In particular,
  $ 1.47431 < c_1 < 1.47441, quad 0.79042 < c_2 < 0.79052. $
]

The constants are sharp for the trimmed sums $T_p$, not asserted to be sharp for the distance to any fixed graph. The sharpness examples for $p=1$ and $p=2$ are different.

= The induced-subgraph reduction

*Lemma 2 (small rank witness).* For any positive integer $r$, a graph of adjacency rank at least $r$ contains an induced subgraph of order $r$ or $r+1$ and adjacency rank at least $r$.

_Proof._ Choose an induced subgraph $F$ of minimum order $m$ having rank $s >= r$. Deleting one vertex loses at most two in rank, since it deletes one row and one column. Minimality implies $s <= r+1$. In a real symmetric matrix of rank $s$, at least one principal minor of order $s$ is nonzero: up to sign, their sum is the coefficient of degree $m-s$ of the characteristic polynomial, which is the product of the $s$ nonzero eigenvalues up to sign. This gives an induced subgraph on $s$ vertices of rank $s$, so $m=s$. $square$

*Lemma 3 (trimmed sums and interlacing).* Suppose $F$ is an induced subgraph of $G$ on $m$ vertices, and $a,b$ are nonnegative integers with $a+b < m$. For every real $p>0$,
$ sum_(i=a+1)^(m-b) |lambda_i(F)|^p <= sum_(i=a+1)^(N-b) |lambda_i(G)|^p. $ <monotone>

_Proof._ By Cauchy interlacing, $lambda_i(G)<=lambda_i(F)<=lambda_(i+N-m)(G)$. For each negative eigenvalue in the sum on the left, use the lower interlacing bound; for each positive one, use the upper bound. The selected indices all lie between $a+1$ and $N-b$. Within each sign the selection is injective. The minus-sign selections precede the plus-sign selections, since the corresponding indices in $F$ are ordered and $N-m>=0$. This proves the inequality after ignoring zero contributions. $square$

Taking $r=6$, $a=2$ and $b=1$, the minimum of each $T_p$ over graphs of rank at least six is therefore the minimum among graphs on six or seven vertices of rank at least six. More generally, the same argument gives a finite prescription for the minimum of the right-hand side of @monotone under a rank lower bound $r>a+b$. That minimum is positive because in each finite witness at least one nonzero eigenvalue survives the trimming.

= Exact finite certificate

We used two different enumeration and arithmetic routes. The first produces each class by adding a vertex in every possible way to representatives at the previous order. It sorts vertices by the invariant pair consisting of degree and the multiset of neighbor degrees. The canonical code is the minimum adjacency bit string over permutations within those sorted classes. Every graph arises by this recursion because deleting a vertex gives a graph at the previous order. Equal codes certify isomorphism, and isomorphic graphs give equal codes. The check uses integer characteristic polynomials and exact rational root isolation, preserving multiplicities. The least degree with nonzero coefficient is the nullity. The resulting root intervals give lower bounds on $T_p$ by interval evaluation of $|x|^p$ in the retained coordinates. This route alone certifies $T_1>1.47$ and $T_2>0.79$ for all the finite witnesses.

The second route reads representatives from the graph atlas @atlas and uses rational inertia rather than characteristic polynomials. For a rational number $t$, the number of eigenvalues below $t$ is the negative index of $A-t I$, and the multiplicity of $t$ is its nullity. Successive congruence eliminations use a nonzero diagonal entry as a one-dimensional pivot or, if the diagonal is zero and some off-diagonal entry $q$ is nonzero, use a block with diagonal entries zero and off-diagonal entries $q$. That block has one positive and one negative eigenvalue. Its Schur complement is taken over the rationals. A remaining zero matrix contributes exactly its order to the nullity. Binary search on a grid of spacing $10^(-5)$ uses these counts to enclose each ordered eigenvalue, counting repeated roots separately. No floating-point eigenvalue computation is used by this route.

#block(breakable: false, width: 100%)[
#align(center)[
  #table(
    columns: (auto, auto, auto, auto, auto),
    inset: (x: 7pt, y: 5pt),
    align: center,
    stroke: (x: none, y: 0.45pt + luma(195)),
    [Order], [Unlabeled graphs], [Rank $>=6$], [$T_1<1.48$], [$T_2<0.791$],
    [6], [156], [57], [1], [1],
    [7], [1044], [779], [1], [1],
  )
]
]

For each exceptional entry, the upper interval bound is strictly below the cutoff; every other finite witness has a lower bound at least the cutoff. For $p=1$ the only exceptions are $W_1$ and $W_1$ with an isolated vertex; for $p=2$ they are $W_2$ and $W_2$ with an isolated vertex. Adding an isolated vertex preserves $T_p$ in these cases: both graphs have at least two negative eigenvalues by interlacing with the triangle on vertices 0, 1 and 5 in the first case and on 0, 1 and 4 in the second, and at least one positive eigenvalue. The extra zero changes no retained nonzero term. The exact enclosures for the exceptions imply the intervals in Theorem 1. The theorem follows from the finite reduction, and $W_p$ attains the corresponding bound. The two scripts, their replay logs and dependency versions accompany this preprint.

= Consequences for spectral distance

*Corollary 4.* Let $B$ be a graph whose adjacency spectrum has one positive eigenvalue, two negative eigenvalues and all remaining eigenvalues zero. For every graph $H$ of the same order, $D_p(B,H)<c_p$ implies $rk A(H)<=5$, for $p in {1,2}$.

_Proof._ The entries at positions $3, dots, N-1$ of the increasing spectrum of $B$ are zero. Hence $D_p(B,H) >= T_p(H)$, and Theorem 1 gives the result. $square$

The hypothesis on $B$ includes every complete tripartite graph with three nonempty parts, with or without added isolated vertices. The restriction to the span of the normalized indicators of the three parts is congruent to the adjacency matrix of $K_3$ by a positive diagonal scaling, and the orthogonal complement has eigenvalue zero. In particular, for $B=K_(n,n,n)$ we have $D_2(B,H)<2/3<c_2$ whenever the premise of Problem 21 of @jss holds. This proves its conclusion even for disconnected $H$.

*Corollary 5.* For $n>=3$, every nonisomorphic graph of order $3n$ minimizing $D_1$ or $D_2$ from $K_(n,n,n)$ has adjacency rank at most five.

_Proof._ The competitor $cal(H)_n$ constructed in @jss is nonisomorphic to $K_(n,n,n)$. By Theorem 6 and Remark 7 there, its Manhattan distance is less than $1+2/(3n)<=11/9<c_1$. The proof of Theorem 15(i) there also bounds its squared distance by $1/2+1/(3n)+2/(9n^2) < 2/3 < c_2$. Any minimizing competitor thus satisfies the hypothesis of Corollary 4 in the relevant distance. $square$

The reduction applies to all minimizers; it does not identify the minimizing graph or establish the uniqueness proposed in Conjecture 20 of @jss.

*Development disclosure.* OpenAI models were used to develop the argument, implement the certificates and prepare this manuscript. The mathematical claim rests on the proof and the supplied exact checks.

#bibliography("references.bib", title: "References", style: "ieee")
