#!/usr/bin/env python3
"""Exact replay for the seven-vertex spectral obstruction (Python, SymPy)."""
from collections import defaultdict
from itertools import permutations, product
from sympy import Matrix, Poly, Symbol, Rational

def invariant_partition(adj):
    n=len(adj)
    deg=[a.bit_count() for a in adj]
    parts=defaultdict(list)
    for i in range(n):
        profile=(deg[i],tuple(sorted(deg[j] for j in range(n) if (adj[i]>>j)&1)))
        parts[profile].append(i)
    return tuple(tuple(p) for _,p in sorted(parts.items()))

def canon(adj):
    n=len(adj)
    parts=invariant_partition(adj)
    # Degree and neighbor-degree profiles are invariants. Only permutations
    # within a common profile need be considered, with profiles sorted.
    best=None
    for ps in product(*(permutations(part) for part in parts)):
        order=tuple(i for p in ps for i in p)
        val=0
        for i in range(n):
            for j in range(i):
                val=(val<<1)|((adj[order[i]]>>order[j])&1)
        if best is None or val<best:
            best=val
    return best

def decode(n,key):
    rows=[0]*n
    for i in range(n-1,-1,-1):
        for j in range(i-1,-1,-1):
            if key&1:
                rows[i]|=1<<j
                rows[j]|=1<<i
            key>>=1
    return rows

def extend(n,keys):
    keys2=set()
    for key in keys:
        rows=decode(n,key)
        for nbr in range(1<<n):
            aug=[a|(((nbr>>i)&1)<<n) for i,a in enumerate(rows)]+[nbr]
            keys2.add(canon(aug))
    return keys2

def min_square(a,b):
    if a<=0<=b:
        return 0
    return min(a*a,b*b)

def main():
    x=Symbol('x')
    graphs={0}
    expected={1:1,2:2,3:4,4:11,5:34,6:156,7:1044}
    total=0
    worst=None
    abs_worst=None
    for n in range(1,8):
        graphs=extend(n-1,graphs)
        assert len(graphs)==expected[n],(n,len(graphs))
        if n<6:
            continue
        certified=0
        for g in sorted(graphs):
            rows=decode(n,g)
            p=Matrix(n,n,lambda i,j:(rows[i]>>j)&1).charpoly(x).as_poly()
            nullity=min(power[0] for power,_ in p.terms())
            if n-nullity<6:
                continue
            intervals=p.intervals(eps=Rational(1,10000))
            roots=sorted(pair for pair,num in intervals for _ in range(num))
            assert len(roots)==n
            lower=sum(min_square(a,b) for a,b in roots[2:-1])
            assert lower>Rational(79,100),(n,g,lower)
            abs_lower=sum(0 if a<=0<=b else min(abs(a),abs(b)) for a,b in roots[2:-1])
            assert abs_lower>Rational(147,100),(n,g,abs_lower)
            if abs_worst is None or abs_lower<abs_worst: abs_worst=abs_lower
            if worst is None or lower<worst[0]:
                worst=lower,n,g,p.as_expr()
            certified+=1
        print(f"n={n}: {len(graphs)} unlabeled graphs, {certified} rank >= 6, certified tail > 79/100",flush=True)
        total+=certified
    assert total==836
    print("Minimum certified lower bounds (squared, absolute):",worst[0],float(worst[0]),abs_worst,float(abs_worst))
    print("Smallest-bound representative:",worst[1:])

if __name__=="__main__":
    main()
