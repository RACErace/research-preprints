# Sharp adjacency spectral-tail bounds at rank six

Paper: spectral-rank-six.pdf. Editable source: main.typ + references.bib (Typst 0.15.2).

Install requirements.txt, then run:
```sh
python -B verify.py
python -B verify_independent.py
```

The first script constructs the graph census and isolates the roots of integer characteristic polynomials. The second uses the NetworkX atlas and exact rational inertia, without a floating-point eigensolver. Both logs are included. Keep assertions enabled.
