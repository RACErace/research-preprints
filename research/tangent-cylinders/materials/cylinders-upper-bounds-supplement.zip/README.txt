九根圆柱与单位球相切的半径上界
2026-11-26

R_N 表示 N 根等半径、内部互不相交的无限长圆柱同时与单位球相切时的最大半径。
本包的严格结果为 R_9 < 6453/10000 和 R_10 < 619/1000。目标半径为
sin(pi/8)/(1-sin(pi/8)) = 0.6199144044...。在该半径上，最大根数为 8 或 9。

整数重放（Python 3.9+ 标准库）
  python verify.py nine.json
  python independent.py nine.json
  python verify.py ten.json
  python independent.py ten.json
  python geometry.py --list

九柱文件有 22 个整数向量，最高 ell=14。两套程序独立构造正型多项式并覆盖
969 个终端盒，最大深度为 20。十柱文件有 14 个整数向量，最高 ell=10，
对应 7 个终端盒、最大深度 3。原始输出保存在 replay.txt。

proof.pdf / proof.md   中文推导、文献版本和 47 个树形的存在性归约。
nine.json / ten.json   两份有限整数证书，各自含待排除的基数及有理半径。
verify.py             切比雪夫展开、归一化 Bernstein 系数、de Casteljau 细分。
independent.py        偶数二项式展开、齐次 Bernstein 基、直接变量替换细分。
geometry.py           九顶点树的完备枚举和猜想半径的精确比较。
discover.py           候选发现程序，需要 NumPy、SciPy、CVXPY 和 Clarabel。
glazyrin-replay.json  Glazyrin 作者程序在 N=9 案例的云端完整重放输出。
SHA256SUMS            本包各文件的 SHA-256（清单自身除外）。

发现九柱证书所用的参数为
  python discover.py 14 6453/10000 new-nine.json --rounds 22 --grid 23
十柱见证起初在 6199/10000 处用有限网格求得，最终在更低半径 619/1000
处通过整数重放。证明使用已提供的整数，不需要在不同数值环境中重新发现它们。

