#!/usr/bin/env python3
"""Exact two-point exclusion of nine tangent cylinders. Python standard library.

Run: python verify.py certificate.json
Use --radius a/b to test the same kernel at another positive rational radius.
All arithmetic in the polynomial, Bernstein transformation, subdivision and
sign decisions is integer arithmetic. Fractions are used to read the radius.
"""
import argparse
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json
from math import comb, lcm
from pathlib import Path


@lru_cache(None)
def cheb(k, sign):
    """Power coefficients of T_k(sign*(1-2x))."""
    if k == 0:
        return (1,)
    if k == 1:
        return (sign, -2*sign)
    prev = cheb(k-1, sign)
    lower = cheb(k-2, sign)
    ans = [0]*(k+1)
    for j, item in enumerate(prev):
        ans[j] += 2*sign*item
        ans[j+1] -= 4*sign*item
    for j, item in enumerate(lower):
        ans[j] -= item
    return tuple(ans)


def build_gap(terms, degree, count=9):
    """G=-F(1)-(count-1)F, as raw Bernstein in t and power series in y,z."""
    coeff = defaultdict(int)
    trace = 0
    for term in terms:
        ell, c = term["ell"], term["c"]
        n = 2*ell
        if not 1 <= ell <= degree or len(c) != n+1:
            raise ValueError("invalid symmetric power")
        if any(type(value) is not int for value in c):
            raise ValueError("certificate data must be integers")
        trace += sum(comb(n,i)*x*x for i,x in enumerate(c))
        for i, ci in enumerate(c):
            if not ci:
                continue
            for j, cj in enumerate(c):
                if not cj or (j-i)%2:
                    continue
                base = -(count-1)*ci*cj*comb(n,j)
                a_poly = cheb(abs(n-i-j)//2, 1)
                b_poly = cheb(abs(j-i)//2, -1)
                for k in range(max(0,i-j), min(i,n-j)+1):
                    p = ell + (i-j)//2 - k
                    weight = base * (-1)**k * comb(n-j,k) * comb(j,i-k)
                    for u in range(degree-ell+1):
                        elevated = weight * comb(degree-ell,u)
                        for a, aa in enumerate(a_poly):
                            for b, bb in enumerate(b_poly):
                                coeff[p+u,a,b] += elevated*aa*bb
    if trace <= 0:
        raise ValueError("zero kernel")
    for t in range(degree+1):
        coeff[t,0,0] -= trace*comb(degree,t)
    return {k:c for k,c in coeff.items() if c}, trace


def binomial_scale(d):
    return lcm(*(comb(d,i) for i in range(d+1)))


def cube_bernstein(coeff, L, h):
    """Return one positively scaled integer Bernstein tensor on the cube.

    y=(A+(B-A)v)/B and z=(A+(B-A)v*w)/(A+(B-A)v).
    Multiply the gap by B**L * (A+(B-A)v)**L, a positive polynomial.
    """
    A, B = h.numerator, h.denominator
    D = B-A
    if not 0 < A < B:
        raise ValueError("radius parameter outside (0,1)")
    shape = (L+1,2*L+1,L+1)
    T,V,W = shape
    tensor = [0]*(T*V*W)
    powers = {}
    for (t,a,b), value in coeff.items():
        if (a,b) not in powers:
            m = L+a-b
            ym = [comb(m,i)*A**(m-i)*D**i for i in range(m+1)]
            zm = [comb(b,j)*A**(b-j)*D**j for j in range(b+1)]
            scalar = B**(L-a)
            powers[a,b] = [(i+j,j,scalar*yi*zj) for i,yi in enumerate(ym)
                           for j,zj in enumerate(zm)]
        for v,w,item in powers[a,b]:
            tensor[(t*V+v)*W+w] += value*item
    # t already uses the unnormalized degree L Bernstein monomials.
    st = binomial_scale(L)
    for t in range(T):
        scale = st//comb(L,t)
        start = t*V*W
        for ix in range(start,start+V*W):
            tensor[ix] *= scale
    # On each of the other axes, x^j has normalized Bernstein coefficients
    # binom(i,j)/binom(d,j) for i>=j, zero otherwise.
    for axis in (1,2):
        d = shape[axis]-1
        stride = W if axis==1 else 1
        scale = binomial_scale(d)
        matrix = [[comb(i,j)*(scale//comb(d,j)) for j in range(i+1)]
                  for i in range(d+1)]
        outer = len(tensor)//((d+1)*stride)
        for group, off in product(range(outer), range(stride)):
            start = group*(d+1)*stride + off
            prev = tensor[start:start+(d+1)*stride:stride]
            for i, row in enumerate(matrix):
                tensor[start+i*stride] = sum(x*y for x,y in zip(row,prev))
    return tensor, shape


def subdivide(tensor, shape, axis):
    """Midpoint de Casteljau, all child entries scaled by 2**degree."""
    d = shape[axis]-1
    stride = (shape[1]*shape[2],shape[2],1)[axis]
    outer = len(tensor)//((d+1)*stride)
    low, high = [0]*len(tensor), [0]*len(tensor)
    for group, off in product(range(outer),range(stride)):
        start = group*(d+1)*stride + off
        vals = tensor[start:start+(d+1)*stride:stride]
        for k in range(d+1):
            low[start+k*stride] = vals[0] << (d-k)
            high[start+(d-k)*stride] = vals[-1] << (d-k)
            vals = [x+y for x,y in zip(vals,vals[1:])]
    return low, high


def cover(coeff, shape, limit=42):
    leaves = nodes = depth_max = 0
    stack = [(coeff,"")]
    corners = [(i*shape[1]+j)*shape[2]+k for i,j,k in
               product((0,shape[0]-1),(0,shape[1]-1),(0,shape[2]-1))]
    while stack:
        vals, path = stack.pop()
        depth = len(path)
        nodes += 1
        if min(vals)>0:
            leaves += 1
            depth_max = max(depth_max,depth)
            continue
        if min(vals[i] for i in corners) <= 0:
            raise ValueError("nonpositive exact gap at a box corner, path "+path)
        if depth>=limit:
            raise ValueError("inconclusive at subdivision limit, path "+path)
        left,right = subdivide(vals, shape, depth%3)
        stack.extend(((right,path+"1"),(left,path+"0")))
    return nodes, leaves, depth_max


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("certificate",type=Path)
    p.add_argument("--radius")
    p.add_argument("--count",type=int)
    args = p.parse_args()
    cert = json.loads(args.certificate.read_text())
    r = Fraction(args.radius or cert["radius"])
    if args.count is None:
        args.count=cert.get("count",9)
    if args.count < 2:
        raise ValueError("need at least two lines")
    if r <= 0:
        raise ValueError("radius must be positive")
    h = (r/(1+r))**2
    coeff,trace = build_gap(cert["terms"],cert["degree"],args.count)
    tensor,shape = cube_bernstein(coeff,cert["degree"],h)
    nodes,leaves,depth = cover(tensor,shape)
    print(f"radius = {r}, squared half-separation = {h}")
    print(f"F(identity) = {trace}; symmetric powers through degree {cert['degree']}")
    print(f"strictly positive gap on {leaves} leaves ({nodes} nodes, depth {depth})")
    print(f"PASS: R_{args.count} < {r}")


if __name__=="__main__":
    main()

