#!/usr/bin/env python3
"""Enumerate the 47 unlabeled tree systems in the nine-line reduction.
python geometry.py --list prints one parent list per tree (vertex 0 is root).
Only the standard library is required.
"""
import argparse
from fractions import Fraction


def code(graph, root, parent=-1):
    return "("+"".join(sorted(code(graph,x,root) for x in graph[root] if x!=parent))+")"


def canonical(graph):
    # A rooted parenthesis code specifies the rooted tree recursively.
    # Minimizing over all possible roots removes the root label.
    return min(code(graph,i) for i in range(len(graph)))


def trees(order):
    by_key={"()":((),)}
    for n in range(1,order):
        larger={}
        for g in by_key.values():
            for attach in range(n):
                h=list(g)
                h[attach]=h[attach]+(n,)
                h.append((attach,))
                new_graph=tuple(h)
                larger[canonical(new_graph)]=new_graph
        by_key=larger
    return by_key


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--list",action="store_true")
    args=p.parse_args()
    shapes=trees(9)
    if len(shapes)!=47:
        raise ValueError("unexpected tree count")
    if args.list:
        for key,g in sorted(shapes.items()):
            print(key, "parents", [min(x for x in g[i] if x<i) for i in range(1,9)])
    # r/(1+r) < sin(pi/8) iff 2-4*(r/(1+r))^2 > sqrt(2).
    r=Fraction(619,1000)
    b=2-4*(r/(1+r))**2
    if not (b>0 and b*b>2):
        raise ValueError("threshold comparison failed")
    print("47 unlabeled trees on 9 vertices; 8 edge charts of at most two continuous variables")
    print("Verified 619/1000 < sin(pi/8)/(1-sin(pi/8)) by integer comparison")


if __name__=="__main__":
    main()

