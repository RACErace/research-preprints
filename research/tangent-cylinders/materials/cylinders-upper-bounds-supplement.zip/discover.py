"""Find candidate positive-type kernels. Numerical discovery only.

The exact checker reads the integer vectors in the output, never the solver.
Run with python discover.py DEGREE RADIUS OUT.json [--rounds N].
"""
import argparse
import json
import math
import os
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

import numpy as np
from scipy.optimize import minimize
from scipy.ndimage import maximum_filter
from scipy.fft import dctn
from numpy.polynomial.chebyshev import chebvander
import cvxpy as cp


def layouts(degree):
    blocks = []
    for ell in range(1, degree + 1):
        n = 2 * ell
        for parity in (0, 1):
            indices = [j for j in range(parity, ell + 1, 2)
                       if j < ell or ell % 2 == 0]
            if not indices:
                continue
            vectors = np.zeros((n + 1, len(indices)))
            for k, j in enumerate(indices):
                if j == ell:
                    vectors[j, k] = 1
                else:
                    vectors[j, k] = 1 / math.sqrt(2)
                    vectors[n-j, k] = (-1)**ell / math.sqrt(2)
            blocks.append((ell, indices, vectors))
    return blocks


def entry_terms(ell, i, j):
    n = 2 * ell
    ratio = math.sqrt(math.comb(n,j) / math.comb(n,i))
    return [(ell + (i-j)//2 - k, ratio * (-1)**k *
             math.comb(n-j, k) * math.comb(j, i-k))
            for k in range(max(0, i-j), min(i, n-j)+1)]


def feature_matrix(blocks, locations, h):
    # Cube coordinates t, v, w.  y=h+(1-h)v, z=(h+(y-h)w)/y.
    t, v, w = locations.T
    y = h + (1-h) * v
    z = (h + (y-h) * w) / y
    return absolute_features(blocks, t, y, z)


def absolute_features(blocks, t, y, z):
    degree = max(ell for ell, _, _ in blocks)
    ca = chebvander(1-2*y, degree)
    cb = chebvander(2*z-1, degree)
    tp = [t**i for i in range(degree+1)]
    op = [(1-t)**i for i in range(degree+1)]
    columns = []
    for ell, indices, vectors in blocks:
        n = 2*ell
        for a in range(len(indices)):
            for b in range(a, len(indices)):
                total = np.zeros(len(t))
                for i in np.flatnonzero(vectors[:,a]):
                    for j in np.flatnonzero(vectors[:,b]):
                        for ii, jj in ([(i,j)] if a==b else [(i,j),(j,i)]):
                            radial = sum(kc * tp[p] * op[ell-p]
                                         for p,kc in entry_terms(ell, int(ii), int(jj)))
                            total += (vectors[i,a] * vectors[j,b] * radial *
                                      ca[:,abs(n-ii-jj)//2] *
                                      cb[:,abs(jj-ii)//2])
                columns.append(total)
    return np.stack(columns, axis=1)


def mesh(count):
    grid = (1 - np.cos(np.linspace(0, np.pi, count))) / 2
    return np.stack(np.meshgrid(grid, grid, grid, indexing='ij'), axis=-1).reshape(-1,3)


def refine_peaks(coeff, fit_features, blocks, locations, scores, grid, h, obj):
    degree = max(ell for ell,_,_ in blocks)
    size = degree+1
    table = (fit_features@coeff).reshape((size,size,size))
    c = dctn(table, type=1) / degree**3
    for axis in range(3):
        first_last = [slice(None)]*3
        first_last[axis] = [0,-1]
        c[tuple(first_last)] *= 0.5
    indices = np.arange(size)

    def one(x):
        theta = np.arccos(np.clip(2*x-1,-1,1))
        values = np.cos(indices*theta)
        if x<=1e-12:
            slope = 2*indices*indices*(-1.0)**(indices+1)
        elif x>=1-1e-12:
            slope = 2*indices*indices
        else:
            slope = 2*indices*np.sin(indices*theta)/np.sin(theta)
        return values,slope

    def neg_score(p):
        t,v,w = p
        y = h+(1-h)*v
        z = h/y+(1-h/y)*w
        a, da = one(t)
        b, db = one(y)
        d, dd = one(z)
        planar = (c @ d)
        value = a @ planar @ b
        ft,fy,fz = da@planar@b, a@planar@db, a@(c@dd)@b
        return -value,-np.array((ft,(1-h)*(fy-fz*h*(1-w)/y**2),fz*(1-h/y)))

    cube = scores.reshape((grid,grid,grid))
    near = (cube >= maximum_filter(cube,size=3,mode="nearest")-1e-14) & (cube>=obj-0.003)
    starts = []
    seen = set()
    maxima = []
    for ix in np.flatnonzero(near):
        point = locations[ix]
        # Grid faces with redundant phase parameters can produce plateaus.
        if any(np.sum((point-p)**2)<0.008 for p in starts):
            continue
        starts.append(point)
        out = minimize(neg_score,point,jac=True,bounds=[(0,1)]*3,
                       method="L-BFGS-B",options={"ftol":1e-14,"gtol":1e-11,"maxiter":55})
        label = tuple(np.round(out.x,6))
        if label not in seen:
            seen.add(label)
            maxima.append((-out.fun,out.x))
    return sorted(maxima,key=lambda pair: -pair[0])


def save_integer_factor(path, blocks, matrices, radius, degree):
    terms = []
    for (ell, _, vectors), mat in zip(blocks,matrices):
        ev, u = np.linalg.eigh((mat.value + mat.value.T)/2)
        norm = np.sqrt([math.comb(2*ell, j) for j in range(2*ell+1)])
        for lam, vv in zip(ev, u.T):
            if lam < 1e-10:
                continue
            arr = np.rint((vectors@vv)*math.sqrt(lam)*10**8/norm).astype(np.int64)
            if np.any(arr):
                terms.append({"ell":ell,"c":[int(v) for v in arr]})
    path.write_text(json.dumps({"radius":radius,"degree":degree,"terms":terms},
                               separators=(",",":"))+"\n")


def solve(args):
    degree, radius = args.degree, args.radius
    from fractions import Fraction
    r = float(Fraction(radius))
    h = (r/(1+r))**2
    blocks = layouts(degree)
    locations = mesh(5)
    data = feature_matrix(blocks, locations, h)
    probes = mesh(args.grid)
    probe_features = feature_matrix(blocks, probes, h)
    fit_axis = (1+np.cos(np.pi*np.arange(degree+1)/degree))/2
    fit_locations = np.stack(np.meshgrid(fit_axis,fit_axis,fit_axis,indexing="ij"),axis=0)
    fit_features = absolute_features(blocks, *fit_locations.reshape(3,-1))
    matrices = [cp.Variable((len(ix),len(ix)), symmetric=True)
                for _,ix,_ in blocks]
    coords = cp.hstack([var[a,b] for var in matrices
                        for a in range(var.shape[0]) for b in range(a,var.shape[0])])
    offset = cp.Variable()
    fixed = [var >> 0 for var in matrices] + [sum(cp.trace(var) for var in matrices)==1]
    for k in range(args.rounds):
        prog = cp.Problem(cp.Minimize(offset), fixed + [data @ coords <= offset])
        prog.solve(solver="CLARABEL", tol_gap_abs=3e-8, tol_feas=3e-8,
                   tol_gap_rel=3e-8, max_iter=120, max_threads=1)
        if coords.value is None:
            raise RuntimeError(prog.status)
        coeff = coords.value
        scores = probe_features @ coeff
        print(k, len(data), 'sample bound', offset.value, 'grid maximum', max(scores),
              'N relaxed', 1-1/max(scores) if max(scores)<0 else 'none', flush=True)
        save_integer_factor(args.output, blocks, matrices, radius, degree)
        order = np.argsort(scores)[::-1]
        selected = []
        cutoff = offset.value+5e-7
        for ix in order:
            if scores[ix] < cutoff or len(selected)>=70:
                break
            point = probes[ix]
            if all(np.sum((point-other)**2)>0.012 for other in selected):
                selected.append(point)
        if k>=4:
            peaks = refine_peaks(coeff,fit_features,blocks,probes,scores,args.grid,h,offset.value)
            print("   continuous peak", peaks[0][0] if peaks else None,flush=True)
            selected.extend(p for val,p in peaks if val>offset.value+2e-7)
        if not selected:
            break
        extra = np.asarray(selected)
        data = np.vstack((data, feature_matrix(blocks,extra,h)))
        if len(data)>2000:
            raise RuntimeError("constraint cap reached")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("degree",type=int)
    p.add_argument("radius")
    p.add_argument("output",type=Path)
    p.add_argument("--rounds",type=int,default=14)
    p.add_argument("--grid",type=int,default=21)
    solve(p.parse_args())

