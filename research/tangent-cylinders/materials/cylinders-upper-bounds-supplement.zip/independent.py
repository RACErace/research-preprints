#!/usr/bin/env python3
"""Independent integer replay in homogeneous Bernstein bases.

This implementation has no imports from verify.py. The two-angle factors come
from even binomial terms in complex powers. Cube substitution and bisection
use direct homogeneous expansion. Run with the same arguments as verify.py.
"""
import argparse
from fractions import Fraction
from functools import lru_cache
import json
from math import comb
from pathlib import Path


@lru_cache(None)
def angular(order, L, swapped):
    # Re[(sqrt(1-y)+i sqrt(y))^(2*order)], elevated to degree L.
    raw = [0]*(L+1)
    for k in range(order+1):
        initial = (-1)**k * comb(2*order,2*k)
        j = order-k if swapped else k
        for e in range(L-order+1):
            raw[j+e] += initial * comb(L-order,e)
    return raw


def original(cert, count):
    L = cert["degree"]
    K = L+1
    data = [0]*(K**3)
    trace = 0
    for term in cert["terms"]:
        ell, c = term["ell"],term["c"]
        n = 2*ell
        if not 1<=ell<=L or len(c)!=n+1 or any(type(x) is not int for x in c):
            raise ValueError("invalid vector")
        trace += sum(comb(n,j)*cj**2 for j,cj in enumerate(c))
        for i,ci in enumerate(c):
            for j,cj in enumerate(c):
                if not ci*cj or (i+j)%2:
                    continue
                ay = angular(abs(n-i-j)//2,L,False)
                az = angular(abs(i-j)//2,L,True)
                radial = [0]*K
                for k in range(max(0,i-j),min(i,n-j)+1):
                    p = (n+i-j)//2-k
                    val = (1-count)*comb(n,j)*ci*cj*(-1)**k*comb(n-j,k)*comb(j,i-k)
                    for e in range(L-ell+1):
                        radial[p+e] += val*comb(L-ell,e)
                yz = [x*y for x in ay for y in az]
                for p,v in enumerate(radial):
                    if v:
                        base = p*K*K
                        for flat,u in enumerate(yz):
                            data[base+flat] += v*u
    if trace<=0:
        raise ValueError("zero kernel")
    for t in range(K):
        for y in range(K):
            for z in range(K):
                data[(t*K+y)*K+z] -= trace*comb(L,t)*comb(L,y)*comb(L,z)
    return data,trace


def cube(raw,L,h):
    A,B = h.numerator,h.denominator
    D = B-A
    T,V,W = L+1,2*L+1,L+1
    target = [0]*(T*V*W)
    # Coefficients of (A+D*v*w)^b in raw bivariate homogeneous basis.
    for b in range(L+1):
        zb = {}
        for i in range(b+1):
            for j in range(b+1):
                zb[i,j] = comb(b,i)*sum(comb(i,m)*comb(b-i,j-m)*B**m*A**(b-m)
                                        for m in range(max(0,i+j-b),min(i,j)+1))
        for a in range(L+1):
            # Y^a (1-v)^(L-a) Z^b v^(L-b) (1-w)^(L-b).
            basis = {}
            scale = D**(2*L-a-b)
            for k in range(a+1):
                weight = scale*comb(a,k)*A**(a-k)*B**k
                for (i,j),item in zb.items():
                    index=(L-b+i+k)*W+j
                    basis[index] = basis.get(index,0)+weight*item
            for t in range(T):
                src=raw[(t*T+a)*T+b]
                for index,w in basis.items():
                    target[t*V*W+index] += src*w
    return target,(T,V,W)


@lru_cache(None)
def transforms(d):
    left = [[comb(d-i,j-i) for i in range(j+1)] for j in range(d+1)]
    right = [[comb(i,j) for i in range(j,d+1)] for j in range(d+1)]
    return left,right


def halve(raw,shape,axis):
    d=shape[axis]-1
    stride=(shape[1]*shape[2],shape[2],1)[axis]
    lt,rt=transforms(d)
    left,right=[0]*len(raw),[0]*len(raw)
    for block in range(0,len(raw),stride*(d+1)):
        for off in range(stride):
            start=block+off
            line=raw[start:start+(d+1)*stride:stride]
            for j in range(d+1):
                ix=start+j*stride
                left[ix]=sum(a*b for a,b in zip(lt[j],line)) << (d-j)
                right[ix]=sum(a*b for a,b in zip(rt[j],line[j:])) << j
    return left,right


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate",type=Path)
    parser.add_argument("--count",type=int)
    parser.add_argument("--radius")
    args=parser.parse_args()
    cert=json.loads(args.certificate.read_text())
    r=Fraction(args.radius or cert["radius"])
    if args.count is None:
        args.count=cert.get("count",9)
    if r<=0 or args.count<2:
        raise ValueError("invalid claim")
    raw,trace=original(cert,args.count)
    root,shape=cube(raw,cert["degree"],(r/(1+r))**2)
    stack=[(root,0)]
    leaves=deepest=0
    while stack:
        box,depth=stack.pop()
        if min(box)>0:
            leaves+=1
            deepest=max(deepest,depth)
        elif depth>=42:
            raise ValueError("positivity not certified")
        else:
            lft,rgt=halve(box,shape,depth%3)
            stack.extend(((rgt,depth+1),(lft,depth+1)))
    print(f"Independent homogeneous replay: trace {trace}, {leaves} leaves, depth {deepest}")
    print(f"PASS: R_{args.count} < {r}")


if __name__=="__main__":
    main()

