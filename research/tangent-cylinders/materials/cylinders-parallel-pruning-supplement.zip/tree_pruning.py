#!/usr/bin/env python3
"""Exhaustive isomorphism-reduced coloring of the 47 nine-vertex contact trees."""
from collections import Counter
import argparse


def rooted(g,root,parent,colors):
    forms=[]
    for w in g[root]:
        if w!=parent:
            edge=(min(w,root),max(w,root))
            forms.append(colors.get(edge,"")+rooted(g,w,root,colors))
    return "("+ "".join(sorted(forms))+")"


def canonical(g,colors):
    return min(rooted(g,v,-1,colors) for v in range(len(g)))


def tree_list():
    prev={"()":((),)}
    for order in range(1,9):
        current={}
        for g in prev.values():
            for v in range(order):
                new=list(g)
                new[v]=new[v]+(order,)
                new.append((v,))
                new=tuple(new)
                current[canonical(new,{})]=new
        prev=current
    return prev


def tally(g):
    n=len(g)
    edges=sorted((i,j) for i,ns in enumerate(g) for j in ns if i<j)
    classes={}
    for mask in range(1<<len(edges)):
        color={e:("p" if mask&(1<<k) else "s") for k,e in enumerate(edges)}
        label=canonical(g,color)
        if label in classes: continue
        done=set();sizes=[]
        for v in range(n):
            if v in done: continue
            work=[v];size=0;done.add(v)
            while work:
                x=work.pop();size+=1
                for y in g[x]:
                    if y not in done and color[min(x,y),max(x,y)]=="p":
                        done.add(y);work.append(y)
            sizes.append(size)
        sizes.sort(reverse=True)
        if sizes[0]>=6: verdict="old"
        elif len(sizes)<=2: verdict="old_coplanar"
        elif sizes[0]==5: verdict="five"
        elif sizes[:2]==[4,4]: verdict="double_four"
        else: verdict="open"
        classes[label]=verdict
    return Counter(classes.values())


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--table",action="store_true")
    opts=p.parse_args()
    trees=tree_list()
    if len(trees)!=47: raise ValueError("unexpected number of tree shapes")
    total=Counter()
    if opts.table: print("tree\tshape\told_ge_6\told_two_classes\tnew_5\ttwo_4\tremaining")
    for index,(shape,g) in enumerate(sorted(trees.items()),1):
        row=tally(g);total.update(row)
        if opts.table: print(index,shape,*(row[c] for c in ("old","old_coplanar","five","double_four","open")),sep="\t")
    if opts.table: return
    print("47 uncolored trees,",sum(total.values()),"inequivalent two-colored trees.")
    print("Previously excluded by a parallel component of size >=6:",total["old"])
    print("Additional old coplanar case (5+4):",total["old_coplanar"])
    print("Additional prunings by the five-parallel theorem:",total["five"])
    print("Two parallel components of size 4:",total["double_four"])
    print("Remaining after these component-size tests:",total["open"])


if __name__=="__main__":
    main()

