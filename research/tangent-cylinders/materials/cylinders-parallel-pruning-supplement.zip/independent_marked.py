#!/usr/bin/env python3
"""Independent replay using power coefficients and normalized Bernstein bases."""
import argparse
from collections import defaultdict
from fractions import Fraction
from math import comb, lcm
from pathlib import Path
import json
from bernstein_power import build_gap, cube_bernstein, cover


def affine_box(poly,L,c):
    # Normalized degree-L Bernstein values of (c+(1-c)*v)^p.
    # Compute by choosing p slots from a degree-L elevation, exactly j of
    # them among the i slots at the right endpoint of the polar form.
    A,B=c.numerator,c.denominator
    common=lcm(*(comb(L,j) for j in range(L+1)))
    factor=common*B**L
    matrix=[]
    for i in range(L+1):
        row=[]
        for p in range(L+1):
            numerator=sum(comb(i,j)*comb(L-i,p-j)*B**j*A**(p-j)
                          for j in range(max(0,p-(L-i)),min(p,i)+1))
            row.append(numerator*(factor//(comb(L,p)*B**p)))
        matrix.append(row)
    sz=L+1
    output=[0]*sz**3
    for (t,y,z),coeff in poly.items():
        coeff*=common//comb(L,t)
        for i in range(sz):
            for j in range(sz):
                output[(t*sz+i)*sz+j]+=coeff*matrix[i][y]*matrix[j][z]
    return output,(sz,sz,sz)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("certificate",type=Path)
    d=json.loads(p.parse_args().certificate.read_text())
    L=d["degree"];K=d["weight_denominator"];n=d["count"]
    M=Fraction(d["pair_bound"]);B=Fraction(d["local_bound"])
    h=Fraction(d["h"]);c=Fraction(d["cutoff"])
    # h < (2-sqrt(2))/4 and c < cos(pi/8)^2 or cos(5*pi/32)^2.
    if not (0<h<1 and 0<c<1 and 2-4*h>0 and (2-4*h)**2>2):
        raise ValueError("invalid pair relaxation")
    if n==4:
        ok=(4*c-2<0 or (4*c-2)**2<2)
    elif n==5:
        v=1-2*(2*c-1)**2
        ok=v>0 and (2-4*v*v<0 or (2-4*v*v)**2<2)
    else:
        ok=False
    if not ok or type(K) is not int or K<=0:
        raise ValueError("invalid local relaxation or weight scale")
    pair=defaultdict(int);local=defaultdict(int)
    S=cost=0
    for term in d["terms"]:
        weight=term["weight"]
        if type(weight) is not int:
            raise ValueError("weight must be an integer")
        # Recover -f as a polynomial from -f(identity)-f.
        minus,norm=build_gap([term],L,2)
        for t in range(L+1):
            key=(t,0,0)
            minus[key]=minus.get(key,0)+norm*comb(L,t)
        for key,coef in minus.items():
            pair[key]+=M.denominator*coef
            local[key]+=B.denominator*weight*coef
        S+=norm;cost+=weight*weight*norm
    for t in range(L+1):
        pair[t,0,0]+=M.numerator*S*comb(L,t)
        local[t,0,0]+=B.numerator*K*S*comb(L,t)
    print("Pair cover (nodes, leaves, depth)",cover(*cube_bernstein(pair,L,h)))
    print("Marked cover (nodes, leaves, depth)",cover(*affine_box(local,L,c)))
    bound=n+n*(n-1)*M+2*n*B+Fraction(cost,K*K*S)
    if bound>=0:
        raise ValueError("moment does not exclude the claim")
    print("Independent norm upper bound",bound)
    print("PASS: at most",n-1,"separated lines in the marked box")


if __name__=="__main__":
    main()

