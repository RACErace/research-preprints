九柱插入猜想 13.1 的平行轴剪枝
2026 年 11 月 26 日

解压到同一目录，使用 Python 3.9 或更新版本运行
    python3 replay.py
全部数学检查仅需 Python 标准库，目标是九根单位球切线的线距至少 sqrt(2-sqrt(2))。

proof.pdf 和 proof.md 给出五根平行、部分四平行、任意八方向共面以及显式近乎平行条件的排除证明。一般九线问题仍未解决。

five-parallel.json 与 four-parallel-window.json 为两个标记矩证书的精确整数向量、实权重的有理分子及证明界。verify_marked.py 用齐次 Bernstein 多项式，independent_marked.py 用普通幂基，两者分别调用 bernstein_homogeneous.py 与 bernstein_power.py。angle_margins.py 检验所需角度不等式。tree_pruning.py 重算 47 个树形的 5743 种边标记结果。附带的 trees.tsv 与 replay.txt 可同程序运行结果对照。每种树形的名称是对全部选根取最小的排序子树括号编码。仅比较输入文件的完整性，可另运行 sha256sum -c SHA256SUMS。

kernel-background.md 是上一轮的核函数公式、树形存在归约及文献、代码版本记录。prior-certificate.zip 保存上一轮的整包原件，包含 R9 < 0.6453 和 R10 < 0.619 的独立重放程序，其 SHA-256 为
019bbae1ca59373c5844a1aa64caa4bf90e9957a7e97326f6fce69c8d306a8e3
