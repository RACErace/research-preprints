#!/usr/bin/env python3
"""Exact scalar checks for the geometric reduction and the near-parallel extension."""
from fractions import Fraction as F


def need(ok,message):
    if not ok: raise ValueError(message)


def main():
    tau=F(76533,100000);s=tau/2
    theta_sin3=3*s-4*s**3
    need(s*s>=F(1464,10000),"relaxed pair separation")
    need(theta_sin3**2>F(8535,10000),"single-gap marked-box inclusion")
    # pi/12 < theta < pi/6 follows for 1/3<s<1/2, since sin(pi/12)<1/3.
    need(F(1,3)<s<F(1,2),"angle range")
    need(2*s>1-2*s*s,"2*asin(2s)+4*theta > pi")
    need(s*s > theta_sin3**2*(1-theta_sin3**2),"asin(2s)+6*theta > pi")
    # cos(5 theta)=sqrt(1-s^2)*(1-12s^2+16s^4).
    poly=1-12*s*s+16*s**4
    need(poly<0 and (1-s*s)*poly**2>(1-2*s)**2,
         "cos(5 theta)<2s-1")
    need(tau>F(44,63),"nine parallel lines violate circle spacing")
    # sqrt(2-sqrt(2)) > tau+3/100000.
    v=tau+F(3,100000)
    need(2-v*v>0 and (2-v*v)**2>2,"target separation margin")
    K=300000;eps=F(1,10**27)
    a=K**4*eps
    need(2*a<F(3,100000) and a+F(6,K)<F(3,100000),"rounding loss")
    print("PASS: five-parallel exclusion also holds at separation",tau)
    print("sin(3 theta)^2 =",theta_sin3**2,"> 8535/10000")
    print("PASS: projective chord-radius 10^-27 rounding constants")
    print("Largest inside-direction movement is at most",a)


if __name__=="__main__":
    main()

