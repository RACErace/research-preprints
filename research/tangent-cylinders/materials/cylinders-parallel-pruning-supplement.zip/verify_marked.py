#!/usr/bin/env python3
"""Integer weighted-moment exclusion in a marked rotation box.
Usage: python verify_marked.py five-parallel.json
Uses only Python's integer and fraction arithmetic.
"""
import argparse
from fractions import Fraction
import json
from math import comb
from pathlib import Path

from bernstein_homogeneous import original, cube, halve


def constant_coeffs(L):
    return [comb(L,t)*comb(L,y)*comb(L,z)
            for t in range(L+1) for y in range(L+1) for z in range(L+1)]


def crop(raw,L,cut):
    """Restrict the second and third homogeneous variables to [cut,1]."""
    A,B=cut.numerator,cut.denominator
    D=B-A; size=L+1
    matrix=[[comb(i,j)*A**(i-j)*B**j*D**(L-i) for i in range(j,size)] for j in range(size)]
    for stride in (size,1):
        out=[0]*len(raw)
        for block in range(0,len(raw),stride*size):
            for off in range(stride):
                start=block+off
                line=raw[start:start+size*stride:stride]
                for j in range(size):
                    out[start+j*stride]=sum(x*y for x,y in zip(matrix[j],line[j:]))
        raw=out
    return raw,(size,)*3


def positive(tensor,shape):
    stack=[(tensor,0)]
    leaves=deepest=0
    corners=[(t*shape[1]+y)*shape[2]+z for t in (0,shape[0]-1)
             for y in (0,shape[1]-1) for z in (0,shape[2]-1)]
    while stack:
        box,depth=stack.pop()
        if min(box)>0:
            leaves+=1;deepest=max(depth,deepest)
        elif depth>=45 or min(box[ix] for ix in corners)<=0:
            raise ValueError("positivity certificate failed at depth "+str(depth))
        else:
            lo,hi=halve(box,shape,depth%3)
            stack.extend(((hi,depth+1),(lo,depth+1)))
    return leaves,deepest


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("certificate",type=Path)
    doc=json.loads(p.parse_args().certificate.read_text())
    L=doc["degree"];h=Fraction(doc["h"]);cut=Fraction(doc["cutoff"])
    if not (0<h<1 and 0<cut<1):
        raise ValueError("invalid rational enclosure")
    # h < sin(pi/8)^2 and cutoff < sin(3*pi/8)^2 exactly.
    low=2-4*h
    high=4*cut-2
    if not (low>0 and low*low>2 and (high<0 or high*high<2)):
        raise ValueError("thresholds do not cover the problem")
    count=doc["count"]
    if count not in (4,5):
        raise ValueError("unexpected claim")
    if count==5:
        z=1-2*(2*cut-1)**2
        x=2-4*z*z
        if not(z>0 and (x<0 or x*x<2)):
            raise ValueError("cut is too high for the four-anchor claim")
    M=Fraction(doc["pair_bound"]);B=Fraction(doc["local_bound"])
    constant=constant_coeffs(L)
    raw,S=original(doc,2)
    raw_pair=[M.denominator*g+(M.denominator+M.numerator)*S*u for g,u in zip(raw,constant)]
    n1,d1=positive(*cube(raw_pair,L,h))
    scale=doc["weight_denominator"]
    if type(scale) is not int or scale<=0: raise ValueError("invalid denominator")
    cross=[B.numerator*scale*S*q for q in constant]
    cost=0
    for term in doc["terms"]:
        weight=term["weight"]
        if type(weight) is not int: raise ValueError("noninteger auxiliary coefficient")
        raw,norm=original({"degree":L,"terms":[term]},2)
        cost+=weight*weight*norm
        for j,(value,unit) in enumerate(zip(raw,constant)):
            cross[j]+=B.denominator*weight*(value+norm*unit)
    n2,d2=positive(*crop(cross,L,cut))
    energy=count+count*(count-1)*M+2*count*B+Fraction(cost,S*scale**2)
    if energy>=0:
        raise ValueError("nonnegative final energy")
    print("Global F/S <",str(M)+":",n1,"leaves, depth",d1)
    print("Marked B/S <",str(B)+":",n2,"leaves, depth",d2)
    print("S =",S,"weighted norm numerator =",cost)
    print("Upper bound for the normalized squared norm =",energy)
    print("PASS: the marked box contains at most",count-1,"mutually separated lines")


if __name__=="__main__":
    main()

