#!/usr/bin/env python3
"""Replay the complete proof using the Python standard library."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(args):
    command = [sys.executable, "-B", *args]
    return subprocess.check_output(command, cwd=ROOT, text=True)


def main():
    cases = [
        (program, certificate)
        for certificate in ("five-parallel.json", "four-parallel-window.json")
        for program in ("verify_marked.py", "independent_marked.py")
    ]
    cases.extend([("angle_margins.py",), ("tree_pruning.py",)])
    for args in cases:
        print("$ python3", " ".join(args))
        print(run(args), end="")
    table = run(["tree_pruning.py", "--table"])
    if table != (ROOT / "trees.tsv").read_text():
        raise ValueError("recomputed tree table differs from documented table")
    print("PASS: all 47 table rows match")


if __name__ == "__main__":
    main()
