// Standalone checker for the continuous ten-point forest. Read the decompressed certificate on stdin.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Perm=array<int,64>;
using XYZ=array<int,3>;
using Cube=array<pair<int,int>,3>;
using Wide=unsigned __int128;
constexpr int D=128, UNIT=65536;
int LIMIT;bool rigidity;vector<int> root_codes;
int n=0;
vector<vector<int>> tours;
vector<int> weight,floor_weight;
vector<Perm> sym;
set<uint64_t> proven_orbits;
uint64_t total_signatures=0,nodes=0,leaves=0,parity_leaves=0;
int max_depth=0;
void require(bool p){if(!p)throw runtime_error("certificate check failed");}
int pinmask(int code){
    int result=0;
    for(int k=0;k<3;++k){
        int d=(code>>(2*k))%4;
        if(d==0||d==3)result|=1<<(2*k+(d==3));
    }
    return result;
}
uint64_t expected_signatures(){
    // Multisets of n boxes. Each of six faces has precisely one marked extremum.
    vector<array<uint64_t,64>> counts(n+1);counts[0][0]=1;
    for(int code=0;code<64;++code){
        int f=pinmask(code);auto next=counts;
        for(int used=0;used<n;++used)for(int taken=0;taken<64;++taken){
            if(taken&f)continue;
            for(int copies=1;used+copies<=n;++copies){
                next[used+copies][taken|f]+=counts[used][taken];
                if(f)break;
            }
        }
        counts.swap(next);
    }
    return counts[n][63];
}
void make_group(){
    Perm id{},swap01{},swap12{},flip{};
    for(int code=0;code<64;++code){
        int x=code%4,y=(code/4)%4,z=code/16;
        id[code]=code;swap01[code]=y+4*x+16*z;
        swap12[code]=x+4*z+16*y;flip[code]=3-x+4*y+16*z;
    }
    set<Perm> found{id};sym={id};
    for(size_t i=0;i<sym.size();++i){
        for(const auto& f:{swap01,swap12,flip}){
            Perm h{};for(int c=0;c<64;++c)h[c]=f[sym[i][c]];
            if(found.insert(h).second)sym.push_back(h);
        }
    }
    require(sym.size()==48);
}
void register_root(const vector<int>& codes){
    int pins=0;
    for(int code:codes){
        require(0<=code&&code<64);
        int f=pinmask(code);require((pins&f)==0);pins|=f;
    }
    require(pins==63);
    set<uint64_t> ids;
    for(const auto& g:sym){
        auto r=codes;for(int& x:r)x=g[x];sort(r.begin(),r.end());
        uint64_t id=0;for(int x:r)id=(id<<6)|x;
        ids.insert(id);
    }
    require(proven_orbits.insert(*ids.begin()).second);
    total_signatures+=ids.size();
}
void make_costs(){
    Wide den=8;for(int k=0;k<6;k++)den*=D;
    for(int s=0;s<=3*D*D;++s){
        Wide num=Wide(UNIT)*UNIT*s*s*s;
        int low=0,high=4*UNIT;
        while(low<high){
            int m=(low+high)/2;
            if(Wide(m)*m*den>=num)high=m;else low=m+1;
        }
        require(Wide(low)*low*den>=num);
        require(low==0||Wide(low-1)*(low-1)*den<num);
        weight.push_back(low);floor_weight.push_back(low-(Wide(low)*low*den>num));
    }
    vector<int> t(n);
    for(int j=0;j<n;++j)t[j]=j;
    do{if(t[1]<t.back())tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));
}
vector<Cube> decode(const vector<int>& codes){
    vector<Cube> b(n);
    for(int i=0;i<n;++i)for(int a=0;a<3;++a){
        int s=(codes[i]>>(2*a))&3;
        if(s==0)b[i][a]={0,0};
        if(s==1)b[i][a]={0,D/2};
        if(s==2)b[i][a]={D/2,D};
        if(s==3)b[i][a]={D,D};
    }
    return b;
}
bool corner_lemma(const vector<Cube>& boxes){
    int common=-1;
    for(const auto& b:boxes){
        int par=0;
        for(auto [lo,hi]:b){
            const int side=rigidity?D/8:D/4;
            if(hi<=side)continue;
            if(lo>=D-side)par^=1;
            else return false;
        }
        if(common>=0&&par!=common)return false;
        common=par;
    }
    return true;
}
struct Section{array<XYZ,8> p;int size=0;};
Section vertices(const Cube& b){
    Section v{};
    for(int mask=0;mask<8;++mask){
        XYZ pt;bool use=true;
        for(int i=0;i<3;++i){
            auto [x,y]=b[i];bool upper=mask&(1<<i);
            if(x==y&&upper)use=false;
            pt[i]=upper?y:x;
        }
        if(use)v.p[v.size++]=pt;
    }
    return v;
}
int sqdistance(const XYZ& x,const XYZ& y){
    int q=0;for(int a=0;a<3;++a){int d=x[a]-y[a];q+=d*d;}return q;
}
bool strict_cycle(const vector<Cube>& b,const vector<int>& t){
    array<Section,10> v{};
    for(int i=0;i<n;++i)v[i]=vertices(b[t[i]]);
    int first=0;for(int i=1;i<n;++i)if(v[i].size<v[first].size)first=i;
    rotate(v.begin(),v.begin()+first,v.begin()+n);
    int w[10][8][8];
    for(int i=0;i<n;++i){int j=(i+1)%n;for(int a=0;a<v[i].size;++a)
        for(int k=0;k<v[j].size;++k)w[i][a][k]=weight[sqdistance(v[i].p[a],v[j].p[k])];}
    // For each fixed corner of the first cube, maximize over all other corners.
    for(int base=0;base<v[0].size;++base){
        int dp[8],next[8];
        for(int i=0;i<v[1].size;++i)dp[i]=w[0][base][i];
        for(int j=1;j+1<n;++j){
            for(int k=0;k<v[j+1].size;++k){
                next[k]=0;
                for(int i=0;i<v[j].size;++i)next[k]=max(next[k],dp[i]+w[j][i][k]);
            }
            copy(next,next+v[j+1].size,dp);
        }
        for(int k=0;k<v[n-1].size;++k)if(dp[k]+w[n-1][k][base]>=LIMIT)return false;
    }
    return true;
}
uint64_t deletions=0,close_pairs=0,empty_orders=0,margin_used=0,angle_used=0;
bool apply_label_order(vector<Cube>& b){
    // Labels in identical root boxes can initially be sorted on one common free axis.
    for(int i=0;i<n;++i){
        int k=0;for(;k<3;++k){int bit=root_codes[i]>>(2*k)&3;if(bit==1||bit==2)break;}
        if(k==3)continue;
        int lo=b[i][k].first,hi=b[i][k].second;
        for(int j=0;j<n;++j)if(root_codes[j]==root_codes[i]){
            if(j<i)lo=max(lo,b[j][k].first);
            if(j>i)hi=min(hi,b[j][k].second);
        }
        b[i][k]={lo,hi};
        if(lo>hi)return false;
    }
    return true;
}
int dist_sq(const Cube& a,const Cube& b,bool upper){
    int m=0;
    for(int j=0;j<3;++j){
        auto [a0,a1]=a[j];auto [b0,b1]=b[j];
        int g=upper?max(abs(a1-b0),abs(b1-a0)):max({0,b0-a1,a0-b1});
        m+=g*g;
    }return m;
}
int dot_bound(const Cube& a,const Cube& x,const Cube& b){
    int result=0;
    for(int k=0;k<3;++k){
        int term=-4*D*D;
        for(int av:{a[k].first,a[k].second})for(int bv:{b[k].first,b[k].second})
        for(int xv:{x[k].first,x[k].second})term=max(term,(av-xv)*(bv-xv));
        result+=term;
    }return result;
}
bool can_use_nine_margin(const vector<Cube>& b,int x){
    for(int k=0;k<3;++k){int digit=root_codes[x]>>(2*k)&3;if(digit==0||digit==3)return false;}
    for(int p=0;p<2;++p){
        bool parity_covers=true;
        for(int i=0;i<n;++i)if(i!=x){
            bool any=false;
            for(int v=0;v<8;++v){
                if(((v^(v>>1)^(v>>2))&1)!=p)continue;
                bool fits=true;
                for(int k=0;k<3;++k){
                    if(v>>k&1)fits= fits && 25*b[i][k].second>=23*D;
                    else fits= fits && 25*b[i][k].first<=2*D;
                }
                any=any||fits;
            }
            parity_covers=parity_covers&&any;
        }
        if(parity_covers)return false;
    }
    return true;
}
bool deletion_leaf(const vector<Cube>& b,int x){
    int credit=rigidity ? (can_use_nine_margin(b,x)?2900:0):2900;
    int required=(4*UNIT-LIMIT)-credit;
    int best=-1000000, rectangular=-1000000;
    for(int u=0;u<n;++u)if(u!=x){
        array<int,8> gains,raw;int m=0;
        for(int v=0;v<n;++v)if(v!=x&&u!=v){
            int lower=floor_weight[dist_sq(b[u],b[v],false)];
            int upper1=weight[dist_sq(b[u],b[x],true)];
            int upper2=weight[dist_sq(b[x],b[v],true)];
            int proven=raw[m]=lower-upper1-upper2;
            int c=dot_bound(b[u],b[x],b[v]);
            if(!rigidity&&c<=0)proven=max(proven,0);
            if(rigidity){
                int A=dist_sq(b[u],b[x],false),B=dist_sq(b[v],b[x],false);
                if(A>=2*c&&B>=2*c){
                    int z=A+B-2*c;require(z>=0&&z<=3*D*D);
                    proven=max(proven,floor_weight[z]-weight[A]-weight[B]);
                }
            }
            gains[m++]=proven;
        }
        require(m==8);
        nth_element(gains.begin(),gains.begin()+1,gains.end());
        nth_element(raw.begin(),raw.begin()+1,raw.end());
        best=max(best,gains[1]);rectangular=max(rectangular,raw[1]);
    }
    if(best<required)return false;
    margin_used+=(best<4*UNIT-LIMIT);
    angle_used+=(rectangular<required);
    return true;
}
void tree(istringstream& in,vector<Cube> b,int depth){
    require(depth<=200);max_depth=max(depth,max_depth);++nodes;
    int t;require(bool(in>>t));
    bool nonempty=apply_label_order(b);
    if(t==200021){require(!nonempty);++empty_orders;++leaves;return;}
    require(nonempty);
    if(t<0){
        require(t>=-3*n);
        int i=(-t-1)/3,k=(-t-1)%3;auto [lo,hi]=b[i][k];require(hi-lo>=2);
        int mid=(lo+hi)/2;b[i][k].second=mid;tree(in,b,depth+1);
        b[i][k]={mid,hi};tree(in,b,depth+1);
    }else if(t==0){
        require(corner_lemma(b));++parity_leaves;++leaves;
    }else if(t>=200000&&t<200010){
        require(deletion_leaf(b,t-200000));++deletions;++leaves;
    }else if(t==200020){
        require(!rigidity);bool found=false;
        for(int i=0;i<n;++i)for(int j=0;j<i;++j)found|=196*dist_sq(b[i],b[j],true)<=9*D*D;
        require(found);++close_pairs;++leaves;
    }else{
        require(t>=1&&t<=int(tours.size()));require(strict_cycle(b,tours[t-1]));++leaves;
    }
}
int main(){
    string line;require(bool(getline(cin,line)));istringstream header(line);string tag;
    require(bool(header>>tag>>n)&&n==10&&(tag=="MDS41TEN-BASE"||tag=="MDS41TEN-RIGID"));
    rigidity=tag=="MDS41TEN-RIGID";LIMIT=4*UNIT-(rigidity?8000:0);
    make_group();make_costs();
    while(getline(cin,line)){
        istringstream in(line);vector<int> codes(n);for(int& c:codes)require(bool(in>>c));
        register_root(codes);root_codes=codes;tree(in,decode(codes),0);
        string extra;require(!(in>>extra));
    }
    auto expected=expected_signatures();
    require(expected==11295372&&total_signatures==expected&&proven_orbits.size()==238996);
    require(nodes==2*leaves-proven_orbits.size());
    cout<<tag<<" signatures "<<expected<<" orbits "<<proven_orbits.size()<<" nodes "<<nodes
        <<" leaves "<<leaves<<" tours "<<leaves-parity_leaves-deletions-close_pairs-empty_orders
        <<" parity "<<parity_leaves<<" deletions "<<deletions<<" close "<<close_pairs
        <<" empty_orders "<<empty_orders<<" needed_nine_margin "<<margin_used<<" needed_angle "<<angle_used<<" depth "<<max_depth<<'\n';
}
