#pragma once
// Bounded witness discovery on products of ten point boxes. The standalone verifier has independent geometry and arithmetic.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <vector>
using namespace std;
// Positive tokens are one plus a tour index, zero applies the parity corner lemma,
// and negative tokens split a single scalar coordinate at its midpoint.
constexpr int N=10, D=128, U=1<<16;
constexpr int TARGET=4*U-(WITH_MARGIN?8000:0);
constexpr int TourCount=181440;
using V=array<int,3>;
using Order=array<int,N>;
struct Box{V l,h;}; using Boxes=array<Box,N>;
using Pattern=array<int,N>;
vector<Order> tours;
vector<int> wt, low_wt;
struct Counters{uint64_t cycle=0,local=0,split=0;int deepest=0;} count_all;
constexpr int depth_limit=WITH_MARGIN?76:50;
vector<int> proof;
int edgepos[N][N];
array<array<unsigned char,N>,TourCount> edgelist;
uint64_t nodes=0,inherit_hits=0;
const int trials=9;
using Pool=array<int,trials>;
int rawcost(V a,V b){int d=0;for(int i=0;i<3;++i){int g=a[i]-b[i];d+=g*g;}return wt[d];}
void init(){
 for(int s=0;s<=3*D*D;++s){
    using Wide=unsigned __int128;
    Wide den=Wide(8)*D*D*D*D*D*D, num=Wide(U)*U*s*s*s;
    int left=0,right=4*U;
    while(left<right){
        int m=left+(right-left)/2;
        if(Wide(m)*m*den>=num)right=m;else left=m+1;
    }
    int w=left;
    wt.push_back(w);low_wt.push_back(w-(Wide(w)*w*den>num));
 }
 Order t{};for(int i=0;i<N;++i)t[i]=i;
 do{if(t[1]<t[N-1])tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));

}
Boxes decode(const Pattern& codes){
 Boxes boxes{};
 for(int i=0;i<N;++i)for(int a=0;a<3;++a){
   int e=(codes[i]>>(2*a))&3;
   boxes[i].l[a]=array<int,4>{0,0,D/2,D}[e];
   boxes[i].h[a]=array<int,4>{0,D/2,D,D}[e];
 }
 return boxes;
}
int color(const Box& box){
 int par=0;
 for(int a=0;a<3;++a){
    if(box.h[a]<=(WITH_MARGIN?D/8:D/4))continue;
    if(box.l[a]>=D-(WITH_MARGIN?D/8:D/4))par^=1;
    else return -1;
 }
 return par;
}
struct Node{
 int M[N][N]{}, pt[N]{}, w[N][N][8][8]{};
 V corners[N][8]{};
 int edge_weight[N*N]{};
 Node(const Boxes& boxes){
  for(int i=0;i<N;++i){
   const Box& b=boxes[i];corners[i][0]=b.l;pt[i]=1;
   for(int k=0;k<3;++k)if(b.l[k]!=b.h[k]){
    int pre=pt[i];for(int h=0;h<pre;++h){corners[i][pre+h]=corners[i][h];corners[i][pre+h][k]=b.h[k];}pt[i]*=2;
   }
  }
  for(int i=0;i<N;++i)for(int j=0;j<i;++j){
   int bound=0;
   for(int a=0;a<pt[i];++a)for(int b=0;b<pt[j];++b){
     int c=rawcost(corners[i][a],corners[j][b]);w[i][j][a][b]=w[j][i][b][a]=c;bound=max(bound,c);
   } M[i][j]=M[j][i]=bound; edge_weight[edgepos[i][j]]=bound;
  }

 }
 int score(int k)const{
    int sum=0;for(int e:edgelist[k])sum+=edge_weight[e];return sum;
 }
 int worst(const Order& tour,int stop,int *witness=nullptr){
    int off=0;for(int i=1;i<N;++i)if(pt[tour[i]]<pt[tour[off]])off=i;
    Order t{};for(int i=0;i<N;++i)t[i]=tour[(off+i)%N];
    int best=0;
    for(int a=0;a<pt[t[0]];++a){
        int pre[8],nex[8],arg[N][8]{};
        for(int b=0;b<pt[t[1]];++b)pre[b]=w[t[0]][t[1]][a][b];
        for(int k=2;k<N;++k){
            for(int c=0;c<pt[t[k]];++c){
                int val=-1,idx=0;
                for(int b=0;b<pt[t[k-1]];++b){int x=pre[b]+w[t[k-1]][t[k]][b][c];if(x>val){val=x;idx=b;}}
                nex[c]=val;if(witness)arg[k][c]=idx;
            }
            copy(nex,nex+pt[t[k]],pre);
        }
        for(int b=0;b<pt[t[N-1]];++b){
            int z=pre[b]+w[t[N-1]][t[0]][b][a];
            if(z>best){best=z;if(witness){
                witness[t[0]]=a;int v=b;
                for(int k=N-1;k>=1;--k){witness[t[k]]=v;v=arg[k][v];}
            }}
            if(best>stop)return best;
        }
    }
    return best;
 }
};


void index_tours(){
  int eid=0;for(int i=1;i<N;i++)for(int j=0;j<i;j++)edgepos[i][j]=edgepos[j][i]=eid++;
  for(int k=0;k<TourCount;k++)for(int j=0;j<N;j++){
    int e=edgepos[tours[k][j]][tours[k][(j+1)%N]];
    edgelist[k][j]=e;
  }
}
constexpr int DELETE_LEAF=200000, CLOSE_LEAF=200020;
const int fact[]={1,1,2,6,24,120,720,5040,40320,362880,3628800};
vector<int> ids(fact[N-1]);
int rank_cycle(Order t){
    int zero=find(t.begin(),t.end(),0)-t.begin();
    rotate(t.begin(),t.begin()+zero,t.end());
    int rank=0,unused=(1<<N)-2;
    for(int i=1;i<N;++i){
        int bit=1<<t[i];rank+=__builtin_popcount(unsigned(unused&(bit-1)))*fact[N-1-i];unused^=bit;
    }
    return rank;
}
void index_orientations(){
    for(int k=0;k<TourCount;++k){
        Order r=tours[k];ids[rank_cycle(r)]=k;
        reverse(r.begin()+1,r.end());ids[rank_cycle(r)]=k;
    }
}
struct Constraints{
    vector<array<int,3>> pairs;
    explicit Constraints(const Pattern& p){
        for(int i=0;i<N;++i)for(int j=i+1;j<N;++j)if(p[i]==p[j]){
            for(int k=0;k<3;++k){int s=p[i]>>(2*k)&3;
                if(s==1||s==2){pairs.push_back({i,j,k});break;}
            }
        }
    }
    bool tighten(Boxes& b)const{
        for(auto [i,j,k]:pairs){
            b[j].l[k]=max(b[j].l[k],b[i].l[k]);
            b[i].h[k]=min(b[i].h[k],b[j].h[k]);
            if(b[i].l[k]>b[i].h[k]||b[j].l[k]>b[j].h[k])return false;
        }
        return true;
    }
};
int far_sq(const Box& a,const Box& b){
    int z=0;for(int k=0;k<3;++k){int h=max(a.h[k]-b.l[k],b.h[k]-a.l[k]);z+=h*h;}return z;
}
int near_sq(const Box& a,const Box& b){
    int z=0;for(int k=0;k<3;++k){int h=max({0,a.l[k]-b.h[k],b.l[k]-a.h[k]});z+=h*h;}return z;
}
int dot_upper(const Box& a,const Box& x,const Box& b){
    int s=0;for(int k=0;k<3;++k){
        auto at=[&](int v){
            int al=a.l[k]-v,ah=a.h[k]-v,bl=b.l[k]-v,bh=b.h[k]-v;
            return max({al*bl,ah*bh,al*bh,ah*bl});};
        s+=max(at(x.l[k]),at(x.h[k]));
    }return s;
}
uint64_t deletes=0,closepairs=0,conflicts=0;
array<bool,N> preserves_faces{};
bool small_parity_possible(const Boxes& b,int missing){
    for(int parity=0;parity<2;++parity){
        bool possible=true;
        for(int i=0;i<N&&possible;++i)if(i!=missing){
            possible=false;
            for(int mask=0;mask<8;++mask)if(__builtin_popcount(unsigned(mask))%2==parity){
                bool touches=true;
                for(int j=0;j<3;++j)if((mask>>j)&1){if(25*b[i].h[j]<23*D)touches=false;}
                    else if(25*b[i].l[j]>2*D)touches=false;
                if(touches){possible=true;break;}
            }
        }
        if(possible)return true;
    }
    return false;
}
int deletion_test(const Boxes& b,const Node& v){
    int low[N][N]{},sq[N][N]{};
    for(int i=0;i<N;++i)for(int j=0;j<i;++j){
        sq[i][j]=sq[j][i]=near_sq(b[i],b[j]);low[i][j]=low[j][i]=low_wt[sq[i][j]];
    }
    for(int x=0;x<N;++x){
        // In a deletion preserving all six pins the nine-point configuration is normalized.
        int slack=WITH_MARGIN ? (preserves_faces[x]&&!small_parity_possible(b,x)?2900:0) : 2900;
        int needed=(4*U-TARGET)-slack;
        for(int i=0;i<N;++i)if(i!=x){
            int safe=0;
            for(int j=0;j<N&&safe<2;++j)if(j!=x&&j!=i){
                int gain=low[i][j]-v.M[i][x]-v.M[x][j];
                if(gain>=needed)continue;
                int twice=2*dot_upper(b[i],b[x],b[j]),a=sq[i][x],b2=sq[j][x];
                if(!WITH_MARGIN&&twice<=0)continue;
                if(WITH_MARGIN&&min(a,b2)>=twice){
                    int z=a+b2-twice;
                    // The lower expression is monotone in both squared leg lengths.
                    if(low_wt.at(z)-wt[a]-wt[b2]>=needed)continue;
                }
                ++safe;
            }
            if(safe<2)return x;
        }
    }
    return -1;
}
void opt2(Order& t,const int cost[N][N]){
    for(int pass=0;pass<12;++pass){
        int gain=0,left=0,right=0;
        for(int i=0;i<N-2;++i)for(int j=i+2;j<N;++j){
            if(i==0&&j==N-1)continue;
            int a=t[i],b=t[i+1],c=t[j],d=t[(j+1)%N];
            int g=cost[a][b]+cost[c][d]-cost[a][c]-cost[b][d];
            if(g>gain){gain=g;left=i+1;right=j+1;}
        }
        if(!gain)break;
        reverse(t.begin()+left,t.begin()+right);
    }
}
Order insert_seed(const int cost[N][N],int first,bool farthest){
    Order path{};int n=1,used=1<<first;path[0]=first;
    while(n<N){
        int choice=-1,pos=0,best=farthest?-1:INT32_MAX;
        for(int v=0;v<N;++v)if(!(used>>v&1)){
            int score=INT32_MAX,at=0,nearest=INT32_MAX;
            for(int i=0;i<n;++i){
                int a=path[i],b=path[(i+1)%n];
                int z=cost[a][v]+cost[v][b]-cost[a][b];
                if(z<score){score=z;at=i+1;}
                nearest=min(nearest,cost[a][v]);
            }
            if((farthest&&nearest>best)||(!farthest&&score<best)){
                choice=v;pos=at;best=farthest?nearest:score;
            }
        }
        for(int j=n;j>pos;--j)path[j]=path[j-1];path[pos]=choice;++n;used|=1<<choice;
    }
    return path;
}
// Exact additive optimum to provide a seed only. The certificate checker never uses it.
Order min_additive(const int cost[N][N]){
    constexpr int S=1<<(N-1);
    int dp[S][N];unsigned char prev[S][N];
    for(int s=1;s<S;++s)for(int m=s;m;m&=m-1){
        int bit=m&-m,j=__builtin_ctz(unsigned(bit))+1,t=s^bit;
        int best=INT32_MAX,choice=0;
        if(!t)best=cost[0][j];
        for(int q=t;q;q&=q-1){
            int a=__builtin_ctz(unsigned(q))+1,v=dp[t][a]+cost[a][j];
            if(v<best){best=v;choice=a;}
        }
        dp[s][j]=best;prev[s][j]=choice;
    }
    int s=S-1,end=1;
    for(int j=2;j<N;++j)if(dp[s][j]+cost[j][0]<dp[s][end]+cost[end][0])end=j;
    Order t{};for(int k=N-1;k>=1;--k){t[k]=end;int old=end;end=prev[s][end];s^=1<<(old-1);}
    return t;
}
uint64_t per_root_limit=80000,aggregate_limit=24000000;
uint64_t rootstart=0,exact_seeds=0;
int unresolved_code=0;
bool solve(Boxes box,const Constraints& limits,int depth,const Pool& inherited){
    if(++nodes-rootstart>per_root_limit||nodes>aggregate_limit){unresolved_code=1;return false;}
    count_all.deepest=max(count_all.deepest,depth);
    if(!limits.tighten(box)){proof.push_back(CLOSE_LEAF+1);++conflicts;return true;}
    if(!WITH_MARGIN){
    for(int i=1;i<N;++i)for(int j=0;j<i;++j)if(196*far_sq(box[i],box[j])<=9*D*D){
        proof.push_back(CLOSE_LEAF);++closepairs;return true;
    }
    }
    int par=color(box[0]);
    if(par>=0&&all_of(box.begin()+1,box.end(),[par](const Box& b){return color(b)==par;})){
        proof.push_back(0);++count_all.local;return true;
    }
    Node v(box);
    vector<pair<int,int>> ranked;ranked.reserve(48);
    auto test=[&](int k){
        if(k<0)return false;
        for(auto [sc,id]:ranked)if(id==k)return false;
        int val=v.score(k);
        if(val>=TARGET)val=v.worst(tours[k],TARGET-1);
        if(val<TARGET){proof.push_back(k+1);++count_all.cycle;return true;}
        ranked.emplace_back(val,k);return false;
    };
    for(int k:inherited)if(test(k)){++inherit_hits;return true;}
    auto run=[&](Order o,const int c[N][N]){
        opt2(o,c);return test(ids[rank_cycle(o)]);
    };
    for(int z=0;z<4;++z){
        if(run(insert_seed(v.M,(3*z)%N,z%2==0),v.M))return true;
    }
    if(inherited[0]>=0&&run(tours[inherited[0]],v.M))return true;
    int centers[N][N]{};
    for(int i=0;i<N;++i)for(int j=0;j<i;++j){
        int sq=0;for(int k=0;k<3;++k){int f=box[i].l[k]+box[i].h[k]-box[j].l[k]-box[j].h[k];sq+=f*f;}
        centers[i][j]=centers[j][i]=v.M[i][j]+wt[(sq+2)/4];
    }
    for(int z=0;z<5;++z){
        if(run(insert_seed(centers,2*z,z%2==0),centers))return true;
    }
    int erased=deletion_test(box,v);
    if(erased>=0){proof.push_back(DELETE_LEAF+erased);++deletes;return true;}
    ++exact_seeds;
    auto additive=min_additive(v.M);
    if(test(ids[rank_cycle(additive)]))return true;
    // Try the near-optimal two-edge neighbors of the best robust or additive cycles.
    for(int side=0;side<2;++side){
        Order z=side?additive:tours[min_element(ranked.begin(),ranked.end())->second];
        vector<pair<int,int>> near;near.reserve(N*(N-3)/2);
        for(int i=0;i<N-2;++i)for(int j=i+2;j<N;++j){
            if(i==0&&j==N-1)continue;
            reverse(z.begin()+i+1,z.begin()+j+1);
            int id=ids[rank_cycle(z)];near.emplace_back(v.score(id),id);
            reverse(z.begin()+i+1,z.begin()+j+1);
        }
        partial_sort(near.begin(),near.begin()+6,near.end());
        for(int h=0;h<6;++h)if(test(near[h].second))return true;
    }
    if(depth>=depth_limit){unresolved_code=2;return false;}
    sort(ranked.begin(),ranked.end());
    Pool child{};child.fill(-1);
    for(int k=0;k<min<int>(trials,ranked.size());++k)child[k]=ranked[k].second;
    const auto& t=tours[child[0]];int witness[N]{};v.worst(t,INT32_MAX,witness);
    int si=-1,sk=-1;long long merit=-1;
    for(int h=0;h<N;++h){
        int i=t[h],pre=t[(h+N-1)%N],nxt=t[(h+1)%N];
        V a=v.corners[i][witness[i]],p=v.corners[pre][witness[pre]],q=v.corners[nxt][witness[nxt]];
        int old=rawcost(a,p)+rawcost(a,q);
        for(int k=0;k<3;++k){
            int w=box[i].h[k]-box[i].l[k];if(w<2)continue;
            V m=a;m[k]=(box[i].h[k]+box[i].l[k])/2;
            long long val=(long long)w*(3000+max(0,old-rawcost(m,p)-rawcost(m,q)));
            if(val>merit){merit=val;si=i;sk=k;}
        }
    }
    if(si<0){unresolved_code=3;return false;}
    // Splits round down, so closure under label inequalities need not produce dyadic widths.
    int m=(box[si].h[sk]+box[si].l[sk])/2;
    Boxes right=box;box[si].h[sk]=right[si].l[sk]=m;
    proof.push_back(-1-3*si-sk);++count_all.split;
    return solve(box,limits,depth+1,child)&&solve(right,limits,depth+1,child);
}

