"""Conservative temporal load near a cut. The only geometry is in the motif classifier."""
from functools import lru_cache
from bisect import bisect_right
import curve_windows as base

T=8**6
SLOTS=128
STEP=T//SLOTS
WIDTH=STEP
# Candidate arcs of a given scale have normalized duration in [1/2,4).


@lru_cache(None)
def motifs(b, depth=3):
    accepted=set()
    for lag in range(5):
        starts={(w[2],w[2+lag]) for w in base.small_words(lag,2)}
        for first,last in starts:
            work=[(0,0,first,lag,last)]
            while work:
                h,i,x,j,y=work.pop()
                n=8**h
                if 2*(j-i+1)<n or j-i-1>=4*n:
                    continue
                sq=sum((abs(p-q)+1)**2 for p,q in zip(x[0],y[0]))
                if 40000*sq**3<=b*b*max(n,2*(j-i-1))**2:
                    continue
                if h==depth:
                    accepted.add((i,j));continue
                for u,c in enumerate(base.refine(x)):
                    for v,d in enumerate(base.refine(y)):
                        work.append((h+1,8*i+u,c,8*j+v,d))
    return sorted(accepted)


def ceildiv(x,m):
    return -((-x)//m)


class Budget:
    """Rows bound the union of all possible beneficiary intervals on one side of an anchor."""
    def __init__(self,b,a,depth=3,slots=SLOTS):
        self.a=a
        self.m=8**depth
        self.slots=slots
        self.step=T//slots
        assert T%slots==0
        self.patterns=motifs(b,depth)
        self.maximum=ceildiv(4*(100+a),100)*T
        self.high=(self.maximum+self.step-1)//self.step
        self.rows=[self.row(k) for k in range(self.slots)]
        self.uniform=[max(r[i] for r in self.rows) for i in range(self.high+1)]
        self.cache={}

    @lru_cache(maxsize=16000)
    def row(self,k,cut=0):
        step=self.step
        a0,a1=k*step,(k+1)*step
        # Edge endpoints and candidate anchors may coincide with subdivision boundaries.
        bins=[0]*(self.high+1)
        def record(min_extent,begin,end):
            if min_extent>self.maximum or end<=0 or begin>=self.maximum:return
            begin=max(0,begin)//step
            end=min(self.high,ceildiv(min(self.maximum,end),step))
            index=max(0,ceildiv(min_extent,step))
            if end>begin:
                bins[index]|=((1<<(end-begin))-1)<<begin
        # Coarsest possible comparison scale for the stated reach cap.
        scale=T
        while scale*8<=2*self.maximum:scale*=8
        while scale>=self.m and scale>=T//512:
            period=min(scale,T) # base origin is known only modulo one of I's blocks
            unit=scale//self.m
            for i,j in self.patterns:
                x=i*unit;y=j*unit
                duration=min(4*scale,y+unit-x)
                if duration<cut:continue
                # x+unit >= a0 and x-a1 <= a*duration/100
                low=ceildiv(a0-unit-x,period)
                high=(100*(a1-x)+self.a*duration)//(100*period)
                for shift in range(low,high+1):
                    origin=shift*period
                    begin=origin+x-a1
                    end=origin+y+unit-a0
                    minimum=max(scale//2,origin+y-a1)
                    record(minimum,begin,end)
            scale//=8
        # Every finer beneficiary is contained in this neighborhood.
        if 4*scale>=cut:record(0,0,ceildiv((100+self.a)*4*scale,100))
        mask=0;row=[]
        for j,pieces in enumerate(bins):
            mask|=pieces
            row.append((mask&((1<<j)-1)).bit_count()*step)
        return row

    def cover(self,lo,hi,reach,sign,cut=0):
        if reach<=0 or cut>reach:return 0
        assert lo<=hi and reach<=self.maximum,(lo,hi,reach,self.maximum)
        if sign<0:lo,hi=-hi,-lo
        j=ceildiv(reach,self.step)
        # A closed interval ending at a grid breakpoint may use the bin on its left.
        f=lo//self.step;l=max(f,ceildiv(hi,self.step)-1)
        key=(f%self.slots,min(l-f,self.slots-1),j,cut)
        if key not in self.cache:
            if cut:z=max(self.row(k%self.slots,cut)[j] for k in range(f,min(l+1,f+self.slots)))
            elif l-f+1>=self.slots:z=self.uniform[j]
            else:z=max(self.rows[k%self.slots][j] for k in range(f,l+1))
            self.cache[key]=z
        return min(reach,self.cache[key])
