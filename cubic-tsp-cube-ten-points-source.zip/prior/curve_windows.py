"""Aligned space/time cylinders of the closed Spring ring."""
import json
import sys
from collections import Counter, defaultdict
from functools import lru_cache
from math import isqrt
from pathlib import Path

import spring_base as spring


def need(ok, message):
    if not ok:
        raise ValueError(message)


@lru_cache(None)
def refine(cell):
    origin, state = cell
    return tuple((tuple(2*x+y for x,y in zip(origin,offset)), child)
                 for offset,child in spring.parts(state))


def expand(seq):
    return tuple(ch for cell in seq for ch in refine(cell))


def reverse(seq):
    return tuple((v,(k,g,not r)) for v,(k,g,r) in seq[::-1])


@lru_cache(None)
def frame_change(frame):
    # Orthogonal matrix of the original cube frame. Its transpose is the inverse.
    cc = spring.CORNERS
    origin = cc[frame[0]]
    columns = tuple(tuple(x-y for x,y in zip(cc[frame[i]],origin)) for i in (4,2,1))
    inverse = tuple(frame.index(j) for j in range(8))
    return columns,inverse


@lru_cache(None)
def transformed(frame,rel,kind,orient,backwards):
    columns,inverse=frame_change(frame)
    lower=tuple(sum(x*y for x,y in zip(col,rel)) for col in columns)
    return lower,(kind,tuple(inverse[i] for i in orient),backwards)


def normalize(seq, pivot=0):
    origin, (_,frame,_) = seq[pivot]
    return tuple(transformed(frame,(p[0]-origin[0],p[1]-origin[1],p[2]-origin[2]),k,h,r)
                 for p,(k,h,r) in seq)

@lru_cache(None)
def adjacent_pairs():
    seqs = [spring.parts((k,spring.ID,r)) for k in (0,1) for r in (False,True)]
    seqs.append(spring.TOP+(spring.TOP[0],))
    pairs = {normalize(seq[i:i+2]) for seq in seqs for i in range(len(seq)-1)}
    previous = set()
    while previous != pairs:
        previous = pairs
        pairs = pairs | {normalize((refine(a)[-1],refine(b)[0])) for a,b in pairs}
    return frozenset(pairs)


@lru_cache(None)
def language(length):
    if length == 2:
        return adjacent_pairs()
    needed_parents = (length+14)//8
    out = set()
    for parent in language(needed_parents):
        seq = expand(parent)
        for j in range(8):
            part = seq[j:j+length]
            need(len(part)==length,"incomplete parent word")
            out.add(normalize(part))
    ring = spring.TOP*((length+14)//8)
    for j in range(8):
        out.add(normalize(ring[j:j+length]))
    return frozenset(out)


def stream_windows(length):
    """Generate the long words without retaining the full unprocessed language."""
    if length<=2:
        yield from adjacent_pairs()
        return
    for parent in language((length+14)//8):
        expanded=expand(parent)
        for offset in range(8):
            word=expanded[offset:offset+length]
            need(len(word)==length,"short extended word")
            yield word
    ring=spring.TOP*((length+14)//8)
    for first in range(8):
        yield ring[first:first+length]


@lru_cache(None)
def small_words(lag,radius):
    seqs = language(lag+2*radius+1)
    return tuple(sorted({normalize(word,radius) for s in seqs for word in (s,reverse(s))}))


def subcell(cell, digits, depth):
    for j in range(depth-1,-1,-1):
        cell = refine(cell)[(digits >> (3*j)) & 7]
    return cell


@lru_cache(None)
def norm_weights(squared_distance):
    radicand = squared_distance**3
    floor = isqrt(radicand)
    ceiling = floor + int(floor*floor < radicand)
    return floor,ceiling


def min_weight(p,a,q,b):
    gaps = (max(0, x-y-b, y-x-a) for x,y in zip(p,q))
    return norm_weights(sum(g*g for g in gaps))[0]


def max_weight(p,a,q,b):
    spans = (max(x+a-y,y+b-x) for x,y in zip(p,q))
    return norm_weights(sum(g*g for g in spans))[1]


def lower_corner(cell, scale):
    return tuple(z*scale for z in cell[0])


