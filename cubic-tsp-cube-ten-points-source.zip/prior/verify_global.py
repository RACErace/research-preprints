"""Replay or complete a bounded table of local two- and three-edge repairs."""
import json
import sys
from pathlib import Path
from collections import Counter
import partners as v
from reconnect import minperiod,original, turn, co_certify


def viewed(c,seq,h,i,j,d):
    if not d:return seq,i,j
    q=len(seq)-2*c.radius-1
    length=(q+1)*8**h-1
    return v.normalize(v.reverse(seq),c.radius),length-j,length-i


def validate(c,seq,h,i,j,record,report=False):
    d,w=record[:2]
    v.need(d in (0,1),"direction")
    word,l,r=viewed(c,seq,h,i,j,d)
    if len(record)==2:
        c.partner(word,h,l,r,w)
        return True
    v.need(len(record)==5,"repair format")
    op,z,depth=record[2:]
    v.need(op in (0,1) and 1<=depth<=c.jdepth,"mode or depth")
    q=len(word)-2*c.radius-1
    span=(q+1)*c.T
    v.need((op and span-w-z<minperiod(word,h,l,r,c)) or (not op and w<z),"probe order")
    A=c.partner(word,h,l,r,w,stop=depth,cap=100000)
    wordB,lo,hi=viewed(c,word,h,l,r,op)
    B=c.partner(wordB,h,lo,hi,z,stop=depth,cap=100000)
    if op:B=[turn(a,span,word[c.radius+q],c.S) for a in B]
    return co_certify(c,original(word,h,l,r,c),A,B,op,report)


def second_works(c,seq,h,i,j,w,A,op,z,B,detail=False):
    if not op and z==w:return False
    I=original(seq,h,i,j,c)
    if op or w<z:return co_certify(c,I,[A],B,op,detail)
    return co_certify(c,I,B,[A],0,detail)


def verify_policy(c,s,h,i,j,record,detail=False):
    _,d,w,k,opts=record
    if d not in (0,1) or not(1<=k<=c.jdepth) or not opts:return False
    seq,lo,hi=viewed(c,s,h,i,j,d)
    A=c.partner(seq,h,lo,hi,w,stop=k,cap=100000)
    q=len(seq)-2*c.radius-1
    span=(q+1)*c.T
    todo=list(A)
    for op,z,p in opts:
        if op not in (0,1) or not(1<=p<=c.jdepth) or (op and span-z-w>=minperiod(seq,h,lo,hi,c)):return False
        if not op and w==z:return False
        other,l,r=viewed(c,seq,h,lo,hi,op)
        B=c.partner(other,h,l,r,z,stop=p,cap=100000)
        if op:B=[turn(a,span,seq[c.radius+q],c.S) for a in B]
        remaining=[]
        for arc in todo:
            if not second_works(c,seq,h,lo,hi,w,arc,op,z,B,detail):remaining.append(arc)
        todo=remaining
        if not todo:
            if detail:c.stats["conditional_records"]+=1
            return True
    return not todo


class Replay(v.Checker):
    def __init__(self,data):
        super().__init__(dict(data,leaves=[]))
        self.active={}
        for row in data["leaves"]:
            adaptive=(len(row)==10 and row[5]=="C")
            if adaptive:
                v.need(all(type(y) is int for y in row[:5]+row[6:9]) and isinstance(row[9],list),"conditional header")
                v.need(all(isinstance(opt,list) and len(opt)==3 and all(type(z) is int for z in opt) for opt in row[9]),"conditional branches")
            else:v.need(len(row) in (7,10) and all(type(y) is int for y in row),"record")
            key=tuple(row[:5]);v.need(key not in self.active,"duplicate record")
            self.active[key]=row[5:]

    def check_word(self,lag,k,seq):
        order=[(0,0,seq[self.radius],lag,seq[self.radius+lag])]
        while order:
            h,i,x,j,y=order.pop();self.stats["localization_rectangles"]+=1
            n=8**h
            if 2*(j+1-i)<n or j-i-1>=4*n:continue
            sq=sum((abs(a-b)+1)**2 for a,b in zip(x[0],y[0]))
            if self.b**2*max(n,2*(j-i-1))**2>=40000*sq**3:continue
            key=(lag,k,h,i,j)
            if key in self.active:
                hint=self.active[key]
                if hint[0]=="C":
                    v.need(verify_policy(self,seq,h,i,j,hint,True),"conditional coverage failed")
                else:v.need(validate(self,seq,h,i,j,hint,True),"joint coverage failed")
                self.used.add(key);self.hist[(lag,"conditional" if hint[0]=="C" else "single" if len(hint)==2 else "double")]+=1;continue
            v.need(h<self.idepth,"missing high interval")
            for u,a in enumerate(v.refine(x)):
                for t,b in enumerate(v.refine(y)):
                    order.append((h+1,8*i+u,a,8*j+t,b))

    def run(self):
        for lag in range(5):
            for i,s in enumerate(v.small_words(lag,self.radius)):
                self.check_word(lag,i,s)
            self.previous_words.cache_clear();self.endpoints.cache_clear()
            v.transformed.cache_clear();v.refine.cache_clear()
        v.need(self.active.keys()==self.used,"unused keys")
        print("upper cost",f"{self.target/100:.2f}","certificates",len(self.used))
        print("lag and certificate type",sorted(self.hist.items()))
        print("motifs",[(lo,len(grid.patterns)) for lo,(_,grid) in zip(self.levels,self.layers)])
        print("continuous branch counts",sorted(self.stats.items()))


if __name__=="__main__":
    data=json.loads(Path(sys.argv[1]).read_text())
    v.need(not data.get("unresolved"),"incomplete certificate")
    Replay(data).run()
