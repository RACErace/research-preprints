// Standalone checker for the strengthened nine-point forest. Read the decompressed certificate on stdin.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
using Perm=array<int,64>;
using XYZ=array<int,3>;
using Cube=array<pair<int,int>,3>;
using Wide=unsigned __int128;
constexpr int D=128, UNIT=65536, LIMIT=4*UNIT-2900;
int n=0;
vector<vector<int>> tours;
vector<int> weight;
vector<Perm> sym;
set<uint64_t> proven_orbits;
uint64_t total_signatures=0,nodes=0,leaves=0,parity_leaves=0;
int max_depth=0;
void require(bool p){if(!p)throw runtime_error("certificate check failed");}
int pinmask(int code){
    int result=0;
    for(int k=0;k<3;++k){
        int d=(code>>(2*k))%4;
        if(d==0||d==3)result|=1<<(2*k+(d==3));
    }
    return result;
}
uint64_t expected_signatures(){
    // Multisets of n boxes. Each of six faces has precisely one marked extremum.
    vector<array<uint64_t,64>> counts(n+1);counts[0][0]=1;
    for(int code=0;code<64;++code){
        int f=pinmask(code);auto next=counts;
        for(int used=0;used<n;++used)for(int taken=0;taken<64;++taken){
            if(taken&f)continue;
            for(int copies=1;used+copies<=n;++copies){
                next[used+copies][taken|f]+=counts[used][taken];
                if(f)break;
            }
        }
        counts.swap(next);
    }
    return counts[n][63];
}
void make_group(){
    Perm id{},swap01{},swap12{},flip{};
    for(int code=0;code<64;++code){
        int x=code%4,y=(code/4)%4,z=code/16;
        id[code]=code;swap01[code]=y+4*x+16*z;
        swap12[code]=x+4*z+16*y;flip[code]=3-x+4*y+16*z;
    }
    set<Perm> found{id};sym={id};
    for(size_t i=0;i<sym.size();++i){
        for(const auto& f:{swap01,swap12,flip}){
            Perm h{};for(int c=0;c<64;++c)h[c]=f[sym[i][c]];
            if(found.insert(h).second)sym.push_back(h);
        }
    }
    require(sym.size()==48);
}
void register_root(const vector<int>& codes){
    int pins=0;
    for(int code:codes){
        require(0<=code&&code<64);
        int f=pinmask(code);require((pins&f)==0);pins|=f;
    }
    require(pins==63);
    set<uint64_t> ids;
    for(const auto& g:sym){
        auto r=codes;for(int& x:r)x=g[x];sort(r.begin(),r.end());
        uint64_t id=0;for(int x:r)id=(id<<6)|x;
        ids.insert(id);
    }
    require(proven_orbits.insert(*ids.begin()).second);
    total_signatures+=ids.size();
}
void make_costs(){
    Wide den=8;for(int k=0;k<6;k++)den*=D;
    for(int s=0;s<=3*D*D;++s){
        Wide num=Wide(UNIT)*UNIT*s*s*s;
        int low=0,high=4*UNIT;
        while(low<high){
            int m=(low+high)/2;
            if(Wide(m)*m*den>=num)high=m;else low=m+1;
        }
        require(Wide(low)*low*den>=num);
        require(low==0||Wide(low-1)*(low-1)*den<num);
        weight.push_back(low);
    }
    vector<int> t(n);
    for(int j=0;j<n;++j)t[j]=j;
    do{if(t[1]<t.back())tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));
}
vector<Cube> decode(const vector<int>& codes){
    vector<Cube> b(n);
    for(int i=0;i<n;++i)for(int a=0;a<3;++a){
        int s=(codes[i]>>(2*a))&3;
        if(s==0)b[i][a]={0,0};
        if(s==1)b[i][a]={0,D/2};
        if(s==2)b[i][a]={D/2,D};
        if(s==3)b[i][a]={D,D};
    }
    return b;
}
bool corner_lemma(const vector<Cube>& boxes){
    int common=-1;
    for(const auto& b:boxes){
        int par=0;
        for(auto [lo,hi]:b){
            if(hi<=D/4)continue;
            if(lo>=3*D/4)par^=1;
            else return false;
        }
        if(common>=0&&par!=common)return false;
        common=par;
    }
    return true;
}
struct Section{array<XYZ,8> p;int size=0;};
Section vertices(const Cube& b){
    Section v{};
    for(int mask=0;mask<8;++mask){
        XYZ pt;bool use=true;
        for(int i=0;i<3;++i){
            auto [x,y]=b[i];bool upper=mask&(1<<i);
            if(x==y&&upper)use=false;
            pt[i]=upper?y:x;
        }
        if(use)v.p[v.size++]=pt;
    }
    return v;
}
int sqdistance(const XYZ& x,const XYZ& y){
    int q=0;for(int a=0;a<3;++a){int d=x[a]-y[a];q+=d*d;}return q;
}
bool strict_cycle(const vector<Cube>& b,const vector<int>& t){
    array<Section,9> v{};
    for(int i=0;i<n;++i)v[i]=vertices(b[t[i]]);
    int first=0;for(int i=1;i<n;++i)if(v[i].size<v[first].size)first=i;
    rotate(v.begin(),v.begin()+first,v.begin()+n);
    int w[9][8][8];
    for(int i=0;i<n;++i){int j=(i+1)%n;for(int a=0;a<v[i].size;++a)
        for(int k=0;k<v[j].size;++k)w[i][a][k]=weight[sqdistance(v[i].p[a],v[j].p[k])];}
    // For each fixed corner of the first cube, maximize over all other corners.
    for(int base=0;base<v[0].size;++base){
        int dp[8],next[8];
        for(int i=0;i<v[1].size;++i)dp[i]=w[0][base][i];
        for(int j=1;j+1<n;++j){
            for(int k=0;k<v[j+1].size;++k){
                next[k]=0;
                for(int i=0;i<v[j].size;++i)next[k]=max(next[k],dp[i]+w[j][i][k]);
            }
            copy(next,next+v[j+1].size,dp);
        }
        for(int k=0;k<v[n-1].size;++k)if(dp[k]+w[n-1][k][base]>=LIMIT)return false;
    }
    return true;
}
void tree(istringstream& in,vector<Cube>& b,int depth){
    require(depth<=200);max_depth=max(depth,max_depth);++nodes;
    int t;require(bool(in>>t));
    if(t<0){
        require(t>=-3*n);
        int i=(-t-1)/3,k=(-t-1)%3;auto [l,h]=b[i][k];
        require(h>l&&(h+l)%2==0);
        int m=(l+h)/2;
        b[i][k]={l,m};tree(in,b,depth+1);
        b[i][k]={m,h};tree(in,b,depth+1);
        b[i][k]={l,h};
    }else if(t==0){
        require(corner_lemma(b));++parity_leaves;++leaves;
    }else{
        require(t<=int(tours.size()));require(strict_cycle(b,tours[t-1]));++leaves;
    }
}
int main(){
    string line;require(bool(getline(cin,line)));istringstream header(line);string tag;
    require(bool(header>>tag>>n)&&tag=="MDS41MARGIN9"&&n==9);
    make_group();make_costs();
    while(getline(cin,line)){
        istringstream in(line);vector<int> codes(n);for(auto& x:codes)require(bool(in>>x));
        register_root(codes);auto b=decode(codes);tree(in,b,0);
        string extra;require(!(in>>extra));
    }
    auto expected=expected_signatures();
    require(total_signatures==expected&&nodes==2*leaves-proven_orbits.size());
    cout<<"n "<<n<<" signatures "<<expected<<" symmetry_orbits "<<proven_orbits.size()
        <<" nodes "<<nodes<<" leaves "<<leaves<<" parity_leaves "<<parity_leaves
        <<" strict_tour_leaves "<<leaves-parity_leaves<<" max_depth "<<max_depth<<'\n';
}
