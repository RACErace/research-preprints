"""All pure three-cut reconnections and interval-compatible joint tests."""
from itertools import product
from functools import lru_cache
import partners as v


@lru_cache(None)
def lift_box(p,side,origin,frame,S):
    # Apply the signed cube symmetry to the lower corner of a small axis-aligned box.
    corners=v.spring.CORNERS
    base=corners[frame[0]]
    result=[S*(origin[d]+base[d]) for d in range(3)]
    for n,idx in enumerate((4,2,1)):
        col=[corners[frame[idx]][k]-base[k] for k in range(3)]
        for k,co in enumerate(col):
            if co:result[k]+=co*(p[n]+(side if co<0 else 0))
    return tuple(result)


def turn(arc,span,cell,S):
    u,U,v_,V,c,e,h,old,high,qlower=arc
    origin,(_,frame,_)=cell
    return (span-V,span-v_,span-U,span-u,lift_box(e,h,origin,frame,S),
            lift_box(c,h,origin,frame,S),h,old,high,qlower)


@lru_cache(None)
def top_cores(q,radius):
    length=q+2*radius+1
    top=v.spring.TOP*((length+14)//8)
    return {v.normalize(w,radius) for k in range(8) for w in (top[k:k+length],v.reverse(top[k:k+length]))}

def minperiod(core,h,i,j,c):
    lag=len(core)-2*c.radius-1
    duration=max(c.T//2,(j-i-1)*(c.T//8**h))
    period=(8 if core in top_cores(lag,c.radius) else 64)*c.T
    while c.b**2*duration**2>=270000*period**2:period*=8
    return period

def original(core,h,i,j,c):
    lag=len(core)-2*c.radius-1
    n=8**h;step=c.T//n;side=c.S//(2**h)
    a=v.lower_corner(v.subcell(core[c.radius],i,h),side)
    b=v.lower_corner(v.subcell(core[c.radius+lag],j-lag*n,h),side)
    cost=max(100*c.b*max(c.T//2,(j-i-1)*step),10000*v.min_weight(a,side,b,side))
    return (i*step,(i+1)*step,j*step,(j+1)*step,a,b,side,cost,True,minperiod(core,h,i,j,c),(c.target-c.b)*max(c.T//2,(j-i-1)*step))


MOVES=[]
for f in product((0,1),repeat=3):
    # Paths run from end of old edge k to start of old edge k+1.
    paths=[(2*k+1,((2*k+2)%6)) for k in range(3)]
    paths=[pair[::-1] if bit else pair for bit,pair in zip(f,paths)]
    added=tuple((paths[k][1],paths[(k+1)%3][0]) for k in range(3))
    if all(a//2!=b//2 for a,b in added):MOVES.append(added)


def could_be_same(A,B,mixed,firstperiod):
    # Both are represented in the original, chronological frame.
    a,A1,b,B1,x,y,h,_,_=A[:9]
    c,C,d,D,z,w,g,_,_=B[:9]
    if any(p>q+g or q>p+h for p,q in zip(x,z)):return False
    if any(p>q+g or q>p+h for p,q in zip(y,w)):return False
    low=max(c-A1,d-B1);high=min(C-a,D-b)
    if not mixed:return low<=0<=high
    period=firstperiod
    while period<=high:
        if low<=period:return True
        period*=8
    return False


def triple(c,cuts,index):
    I=cuts[index]
    # Maximum one-sided reach to the beneficiary far endpoint.
    P=max(I[3]-cuts[0][2] if index>0 else 0,cuts[-1][1]-I[0] if index<2 else 0)
    P=min(P,((100+c.a)*min(4*c.T,I[3]-I[0])+99)//100)
    if P<=0:return False
    shields=[c.protected_length(max(0,z[2]-z[1],c.T//2 if k==index else 0),z[10] if k==index else z[9]) for k,z in enumerate(cuts)]
    inner=0
    for m,(left,right) in enumerate(zip(cuts,cuts[1:])):
        mid=max(0,right[1]-left[2])
        # In any realized triple internal intervals are no longer than the priority.
        mid=min(mid,P)
        inner+=c.middle(left[2],left[3],right[0],right[1],mid,shields[m],shields[m+1])
    load=inner+c.side(cuts[0][0],cuts[0][1],P,-1,shields[0])+c.side(cuts[-1][2],cuts[-1][3],P,+1,shields[-1])
    # I's demand cancels against its old edge exactly.
    net=c.b*max(c.T//2,I[2]-I[1])
    for k,other in enumerate(cuts):
        if k==index:continue
        lower=max(0,other[2]-other[1])
        net+=other[7] if lower>P else max(min(other[7],c.b*lower),other[7]-(1700-c.b)*P)
    allowed=net-load
    pts=[(p,cut[6]) for cut in cuts for p in cut[4:6]]
    def newedge(a,b):
        p,h=pts[a];q,g=pts[b]
        return v.max_weight(p,h,q,g)
    return any(100*sum(newedge(a,b) for a,b in added)<=allowed for added in MOVES)


def co_certify(c,I,L,R,mixed,detail=False):
    triples=excluded=0
    for l in L:
        for r in R:
            if could_be_same(l,r,mixed,I[9]):return False
            if not mixed:
                if l[2]>r[1]:excluded+=1;continue
                cuts=(l,r,I);idx=2
            else:
                cuts=(l,I,r);idx=1
            if not triple(c,cuts,idx):return False
            triples+=1
    if detail:
        c.stats["three_cut_pairs"]+=triples
        c.stats["inconsistent_partner_pairs"]+=excluded
    return True
