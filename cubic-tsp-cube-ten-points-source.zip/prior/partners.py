"""Integer replay for one probe and the geometric boxes left for its successors."""
from collections import Counter, defaultdict
from functools import lru_cache
from budget import Budget
import spring_base as spring
from curve_windows import need, refine, normalize, reverse, subcell, lower_corner, min_weight, max_weight, stream_windows, small_words, transformed


class Checker:
    def __init__(self, data):
        need(data.get("format")=="MDS41-LOCAL-2","format")
        self.b, self.target, self.a, self.D = data["coefficients"]
        self.radius=data.get("context_radius",2)
        need(2<=self.radius<=12,"context radius")
        self.level,self.idepth,self.jdepth=data["depths"]
        self.T=8**self.level
        self.S=2**self.level
        need(3<=self.idepth<=self.level<=8 and 1<=self.jdepth<=self.level,"depth policy")
        E=1700-self.target
        need(0<self.b<self.target<1700,"coefficient ranges")
        need(2*(100+self.a)*(1700-self.b) <= 100*self.D*(self.target-self.b),"long-partner range")
        # All high chords have duration < (sqrt(3))^3 / b in global units.
        # This suffices for choosing a finer level and guarantees that the probe is outside I.
        need(4*27*100**2 < self.b**2,"first nontrivial level")
        need(27*(100+self.a)**2 < self.b**2,"probe lies on complementary arc")
        self.levels=data["rate_thresholds"]
        need(self.levels[0]==self.b and self.levels[-1]==1700 and all(x<y for x,y in zip(self.levels,self.levels[1:])),"thresholds")
        self.layers=[(y-x,Budget(x,self.a,slots=data.get("budget_slots",128))) for x,y in zip(self.levels,self.levels[1:])]
        self.shield=data.get("protected_boundary",True)
        need(self.level==6 and 2<=self.radius<=6,"normalization")
        self.mode=data.get("credit_mode","half")
        need(self.mode in ("half","both"),"credit mode")
        self.used=set()
        self.stats=Counter()
        self.hist=Counter()

    @lru_cache(None)
    def previous_words(self,lag):
        offset=self.D*min(lag+1,4)+self.radius+1
        length=offset+lag+self.radius+1
        completions=defaultdict(set)
        for seq in stream_windows(length):
            for word in (seq,reverse(seq)):
                norm=normalize(word,offset)
                completions[norm[offset-self.radius:]].add(norm[:offset+1])
        return offset,completions

    @lru_cache(None)
    def endpoints(self,core,iu,iv):
        # Chronological order: first partner endpoint u, then v, then I.
        offset,groups=self.previous_words(len(core)-2*self.radius-1)
        need(0<=offset+iu<=offset+iv<=offset and core in groups,"incomplete extension")
        return tuple(sorted({(s[offset+iu],s[offset+iv]) for s in groups[core]}))

    @lru_cache(maxsize=250000)
    def side(self,lo,hi,reach,sign,cut=0):
        return sum(inc*table.cover(lo,hi,reach,sign,cut) for inc,table in self.layers)

    @lru_cache(maxsize=150000)
    def middle(self,l,L,r,R,gap,ca=0,cb=0):
        return sum(inc*min(gap,table.cover(l,L,gap,+1,ca)+table.cover(r,R,gap,-1,cb)) for inc,table in self.layers)

    def protected_length(self,L,qlower):
        if not self.shield:return 0
        value=min(100*L//self.a,100*qlower//(2*(1700-self.b)*(100+self.a)))
        for cut in (4*self.T,2*self.T,self.T,self.T//2,self.T//4,self.T//8,self.T//32,self.T//128):
            if cut<=value:return cut
        return 0

    def partner(self,core,h,i,j,probe,stop=0,cap=1000):
        residual=[]
        T,S=self.T,self.S
        lag=len(core)-2*self.radius-1
        block=8**h
        it=T//block
        si,st=i*it,(i+1)*it
        tl=j*it
        tt=(j+1)*it
        lo_i=max(T//2,(j-i-1)*it)
        hi_i=min(4*T,(j-i+1)*it)
        need(probe<si and 100*(st-probe)<=self.a*lo_i, "probe clearance")
        side_i=S//(2**h)
        a=lower_corner(subcell(core[self.radius],i,h),side_i)
        b=lower_corner(subcell(core[self.radius+lag],j-lag*block,h),side_i)
        roots=set()
        for left in range((probe-self.D*hi_i)//T,probe//T+1):
            for right in range(probe//T,min(0,st//T)+1):
                for first,last in self.endpoints(core,left,right):
                    roots.add((0,left*T,first,right*T,last))
        need(roots,"empty partner cover")
        pending=list(roots)
        while pending:
            k,u,x,v,y=pending.pop()
            self.stats["partner_rectangles"]+=1
            time=T//(8**k)
            # Intersect each closed parameter cylinder with the probe and gap constraints.
            u_low=max(u,probe-self.D*hi_i)
            u_high=min(u+time,probe)
            v_low=max(v,probe)
            v_high=min(v+time,st)
            if u_low>u_high or v_low>v_high:
                continue
            lower=max(0,v_low-u_high)
            upper=v_high-u_low
            if lower>self.D*hi_i:
                continue
            side=S//(2**k)
            c=lower_corner(x,side)
            e=lower_corner(y,side)
            j_upper=max_weight(c,side,e,side)
            j_lower=min_weight(c,side,e,side)
            reach=tt-v_low
            # Each bound on the load is expressed in hundredths of a time-grid unit.
            liability=self.side(v_low,v_high,reach,+1)
            if self.mode=="both":
                credit=liability+self.side(u_low,u_high,reach,-1)
            else:credit=2*liability
            q_lower=max((self.target-self.b)*lower,self.target*lower-100*j_upper)
            if q_lower>=credit:
                self.stats["credit_terminals"]+=1
                continue
            oldlower=max(100*j_lower,self.target*lower-credit)
            # Pay the beneficiary I exactly; its cost above b cancels.
            # If partner J itself bears demand, cap it both by its real excess and by its maximum possible priority length.
            net=oldlower if lower>reach else max(min(oldlower,self.b*lower),oldlower-(1700-self.b)*reach)
            before=self.b*lo_i+net
            after=100*(max_weight(a,side_i,c,side)+max_weight(b,side_i,e,side))
            middle=max(0,st-v_low)
            cj=self.protected_length(lower,q_lower)
            ci=self.protected_length(lo_i,(self.target-self.b)*lo_i)
            center=self.middle(v_low,v_high,si,st,middle,cj,ci)
            required=center+self.side(u_low,u_high,reach,-1,cj)+self.side(tl,tt,reach,+1,ci)
            if before-after>=required:
                self.stats["exchange_terminals"]+=1
                continue
            if stop and k>=stop:
                residual.append((u_low,u_high,v_low,v_high,c,e,side,oldlower,100*j_upper>self.b*lower,q_lower))
                if len(residual)>cap:raise ValueError("residual cap")
                continue
            need(k<self.jdepth,"unproved partner inequality")
            child_time=time//8
            for kx,cx in enumerate(refine(x)):
                for ky,cy in enumerate(refine(y)):
                    pending.append((k+1,u+kx*child_time,cx,v+ky*child_time,cy))

        return sorted(set(residual))

