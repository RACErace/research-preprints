"""Count cube-box signatures fixed by each of the 48 isometries."""
from collections import Counter
from itertools import permutations, product

N = 10

def action(axis, flip):
    result = []
    for c in range(64):
        digits = [(c >> (2 * axis[k])) & 3 for k in range(3)]
        result.append(sum((3-d if flip[k] else d) << (2*k) for k, d in enumerate(digits)))
    return result

def fixed_counts(g):
    remaining = set(range(64))
    counts = {(0, 0): 1}
    while remaining:
        i = min(remaining)
        orbit = []
        while i in remaining:
            remaining.remove(i)
            orbit.append(i)
            i = g[i]
        marks = []
        for i in orbit:
            for axis in range(3):
                digit = (i >> (2*axis)) & 3
                if digit in (0, 3):
                    marks.append(2*axis + int(digit == 3))
        if len(set(marks)) != len(marks):
            continue
        mask = sum(1 << face for face in marks)
        size = len(orbit)
        updated = counts.copy()
        for (used, occupied), count in counts.items():
            if occupied & mask:
                continue
            limit = (N-used)//size
            if mask:
                limit = min(limit, 1)
            for multiple in range(1, limit+1):
                key = used+multiple*size, occupied|mask
                updated[key] = updated.get(key, 0) + count
        counts = updated
    return counts.get((9,63),0), counts.get((10,63),0)

group = [action(axis, flip) for axis in permutations(range(3)) for flip in product(range(2), repeat=3)]
if len({tuple(g) for g in group}) != 48:
    raise ValueError("cube isometries")
fixed = [fixed_counts(g) for g in group]
raw = fixed_counts(list(range(64)))
orbits = tuple(sum(row[k] for row in fixed)//48 for k in range(2))
if raw != (4898208,11295372) or orbits != (103991,238996):
    raise ValueError("unexpected orbit count")
print("nine and ten signatures", raw, "orbits", orbits)
