constexpr bool WITH_MARGIN=true;
#include "search.hpp"

uint64_t read_nodes=0,changed=0,old_ok=0;
bool refine_old(istringstream& stream,Boxes b,const Constraints& c,int depth){
    int label;if(!(stream>>label))throw runtime_error("truncated base tree");
    ++read_nodes;
    if(!c.tighten(b)){if(label!=CLOSE_LEAF+1)throw runtime_error("base order");proof.push_back(label);return true;}
    if(label<0){
        int i=(-label-1)/3,k=(-label-1)%3;
        int l=b[i].l[k],h=b[i].h[k],m=(l+h)/2;
        if(h-l<2)throw runtime_error("base split");
        proof.push_back(label);
        b[i].h[k]=m;if(!refine_old(stream,b,c,depth+1))return false;
        b[i].l[k]=m;b[i].h[k]=h;return refine_old(stream,b,c,depth+1);
    }
    Pool p;p.fill(-1);
    if(label>0&&label<=TourCount){
        Node n(b);p[0]=label-1;
        if(n.worst(tours[p[0]],TARGET-1)<TARGET){
            proof.push_back(label);++old_ok;return true;
        }
    }else if(label==0){
        int par=color(b[0]);if(par>=0&&all_of(b.begin()+1,b.end(),[par](const Box& g){return color(g)==par;})){
            proof.push_back(0);++old_ok;return true;
        }
    }
    ++changed;
    return solve(b,c,depth,p);
}
int main(int argc,char** argv){
    if(argc>2)return 2;
    int expected=argc==2?stoi(argv[1]):238996;
    init();index_tours();index_orientations();
    per_root_limit=9000;aggregate_limit=24000000;
    string line;int nr=0;cout<<"MDS41TEN-RIGID 10\n";
    while(getline(cin,line)){
        Pattern p;istringstream row(line);for(int& x:p)if(!(row>>x))return 2;
        for(int i=0;i<N;++i){
            preserves_faces[i]=true;for(int k=0;k<3;++k){int e=p[i]>>(2*k)&3;if(e==0||e==3)preserves_faces[i]=false;}
        }
        rootstart=nodes;proof.clear();
        if(!refine_old(row,decode(p),Constraints(p),0)){
            cerr<<"stopped root "<<nr<<" extra_nodes "<<nodes<<" root_nodes "<<nodes-rootstart
                <<" reason "<<unresolved_code<<" pattern";
            for(int i:p)cerr<<' '<<i;cerr<<'\n';return 1;
        }
        string extra;if(row>>extra)return 2;
        for(int x:p)cout<<x<<' ';for(int token:proof)cout<<token<<' ';cout<<'\n';
        if(++nr%10000==0)cerr<<"roots "<<nr<<" extra_nodes "<<nodes<<" changed "<<changed<<" unchanged "<<old_ok<<'\n';
    }
    cerr<<"roots "<<nr<<" old_nodes "<<read_nodes<<" extra_nodes "<<nodes<<" changed "<<changed<<" unchanged "<<old_ok<<'\n';
    return nr==expected?0:1;
}
