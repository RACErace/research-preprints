// Add one unpinned label to each of the nine-point box orbits.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
int main(){
    using Row=array<int,10>;using Map=array<int,64>;
    vector<Map> group;array<int,3> axis{0,1,2};
    do {for(int f=0;f<8;++f){
        Map g{};for(int c=0;c<64;++c)for(int k=0;k<3;++k){
            int d=c>>(2*axis[k])&3;g[c]|=((f>>k&1)?3-d:d)<<(2*k);
        }group.push_back(g);
    }}while(next_permutation(axis.begin(),axis.end()));
    // Only canonical keys are stored. Their digits are sorted box codes.
    unordered_set<uint64_t> keys; keys.reserve(260000);
    string line;getline(cin,line);if(line!="MDS41MARGIN9 9")return 2;
    size_t parents=0;
    while(getline(cin,line)){
        istringstream in(line);Row p;
        for(int i=0;i<9;++i)if(!(in>>p[i]))return 2;
        ++parents;
        for(int a:{1,2})for(int b:{1,2})for(int c:{1,2}){
            p[9]=a+4*b+16*c;
            uint64_t best=~uint64_t(0);
            for(const auto& g:group){
                Row img;
                for(int j=0;j<10;++j)img[j]=g[p[j]];
                sort(img.begin(),img.end());uint64_t id=0;
                for(int x:img)id=(id<<6)|x;
                best=min(best,id);
            }
            keys.insert(best);
        }
    }
    vector<uint64_t> ordered(keys.begin(),keys.end());sort(ordered.begin(),ordered.end());
    for(uint64_t key:ordered){
        for(int j=9;j>=0;--j)cout<<((key>>(6*j))&63)<<(j?' ':'\n');
    }
    cerr<<"parent orbits "<<parents<<" ten orbits "<<keys.size()<<'\n';
    return parents!=103991||keys.size()!=238996;
}
