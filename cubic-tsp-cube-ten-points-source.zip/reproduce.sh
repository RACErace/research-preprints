#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
scratch=$(mktemp -d)
trap 'rm -r -- "$scratch"' EXIT
sha256sum -c --quiet SHA256SUMS
c++ -O2 -std=c++17 verify_ten.cpp -o "$scratch/verify-ten"
for phase in base rigid; do
    xz -dc "ten-$phase.xz" | "$scratch/verify-ten" > "$scratch/$phase.log"
    diff -u "$phase.log" "$scratch/$phase.log"
    cat "$scratch/$phase.log"
done
for check in symmetry constants; do
    python3 -B "$check.py" > "$scratch/$check.log"
    diff -u "$check.log" "$scratch/$check.log"
    cat "$scratch/$check.log"
done
c++ -O2 -std=c++17 prior/verify9.cpp -o "$scratch/verify-nine"
gzip -dc prior/margin9.gz | "$scratch/verify-nine" > "$scratch/nine.log"
diff -u prior/nine.log "$scratch/nine.log"
cat "$scratch/nine.log"
c++ -O2 -std=c++17 prior/small/verify_boxes.cpp -o "$scratch/verify-small-boxes"
for n in 7 8; do
    gzip -dc "prior/small/n$n.boxes.gz" | "$scratch/verify-small-boxes" > "$scratch/boxes$n.log"
    diff -u "prior/small/boxes$n.log" "$scratch/boxes$n.log"
    cat "$scratch/boxes$n.log"
done
python3 -B prior/small/verify_finite.py > "$scratch/finite.log"
diff -u prior/small/finite.log "$scratch/finite.log"
cat "$scratch/finite.log"
python3 -B prior/spring_base.py > "$scratch/curve.log"
diff -u prior/curve.log "$scratch/curve.log"
cat "$scratch/curve.log"
python3 -B prior/verify_global.py prior/global.json > "$scratch/global.log"
diff -u prior/global.log "$scratch/global.log"
cat "$scratch/global.log"
echo 'All ten-point, rigidity, and auxiliary certificate replays match.'
