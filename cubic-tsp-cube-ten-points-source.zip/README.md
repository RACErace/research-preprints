# 三维立方巡回的十点定理

2026 年 11 月 26 日的研究预印本配套材料。对十个标记点，以每边欧氏长度的立方之和计费，最小成本满足

```text
L(X) ≤ 8√2 − min{(9/8) s(X), 125√2/512} .
```

s 是最近两标记的欧氏距离。十个互异点的上确界恰为 8√2，只在极限中达到。十一点若有一对距离至多 √3/5，其成本严格低于 8√2。任意严格反例至少包含十一个两两距离大于 1/20 的点。任意点数的上界仍为 16.10，十一点的全部情形仍待判定。

## 从公开源码复现

公开 ZIP 不直接包含约 87 MB 的两套十点森林。它包含生成器、独立核验器、完整证明、标准输出及前置小点数证书。先克隆同一公开仓库，以取得前一篇预印本的九点森林；再在本 ZIP 的解压目录执行：

```bash
bash reconstruct.sh /path/to/research-preprints
```

这个脚本核对九点输入的压缩态及原始态摘要，重建全部根，生成两套十点森林，最后运行独立核验程序。默认分六个进程运行基础搜索；机器资源紧张时可用 `SERIAL=1`。生成可能需要较长时间。原始三份数据文件摘要见 `ORIGINAL-DATA-SHA256.txt`。自行生成的压缩文件不需要与原始归档逐字节一致；独立检查器必须完整通过，并与标准输出一致。

## 离线重放

已有 `ten-base.xz`、`ten-rigid.xz` 和 `prior/margin9.gz` 时运行

```sh
bash reproduce.sh
```

需要 Bash、Python 3.10 或更新版本、NumPy、GNU sha256sum、xz、gzip、diff，以及支持 unsigned __int128 的 C++17 编译器。仅四至六点的前置核验使用 NumPy，十点的两套森林均只需要 C++17 和 xz。完整重放流式读取证书，使用临时目录存放可执行文件和输出；建议预留数 GiB 内存用于既有全局 16.10 程序。无须联网。完整程序先检查 SHA-256，再与归档的标准输出逐项对照。

单独核验较强的十点连续覆盖可运行

```sh
set -o pipefail
c++ -O2 -std=c++17 verify_ten.cpp -o ./check-ten
xz -dc ten-rigid.xz | ./check-ten
```

## 证明稿和证书

- `proof.md` 是完整中文稿，`print-style.html` 是其可打印版的排版样式。配套 PDF 单独交付，`PDF-SHA256.txt` 记录其摘要。
- `ten-base.xz` 和 `ten-rigid.xz` 分别是基本十点上界森林和定量近取等森林。它们含全部十点根，不必知道生成时的代表顺序。前者含 18,394,548 个节点、9,316,772 个叶；后者含 35,755,526 个节点、17,997,261 个叶。
- 解压后首行为 `MDS41TEN-BASE 10` 或 `MDS41TEN-RIGID 10`。每个后续行先列十个根盒码，再列二叉树的前序整数。−1−3i−k 把第 i 个标签的第 k 轴向下取整中点一分为二。0 调用角盒引理。1 至 181440 是无向巡回的一基编号。200000+x 检查删除标签 x 后每条巡回的邻边插入。200020 对应被最大距离保证的近双点，200021 对应空的标签次序区域。后两类在最终两棵森林中皆未出现。
- `verify_ten.cpp` 是独立核验器，重新生成立方体对称群和巡回表，再用整数计算权重和固定巡回的最坏成本。逐根验证轨道无重叠，核对轨道大小之和等于合法根数，重放闭盒的所有分支。补充输出 `needed_nine_margin` 计需要动用九点定量余量的删点叶，`needed_angle` 计仅用独立边长区间无法通过、加上角度判据才通过的删点叶。基本森林的 43 个删点叶都属于后一类。加强森林完全由固定巡回和四角盒两类叶组成。
- `symmetry.py` 通过 Burnside 引理独立计数。`constants.py` 用有理数和整数平方根验证余量、斜率、合并与球簇展开的不等式。`base.log`、`rigid.log`、`symmetry.log`、`constants.log` 是参考输出。
- `prior/` 包含本稿使用的四至九点前置证书、闭合 Spring 曲线的单弦核验和此前全局 16.10 的区间证书。前置定理的解析部分也写在本稿内；全局 16.10 的重放用于核对既有基准。

## 可选的重新构造

验证不调用候选搜索。要从现有九点森林重建基本十点森林，可在独立工作目录使用下面的命令。这里以单个确定性分片重建，根与行为同一集合，排列顺序允许与归档不同。

```sh
set -o pipefail
c++ -O3 -std=c++17 roots.cpp -o ./make-roots
c++ -O3 -std=c++17 generate.cpp -o ./make-base
gzip -dc prior/margin9.gz | ./make-roots > roots.txt
{ echo 'MDS41TEN-BASE 10'; ./make-base roots.txt 0 1 0 80000; } | xz -2 -T1 -c > rebuilt-base.xz
xz -dc rebuilt-base.xz | ./check-ten
```

`roots.cpp` 向九点根加入一个没有面极值标记的点，再取十点规范代表。`generate.cpp` 及共用的 `search.hpp` 用便宜插入、两边换法和子集动态规划挑选候选，然后对整盒计算上界。在根内按候选巡回的最坏盒顶点选择分叉。候选搜索过程中的排序、预算和评分都不作为证明。`generation.log` 保留实际有限分片的计数。

从交付的基本树重建加强版可运行

```sh
set -o pipefail
c++ -O3 -std=c++17 refine.cpp -o ./make-rigid
xz -dc ten-base.xz | tail -n +2 | ./make-rigid | xz -2 -T1 -c > rebuilt-rigid.xz
xz -dc rebuilt-rigid.xz | ./check-ten
```

`refine.cpp` 只替换未达到新要求的叶。这次构造保留 3,442,599 个基本叶，替换 5,874,173 个，使用 23,235,151 个额外搜索节点。交付的独立加强树已经展开，重放它不需要基本树。`SHA256SUMS` 覆盖压缩包内除清单本身之外的全部文件。
