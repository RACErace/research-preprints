#!/usr/bin/env bash
set -euo pipefail
# Run with a clone of RACErace/research-preprints as the sole argument.
[[ $# == 1 ]] || { echo 'usage: bash reconstruct.sh /path/to/research-preprints' >&2; exit 2; }
repo=$(cd -- "$1" && pwd)
cd -- "$(dirname -- "$0")"
work=$(mktemp -d)
trap 'rm -r -- "$work"' EXIT
d="$repo/cubic-tsp-cube-reordering-data"
cat "$d"/margin9.boxes.xz.part-* > "$work/margin9.boxes.xz"
(cd "$work" && sha256sum -c --quiet "$d/MARGIN-XZ-SHA256.txt")
xz -dc "$work/margin9.boxes.xz" > "$work/margin9.boxes"
printf '728675a68350668e79aa873270eef5174f7368409ed30453102a490fb1e2caf1  margin9.boxes\n' > "$work/margin9.sum"
(cd "$work" && sha256sum -c --quiet margin9.sum)
gzip -n -1 < "$work/margin9.boxes" > prior/margin9.gz
c++ -O3 -std=c++17 roots.cpp -o "$work/roots"
c++ -O3 -std=c++17 generate.cpp -o "$work/base"
c++ -O3 -std=c++17 refine.cpp -o "$work/refine"
"$work/roots" < "$work/margin9.boxes" > "$work/roots.txt"
[[ $(wc -l < "$work/roots.txt") == 238996 ]]
# SERIAL=1 reduces simultaneous memory and CPU use at the expense of time.
pids=()
for k in 0 1 2 3 4 5; do
    if [[ ${SERIAL:-0} == 1 ]]; then
        "$work/base" "$work/roots.txt" "$k" 6 0 80000 > "$work/base-$k.txt"
    else
        "$work/base" "$work/roots.txt" "$k" 6 0 80000 > "$work/base-$k.txt" &
        pids+=("$!")
    fi
done
ok=1
for pid in "${pids[@]}"; do wait "$pid" || ok=0; done
[[ $ok == 1 ]]
{ echo 'MDS41TEN-BASE 10'; cat "$work"/base-[0-5].txt; } | xz -2 -T1 -c > "$work/ten-base.xz"
cat "$work"/base-[0-5].txt | "$work/refine" | xz -2 -T1 -c > "$work/ten-rigid.xz"
mv -- "$work/ten-base.xz" "$work/ten-rigid.xz" .
bash reproduce.sh
