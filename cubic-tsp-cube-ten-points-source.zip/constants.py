"""Rational enclosures for the scalar estimates in the manuscript."""
from fractions import Fraction as Q
from math import isqrt

def check(ok):
    if not ok:
        raise ArithmeticError("invalid scalar inequality")

def sqrt_box(x):
    x = Q(x)
    D = 10**15
    q = isqrt(x.numerator * D**2 // x.denominator)
    return Q(q,D), Q(q + (q*q*x.denominator < x.numerator*D**2),D)

lo2, hi2 = sqrt_box(2)
lo3, hi3 = sqrt_box(3)
Hlo, Hhi = 8*lo2, 8*hi2
eta9lo, eta9hi = 725*lo2/8192, 725*hi2/8192
eta10lo, eta10hi = 125*lo2/512, 125*hi2/512

def a_lower(r):
    return 4*lo2*(1-r)/3 - r*sqrt_box(2+r*r)[1]/2

def midpoint_upper(dl,du):
    return du**3 + Q(3,2)*du**2*sqrt_box(3-dl+du**2/4)[1]

q = Q(1,4)
check(a_lower(q)-17*q*q>Q(1,6))
for r in (Q(2,25), q):
    check(r*(a_lower(r)-Hhi*r*r)>eta9hi)
check(3*((2+q*q)*sqrt_box(2+q*q)[1]+17*q**3)<Hlo-eta9hi)
p = Q(3,14)
check(midpoint_upper(p,p)<eta9lo and 3*Q(2,25)**2<p*p)
print("nine-point rigidity and the 3/14 merge verified")

u = Q(1,8)
check((a_lower(u)-Hhi*u*u)*sqrt_box(Q(2,3))[0] > Q(9,8))
check(3*((2+u*u)*sqrt_box(2+u*u)[1]+17*u**3)<Hlo-eta10hi)
B = Q(27,80)
check(eta10lo>B and midpoint_upper(lo3/5, hi3/5)<B)
print("ten-point slope > 9/8, eleven-point split cost < 27/80 < ten-point margin")

r=Q(1,20)
R=u+4*r
check(R==Q(13,40) and 4*r<=1-2*R)
check(Q(21,20)**3>Hhi/10)
reopen = 10*17*(2*r)**3 + 20*(3*Q(21,20)+4*r)*r*r
check(reopen==B)
internal = 10*(17*(2*r)**3 + 2*(3*hi3*u+4*r)*r*r)
check(internal<Q(17,80)<(a_lower(R)-Hhi*u*u)/4)
check(3*((2+R*R)*sqrt_box(2+R*R)[1] + Hhi*u**3)+internal<Hlo)
print("ten radius-1/20 balls: reopening <= 27/80; corner-group error < 17/80")
