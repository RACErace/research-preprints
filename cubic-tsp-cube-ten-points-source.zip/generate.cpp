constexpr bool WITH_MARGIN=false;
#include "search.hpp"

int main(int argc,char** argv){
    if(argc<4){cerr<<"usage: generate roots.txt residue modulus [cap [nodes-per-root]]\n";return 2;}
    init();index_tours();index_orientations();
    int residue=stoi(argv[2]),mod=stoi(argv[3]),cap=argc>4?stoi(argv[4]):0;
    if(argc>5)per_root_limit=stoull(argv[5]);
    ifstream input(argv[1]);if(!input)return 2;
    string line;int index=-1,nr=0;Pool none;none.fill(-1);
    while(getline(input,line)){
        if(++index%mod!=residue)continue;
        istringstream row(line);Pattern p{};for(int& x:p)if(!(row>>x))return 2;
        rootstart=nodes;proof.clear();
        if(!solve(decode(p),Constraints(p),0,none)){
            cerr<<"unresolved "<<index<<" reason "<<unresolved_code<<" nodes "<<nodes-rootstart<<'\n';return 1;
        }
        cout<<line;for(int s:proof)cout<<' '<<s;cout<<'\n';
        if(++nr%2000==0)cerr<<"shard "<<residue<<" completed "<<nr<<" nodes "<<nodes<<" depth "<<count_all.deepest<<'\n';
        if(cap&&nr>=cap)break;
    }
    cerr<<"done "<<residue<<" roots "<<nr<<" nodes "<<nodes<<" depth "<<count_all.deepest<<" cycles "<<count_all.cycle<<" close "<<closepairs<<" deletion "<<deletes<<" parity "<<count_all.local<<" order "<<conflicts<<" exact_seeds "<<exact_seeds<<'\n';
    return 0;
}
