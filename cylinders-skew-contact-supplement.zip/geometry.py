"""Exact geometric corollaries of the contact rectangle and tree dimensions."""
from collections import Counter
from fractions import Fraction as F
from math import factorial


def cos_bounds(degrees):
    # 333/106 < pi < 355/113, and cosine decreases in this angular range.
    x=F(degrees,180)*F(355,113);y=F(degrees,180)*F(333,106)
    low=sum((-1)**k*x**(2*k)/factorial(2*k) for k in range(8))
    high=sum((-1)**k*y**(2*k)/factorial(2*k) for k in range(9))
    return low,high


def rooted(g,u,back):
    return "("+ "".join(sorted(rooted(g,v,u) for v in g[u] if v!=back))+")"


def shapes():
    prev={"()":((),)}
    for n in range(1,9):
        current={}
        for g in prev.values():
            for u in range(n):
                new=list(g);new[u]=new[u]+(n,);new.append((u,))
                new=tuple(new);code=min(rooted(new,v,-1) for v in range(n+1))
                current[code]=new
        prev=current
    return prev


def run(doc):
    tl,th=map(F,doc["region"]["box"][0]);yl,yh=map(F,doc["region"]["box"][1])
    lb=F(1464466094,10**10);ub=F(1464466095,10**10)
    assert (2-4*lb)**2>2>(2-4*ub)**2 and lb>0
    assert tl>(1-tl)/lb and yl*yl<lb and yh*yh<lb
    assert tl*yl+(1-tl)*ub/yl < F(295,1000)
    assert th*yh+(1-th)*lb/yh > F(317,1000)
    assert cos_bounds(23)[0]>2*tl-1 and cos_bounds(17)[1]<2*th-1
    assert cos_bounds(68)[0]>1-2*F(317,1000) and cos_bounds(66)[1]<1-2*F(295,1000)
    print("All contacts with axis angle 17 to 23 degrees and tangency angle 66 to 68 degrees are excluded.")
    trees=shapes()
    by_leaf=Counter(sum(len(ns)==1 for ns in g) for g in trees.values())
    dims=Counter()
    for leaves,count in by_leaf.items():dims[16-(leaves+1)//2]+=count
    assert len(trees)==47 and sorted(dims.items())==[(12,4),(13,23),(14,19),(15,1)]
    print("Tree counts by number of leaves:",sorted(by_leaf.items()))
    print("All-skew witness dimension bounds (dimension, shapes):",sorted(dims.items()))


if __name__=="__main__":
    import json,sys
    from pathlib import Path
    run(json.loads(Path(sys.argv[1]).read_text()))

