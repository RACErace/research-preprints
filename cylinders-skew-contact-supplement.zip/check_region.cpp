// Verify an entire two-parameter region of nonparallel marked edges.
// Strict lower Bernstein bounds certify the auxiliary. Directed fixed-point
// intervals certify constraints for both endpoints and every parameter cell.
#include "subdivide.hpp"
#include <array>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
using Wide=__int128_t;
constexpr Z unit=1LL<<20;
struct Interval { Z lo,hi; };
using Qbox=std::array<Interval,4>;
struct Params {Z hnum,hden; std::vector<Qbox> frames;};
struct Run { unsigned long long nodes=0,leaves=0;int depth=0,chart=0;std::array<int,3> steps{},index{}; };
Z down(Z n){return n>=0?n/unit:-((unit-1-n)/unit);}
Interval product(Interval x,Interval y){
    std::array<Z,4> z{x.lo*y.lo,x.lo*y.hi,x.hi*y.lo,x.hi*y.hi};
    return {*std::min_element(z.begin(),z.end()),*std::max_element(z.begin(),z.end())};
}
Interval square_range(Interval x){
    Z a=x.lo*x.lo,b=x.hi*x.hi;
    return {x.lo<=0&&x.hi>=0?0:std::min(a,b),std::max(a,b)};
}
bool possible(const Qbox& g,const Params& p){
    std::array<Interval,4> s;
    for(int i=0;i<4;i++)s[i]=square_range(g[i]);
    const Z h=p.hnum,d=p.hden;
    if(Wide(d-h)*(s[1].hi+s[2].hi)<Wide(h)*(s[0].lo+s[3].lo))return false;
    return Wide(d)*s[1].hi*s[2].hi>=Wide(h)*(s[0].lo+s[1].hi)*(s[2].hi+s[3].lo);
}
Qbox relative(const Qbox& h,const Qbox& g){
    // 1-based signed indices of the quaternion components of the center.
    constexpr int matrix[4][4]={{1,2,3,4},{-2,1,4,-3},{-3,-4,1,2},{-4,3,-2,1}};
    Qbox out;
    for(int i=0;i<4;i++){
        Z lo=0,hi=0;
        for(int j=0;j<4;j++){
            int s=matrix[i][j];
            Interval xy=product(h[std::abs(s)-1],g[j]);
            lo+=s>0?xy.lo:-xy.hi;
            hi+=s>0?xy.hi:-xy.lo;
        }
        out[i]={down(lo),-down(-hi)};
    }
    return out;
}
Qbox rotation_box(const Run& r){
    int axis=r.chart/8,j=0;Qbox box;
    for(int i=0;i<4;i++){
        if(i==axis){box[i]={unit,unit};continue;}
        Z a=(unit>>r.steps[j])*r.index[j],b=a+(unit>>r.steps[j]);
        box[i]=(r.chart&(1<<(2-j)))?Interval{a,b}:Interval{-b,-a};
        j++;
    }
    return box;
}
bool search(const Poly& marker,const Params& pp,const std::vector<int>& cells,int depth,Run& r){
    ++r.nodes;r.depth=std::max(r.depth,depth);
    if(strictly_positive(marker)){++r.leaves;return true;}
    Qbox g=rotation_box(r);
    if(!possible(g,pp)){++r.leaves;return true;}
    std::vector<int> keep;keep.reserve(cells.size());
    for(int s:cells)if(possible(relative(pp.frames[s],g),pp)) keep.push_back(s);
    if(keep.empty()){++r.leaves;return true;}
    if(depth==60){
        std::cerr<<"Unresolved chart "<<r.chart<<" unit "<<unit<<" quaternion box";
        for(auto v:g) std::cerr<<" ["<<v.lo<<","<<v.hi<<"]";
        std::cerr<<" parameter cell "<<keep.front()<<"\n";
        return false;
    }
    int ax=depth%3,prev=r.index[ax];Poly lo,hi;divide(marker,ax,lo,hi);
    r.steps[ax]++;
    for(int bit=0;bit<=1;bit++){
        r.index[ax]=2*prev+bit;
        if(!search(bit?hi:lo,pp,keep,depth+1,r))return false;
    }
    r.steps[ax]--;r.index[ax]=prev;
    return true;
}
int main(int argc,char** argv){
    if(argc!=3)return 3;
    std::uint16_t test=1;
    if(*reinterpret_cast<unsigned char*>(&test)!=1)return 3;
    std::ifstream marks(argv[1],std::ios::binary),in(argv[2]);Params p;int count;
    if(!(in>>count>>p.hnum>>p.hden)||count<1||count>4000||p.hnum<=0||p.hnum>=p.hden||p.hden>1000000)return 3;
    p.frames.resize(count);
    for(auto& b:p.frames) for(auto& a:b){
        if(!(in>>a.lo>>a.hi)||a.lo<0||a.hi<a.lo||a.hi>unit+1)return 3;
    }
    std::vector<int> ids(count);std::iota(ids.begin(),ids.end(),0);
    Run r;
    for(int c=0;c<32;c++){
        Poly q;marks.read(reinterpret_cast<char*>(&q.d),4);
        if(!marks||q.d<1||q.d>40)return 3;
        int n=q.d+1;q.a.resize(n*n*n);
        marks.read(reinterpret_cast<char*>(q.a.data()),q.a.size()*8);
        if(!marks||!std::all_of(q.a.begin(),q.a.end(),[](Z z){return z>=-(1LL<<52)&&z<=(1LL<<52);}))return 3;
        r.chart=c;if(!search(q,p,ids,0,r))return 2;
    }
    if(marks.peek()!=std::char_traits<char>::eof())return 3;
    std::cout<<"Exact parameter-region cover: "<<count<<" parameter cells, "<<r.nodes<<" nodes, "<<r.leaves<<" terminal boxes, depth "<<r.depth<<"\n";
}

