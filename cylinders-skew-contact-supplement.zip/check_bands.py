"""Exact upper bounds on the number of pairs inside each rotation box."""
from fractions import Fraction as F
from math import comb,lcm
from pathlib import Path
from itertools import product
import argparse,json
from bernstein_homogeneous import original,cube,halve
from bernstein_power import build_gap,cube_bernstein,cover


def positive(data,shape,limit=55):
    leaves=depth_max=0
    corners=[(i*shape[1]+j)*shape[2]+k for i,j,k in product(*[(0,d-1) for d in shape])]
    stack=[(data,"")]
    while stack:
        row,path=stack.pop()
        if min(row)>0:
            leaves+=1;depth_max=max(depth_max,len(path));continue
        if min(row[i] for i in corners)<=0 or len(path)>=limit:
            raise ValueError("bound fails/inconclusive in box "+path)
        lo,hi=halve(row,shape,len(path)%3)
        stack.extend(((hi,path+"1"),(lo,path+"0")))
    return leaves,depth_max


def crop(raw,L,box):
    n=L+1
    for stride,pair in zip((n*n,n,1),box):
        lo,hi=map(F,pair)
        if not 0<=lo<hi<=1: raise ValueError("bad box")
        D=lcm(lo.denominator,hi.denominator);a=int(D*lo);b=int(D*hi)
        rows=[]
        for j in range(n):
            rows.append([sum(comb(i,k)*comb(L-i,j-k)*b**k*a**(i-k)*(D-b)**(j-k)*(D-a)**(L-i-j+k)
                         for k in range(max(0,j+i-L),min(i,j)+1)) for i in range(n)])
        old=raw;raw=[0]*len(old)
        for group in range(0,len(old),stride*n):
            for off in range(stride):
                pos=group+off;line=old[pos:pos+n*stride:stride]
                for j,r in enumerate(rows):raw[pos+j*stride]=sum(u*v for u,v in zip(r,line))
    return raw,(n,n,n)


def upper(raw,S,L,M):
    constant=[comb(L,i)*comb(L,j)*comb(L,k) for i,j,k in product(range(L+1),repeat=3)]
    return [M.denominator*r+(M.denominator+M.numerator)*S*c for r,c in zip(raw,constant)]


def global_second(doc):
    L=doc["degree"];M=F(doc["pair_upper"]);h=F(doc["h"])
    raw,S=build_gap(doc["terms"],L,2)
    raw={k:v*M.denominator for k,v in raw.items()}
    for t in range(L+1):
        k=(t,0,0)
        raw[k]=raw.get(k,0)+(M.denominator+M.numerator)*S*comb(L,t)
    return cover(*cube_bernstein(raw,L,h),limit=55)


def one(doc,band=True):
    L=doc["degree"];M=F(doc["pair_upper"]);h=F(doc["h"])
    if not 0<h<1 or not (2-4*h>0 and (2-4*h)**2>2):raise ValueError("pair bound excludes target")
    raw,S=original(doc,2)
    a=positive(*cube(upper(raw,S,L,M),L,h))
    b=global_second(doc)
    print("Global bound",M,"homogeneous (leaves, depth)",a,"power (nodes, leaves, depth)",b,flush=True)
    if not band:return
    # Check that the kernel value is unchanged by reversing either unoriented line.
    n=L+1
    for t,y,z in product(range(n),repeat=3):
        if raw[(t*n+y)*n+z]!=raw[((L-t)*n+z)*n+y]:
            raise ValueError("orientation symmetry failed")
    E=F(doc["local_upper"]);k=doc["count"]
    K=positive(*crop(upper(raw,S,L,E),L,doc["box"]))
    bound=9+2*(36-k)*M+2*k*E
    if not 1<=k<=36 or bound>=0:raise ValueError("no contradiction")
    # For contacts, yz=h_actual, throughout the advertised t,y rectangle.
    ylo,yhi=map(F,doc["box"][1]);zlo,zhi=map(F,doc["box"][2])
    low=2-4*yhi*zlo;hi=2-4*ylo*zhi
    if not (low>0 and low*low>=2 and (hi<=0 or hi*hi<=2)):
        raise ValueError("missing contact parameters")
    print("Marked bound",E,"box",doc["box"],"leaves/depth",K,"energy",bound,"max pairs",k-1,flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("file",nargs="?",default="bands.json");a=p.parse_args()
    d=json.loads(Path(a.file).read_text())
    if isinstance(d,list):
        for item in d:one(item)
    else:one(d,False)

