"""Build exact chart tensors and outward quaternion interval boxes."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
from struct import pack
from pathlib import Path
import json
from moments import marker,chart
UNIT=1<<20


def tensors(doc,path):
    cut=F(doc["local_lower"]);m=F(doc["pair_upper"])
    gap,S,C,D=marker(doc,cut)
    if cut<=0 or cut*cut<=C/S*(1+6*m)/7:
        raise ValueError("marked squared-norm inequality inconclusive")
    degree=2*doc["degree"]
    with path.open("wb") as stream:
        for k in range(4):
            for signs in product((-1,1),repeat=3):
                row=chart(gap,degree,k,signs)
                n=max(abs(v) for v in row)
                lower=[v*(1<<51)//n for v in row]
                stream.write(pack("<i",degree))
                stream.write(pack("<"+"q"*len(lower),*lower))
    return S,C


def sqrt_floor(v):
    if v<0:raise ValueError("negative squared interval")
    return isqrt(v.numerator*(UNIT*UNIT)//v.denominator)


def rectangles(region,h,path):
    (tl,th),(yl,yh)=([F(x) for x in w] for w in region["box"])
    nt,ny=region["split"];h=F(h)
    hlo=F(1464466094,10**10);hhi=F(1464466095,10**10)
    if not (0<h<=hlo<hhi<yl<yh<=1 and 0<tl<th<1 and (2-4*hlo)**2>2 and (2-4*hhi)**2<2):
        raise ValueError("invalid rational enclosure of the marked contact")
    if type(nt)!=int or type(ny)!=int or nt<1 or ny<1:raise ValueError("invalid grid")
    out=[f"{nt*ny} {h.numerator} {h.denominator}"]
    for i,j in product(range(nt),range(ny)):
        ta=tl+(th-tl)*i/nt;tb=tl+(th-tl)*(i+1)/nt
        ya=yl+(yh-yl)*j/ny;yb=yl+(yh-yl)*(j+1)/ny
        za=hlo/yb;zb=hhi/ya
        pairs=((ta*(1-yb),tb*(1-ya)),(ta*ya,tb*yb),((1-tb)*za,(1-ta)*zb),
               ((1-tb)*(1-zb),(1-ta)*(1-za)))
        out.append(" ".join(str(w) for x,y in pairs for w in (sqrt_floor(x),sqrt_floor(y)+1)))
    path.write_text("\n".join(out)+"\n")

