#!/usr/bin/env python3
"""Replay every certificate. Requires Python 3.9+ and GCC or Clang for C++17."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from check_bands import one
from check_identity import verify
from check_obstruction import check
from geometry import run as geometry
from moments import write_charts
from region import tensors,rectangles

ROOT=Path(__file__).resolve().parent


def data(name):
    return json.loads((ROOT/name).read_text())


def compile_check(name,work,compiler):
    out=work/name
    subprocess.run([compiler,"-O3","-std=c++17",str(ROOT/(name+".cpp")),"-o",str(out)],check=True)
    return out


def main():
    if not __debug__:raise RuntimeError("use Python without -O so all exact checks run")
    cc=shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
    if cc is None: raise RuntimeError("GCC or Clang C++ compiler required")
    primary=data("marked-edge.json");central=data("central-edge.json")
    if primary["terms"]==central["terms"]:raise ValueError("unexpected duplicate mark")
    if [t["c"] for t in primary["terms"]]!=[t["c"] for t in central["terms"]]:
        raise ValueError("the central cross-check uses a different global kernel")
    for doc in (primary,central):
        verify(doc)
    one(primary,False)
    with TemporaryDirectory() as folder:
        wk=Path(folder);f=wk/"mark.bin";r=wk/"parameter-cells.txt"
        executable=compile_check("check_region",wk,cc)
        S,C=tensors(primary,f);rectangles(primary["region"],primary["h"],r)
        print("Marked norm C/S =",C/S,"S =",S,flush=True)
        subprocess.run([str(executable),str(f),str(r)],check=True)
        executable=compile_check("check_charts",wk,cc)
        with f.open("wb") as out:write_charts(central,out)
        with f.open("rb") as inp:subprocess.run([str(executable)],stdin=inp,check=True)
    for band in data("bands.json"):
        one(band)
    check(primary,data("moment-obstruction.json"))
    geometry(primary)
    print("PASS: all finite and algebraic checks")


if __name__=="__main__":
    main()

