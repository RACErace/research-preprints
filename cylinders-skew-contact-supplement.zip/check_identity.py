"""Independent comparison on a unisolvent integer simplex.

Directly substitutes two linear polynomials in each symmetric tensor; this
path does not use the angular or quaternion binomial expansion for evaluation.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import argparse,json
from moments import marker


def times_poly(r,i,a,b,c,d):
    # Multiply sum_j (r_j + i i_j) Y^j by (a+ib) + (c+id)Y.
    n=len(r);re=[0]*(n+1);im=[0]*(n+1)
    for j in range(n):
        x=r[j];y=i[j]
        re[j]+=x*a-y*b;im[j]+=x*b+y*a
        re[j+1]+=x*c-y*d;im[j+1]+=x*d+y*c
    return re,im


def direct(doc,x,y,z,den):
    # At q=(1,x,y,z), the linear forms are P=a-conj(b)Y, Q=b+conj(a)Y.
    norm=1+x*x+y*y+z*z;L=doc["degree"];val=0
    for term in doc["terms"]:
        ell=term["ell"];n=2*ell;c=term["c"]
        re=[c[0]];im=[0];qr=[1];qi=[0]
        for j in range(1,n+1):
            re,im=times_poly(re,im,1,x,-y,z)
            qr,qi=times_poly(qr,qi,y,z,1,-x)
            v=comb(n,j)*c[j]
            if v:
                re=[u+v*w for u,w in zip(re,qr)]
                im=[u+v*w for u,w in zip(im,qi)]
        ans=sum((rr*aa+ii*bb)*(den//comb(n,j)) for j,(rr,ii,aa,bb)
                in enumerate(zip(re,im,term["re"],term["im"])))
        val+=ans*norm**(L-ell)
    return val


def verify(doc):
    level=F(doc["local_lower"]);raw,S,C,den=marker(doc,level)
    L=doc["degree"];D=2*L;weights=[(key[1:],val) for key,val in raw.items()]
    count=0
    for x in range(D+1):
        px=[x**i for i in range(D+1)]
        for y in range(D+1-x):
            py=[y**i for i in range(D+1)]
            for z in range(D+1-x-y):
                pz=[z**i for i in range(D+1)]
                actual=sum(val*px[a]*py[b]*pz[c] for (a,b,c),val in weights)
                expected=level.denominator*direct(doc,x,y,z,den)-level.numerator*S*den*(1+x*x+y*y+z*z)**L
                if actual!=expected:raise ValueError(f"polynomial identity failed at {(x,y,z)}")
                count+=1
    if count!=comb(D+3,3):raise ValueError("invalid interpolation set")
    print("Direct Gaussian-integer tensor substitution agrees at all",count,"unisolvent points")


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("file",type=Path);a=p.parse_args()
    verify(json.loads(a.file.read_text()))

