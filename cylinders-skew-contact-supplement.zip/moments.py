"""Integer homogeneous quaternion polynomials for a marked-edge certificate."""
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import comb, lcm
from operator import add
from struct import pack, unpack
from pathlib import Path
import sys

ZERO=(0,0,0,0)
ONE={ZERO:1}
X=tuple({tuple(int(i==j) for j in range(4)):1} for i in range(4))


def sm(*parts):
    out=defaultdict(int)
    for a,p in parts:
        for k,c in p.items(): out[k]+=a*c
    return {k:c for k,c in out.items() if c}


def mul(p,q):
    out=defaultdict(int)
    for e,c in p.items():
        for f,d in q.items():
            k=(e[0]+f[0],e[1]+f[1],e[2]+f[2],e[3]+f[3])
            out[k]+=c*d
    return dict(out)


def square(p):
    return mul(p,p)


R2=sm(*[(1,square(v)) for v in X])


@lru_cache(None)
def radius_power(n):
    if n==0:return ONE
    return mul(radius_power(n-1),R2)


@lru_cache(None)
def complex_expansion(plus,minus):
    # i^j times the returned integer coefficient on x^(plus+minus-j) y^j.
    return [sum(comb(plus,k)*comb(minus,j-k)*(-1)**(j-k)
                for k in range(max(0,j-minus),min(j,plus)+1))
            for j in range(plus+minus+1)]


def marker(doc,level):
    L=doc["degree"]
    den=lcm(*(comb(2*term["ell"],i) for term in doc["terms"] for i in range(2*term["ell"]+1)))
    out={};S=0;cost=F(0)
    for term in doc["terms"]:
        ell=term["ell"];n=2*ell;c=term["c"]
        A=term["re"];B=term["im"]
        if n+1!=len(c) or len(A)!=n+1 or len(B)!=n+1 or any(type(z)!=int for ar in (c,A,B) for z in ar):
            raise ValueError("invalid integer feature vector")
        # Ensures the unaveraged real coefficient is the sign-averaged F.
        if any(c[i]!=(-1)**ell*c[n-i] for i in range(n+1)) or len({i%2 for i in range(n+1) if c[i]})!=1:
            raise ValueError("vector does not transform by characters under quaternion conjugations")
        S+=sum(comb(n,i)*v*v for i,v in enumerate(c))
        p=defaultdict(int)
        for i in range(n+1):
            h=comb(n,i)
            cost+=F(A[i]*A[i]+B[i]*B[i],h)
            phases=(A[i],B[i],-A[i],-B[i])
            for j,z in enumerate(c):
                if not z:continue
                for k in range(max(0,i-j),min(i,n-j)+1):
                    ap=n-j-k;am=i-k;bp=j-i+k;bm=k
                    v=den//h*comb(n,j)*z*comb(n-j,k)*comb(j,i-k)*(-1)**k
                    for r,x in enumerate(complex_expansion(ap,am)):
                        for s,y in enumerate(complex_expansion(bp,bm)):
                            if x and y:
                                p[ap+am-r,r,bp+bm-s,s]+=v*x*y*phases[(r+s)%4]
        out=sm((1,out),(1,mul(p,radius_power(L-ell))))
    gap=sm((level.denominator,out),(-level.numerator*S*den,radius_power(L)))
    return gap,S,cost,den


def constraints(center,h,eta):
    a,b,c,d=center
    r=[sm(*zip(row,X)) for row in ((a,b,c,d),(-b,a,d,-c),(-c,-d,a,b),(-d,c,-b,a))]
    s0,s1,s2,s3=map(square,r)
    t=sm((1,s0),(1,s1));u=sm((1,s2),(1,s3));n=sm((1,t),(1,u))
    base=sm((1,mul(s1,s2)),(-h,mul(t,u)))
    n2=square(n)
    constraints=[sm((1,base),((1-h)*eta,n2)),sm((1,s1),(1,s2),(2*eta-h,n))]
    if eta:
        # At unit norm, |grad G| <= 2(1-h)*min(sqrt(t),sqrt(u)).
        # Along a displacement of chord <= eta each block norm grows by <= eta.
        for scale in (F(1,2),F(1,8),F(1,32)):
            for block in (t,u):
                constraints.append(sm((1,base),((1-h)*eta*(scale+2*eta),n2),
                                      ((1-h)*eta/scale,mul(n,block))))
    return [clear(p) for p in constraints]


def clear(p):
    den=lcm(*(F(v).denominator for v in p.values()))
    return {k:int(v*den) for k,v in p.items()}


def chart(p,degree,axis,signs):
    # The largest quaternion component is 1. The other three are signed [0,1].
    ds=[k for k in range(4) if k!=axis]
    d=degree+1;dat=[0]*(d**3)
    for ex,val in p.items():
        i,j,k=[ex[a] for a in ds]
        sign=signs[0]**i*signs[1]**j*signs[2]**k
        dat[(i*d+j)*d+k]+=val*sign
    common=lcm(*(comb(degree,k) for k in range(d)))
    rows=[[comb(i,k)*(common//comb(degree,k)) for k in range(i+1)] for i in range(d)]
    for stride in (1,d,d*d):
        for start in range(0,d**3,stride*d):
            for off in range(stride):
                pos=start+off
                line=dat[pos:pos+stride*d:stride]
                for i,row in enumerate(rows):
                    dat[pos+i*stride]=sum(a*b for a,b in zip(row,line))
    return dat


def frames(doc):
    bound=F(doc["local_lower"]);h=F(doc["h"])
    gap,S,cost,D=marker(doc,bound)
    M=F(doc["pair_upper"])
    if not (0<h<1 and 2-4*h>0 and (2-4*h)**2>2 and bound>0 and M<0):
        raise ValueError("invalid separation relaxation")
    if not bound**2 > cost/S*(1+6*M)/7:
        raise ValueError("no marked norm contradiction")
    conds=constraints((1,0,0,0),h,F(0))+constraints(doc["center"],h,F(doc["eta"]))
    return [(2*doc["degree"],gap,1)]+[(d,c,-1) for d,c in zip((4,2,4,2,4,4,4,4,4,4),conds)],S,cost


def write_charts(doc,stream):
    polys,S,cost=frames(doc)
    for axis in range(4):
        for signs in product((-1,1),repeat=3):
            for degree,p,sgn in polys:
                dat=chart(p,degree,axis,signs)
                # Lower Bernstein bounds for the gap and for negated domain constraints.
                scale=max(abs(z) for z in dat)
                if not scale: raise ValueError("identically zero polynomial")
                vals=[(sgn*z*(1<<51))//scale for z in dat]
                stream.write(pack("<i",degree))
                stream.write(pack("<"+"q"*len(vals),*vals))

