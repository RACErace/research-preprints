// Exact conditional sign check on three-dimensional Bernstein tensors.
// Compile with c++ -O3 -std=c++17. Input uses little-endian signed integers.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <limits>
#include "subdivide.hpp"
constexpr int count = 11;
using Box = std::array<Poly,count>;
struct State {
    unsigned long long nodes=0, leaves=0;
    int deepest=0, limit=52, chart=0;
    std::array<int,3> steps{}, index{};
};
bool verify(const Box& root,int depth,State& s) {
    ++s.nodes; s.deepest=std::max(s.deepest,depth);
    for (int idx: {1,3,2,4,5,6,7,8,9,10,0})if(strictly_positive(root[idx])) {++s.leaves;return true;}
    if(depth==s.limit) {
        std::cerr<<"Unresolved chart "<<s.chart<<" depth "<<depth<<" indices";
        for(int i=0;i<3;i++)std::cerr<<" "<<s.index[i]<<"/"<<(1LL<<s.steps[i]);
        std::cerr<<"\n";return false;
    }
    int axis=depth%3;
    Box children[2];
    for(int i=0;i<count;i++)divide(root[i],axis,children[0][i],children[1][i]);
    int saved=s.index[axis];
    s.steps[axis]++;
    for(int dir=0;dir<2;dir++) {
        s.index[axis]=2*saved+dir;
        if(!verify(children[dir],depth+1,s))return false;
    }
    s.steps[axis]--;s.index[axis]=saved;
    return true;
}
int main(int argc,char** argv){
    static_assert(sizeof(int)==4 && sizeof(Z)==8);
    const std::uint16_t check=1;
    if (*reinterpret_cast<const unsigned char*>(&check)!=1) return 3;
    int only=argc>1?std::atoi(argv[1]):-1;
    State s;
    if(argc>2)s.limit=std::atoi(argv[2]);
    if(s.limit<1 || s.limit>60 || only < -1 || only>31) return 3;
    for(int i=0;i<32;i++){
        Box box;
        for(auto& p:box){
            std::cin.read(reinterpret_cast<char*>(&p.d),4);
            if(!std::cin || p.d<1 || p.d>40)return 3;
            const int n=p.d+1;
            p.a.resize(n*n*n);
            std::cin.read(reinterpret_cast<char*>(p.a.data()),std::streamsize(p.a.size()*8));
            if(!std::cin || !std::all_of(p.a.begin(),p.a.end(),[](Z z){return z>=-(1LL<<52)&&z<=(1LL<<52);})) return 3;
        }
        if(only>=0&&only!=i)continue;
        s.chart=i;
        if(!verify(box,0,s))return 2;
    }
    if(std::cin.peek()!=std::char_traits<char>::eof())return 3;
    std::cout<<"Exact conditional cover: "<<s.nodes<<" nodes, "<<s.leaves<<" terminal boxes, depth "<<s.deepest<<"\n";
}

