#pragma once
#include <algorithm>
#include <cstdint>
#include <vector>
using Z = std::int64_t;
struct Poly { int d; std::vector<Z> a; };
Z floor_half(Z q) {
    return q>=0 ? q/2 : -((1-q)/2);
}
void divide(const Poly& p, int axis, Poly& lo, Poly& hi) {
    lo.d=hi.d=p.d;
    const int n=p.d+1, stride=(axis==0?n*n:(axis==1?n:1));
    lo.a.resize(p.a.size()); hi.a.resize(p.a.size());
    for(int group=0;group<int(p.a.size());group+=n*stride) {
        for (int offset=0;offset<stride;offset++) {
            const int pos=group+offset;
            Z line[42];
            for(int j=0;j<n;j++)line[j]=p.a[pos+j*stride];
            for(int k=0;k<n;k++){
                lo.a[pos+k*stride]=line[0];
                hi.a[pos+(n-1-k)*stride]=line[n-1-k];
                for(int j=0;j<n-1-k;j++)line[j]=floor_half(line[j]+line[j+1]);
            }
        }
    }
}
bool strictly_positive(const Poly& p) {
    return std::all_of(p.a.begin(),p.a.end(),[](Z z){return z>0;});
}
