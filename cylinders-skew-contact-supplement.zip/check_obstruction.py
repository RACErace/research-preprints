"""Exact first-moment obstruction for the same kernel on an orthogonal contact edge."""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json,argparse
from check_identity import times_poly


def features(q,n,c):
    a,b,g,d=q
    re=[c[0]];im=[0];u=[1];v=[0]
    for j in range(1,n+1):
        re,im=times_poly(re,im,a,b,-g,d)
        u,v=times_poly(u,v,g,d,a,-b)
        z=comb(n,j)*c[j]
        if z:
            re=[x+z*y for x,y in zip(re,u)]
            im=[x+z*y for x,y in zip(im,v)]
    return re,im


def intervals():
    scale=10**9
    h0=F(1464466094,10**10);h1=F(1464466095,10**10)
    s,t=382683432,923879532
    if not ((2-4*h0)**2>2>(2-4*h1)**2 and (F(s,scale))**2<h0<h1<F(s+1,scale)**2
            and F(t,scale)**2<1-h1<1-h0<F(t+1,scale)**2):
        raise ValueError("bad trigonometric enclosure")
    return ((0,0),(scale,scale),(s,s+1),(t,t+1)),h1


def check_point(q):
    h,h1=intervals()
    matrix=((1,2,3,4),(-2,1,4,-3),(-3,-4,1,2),(-4,3,-2,1))
    ranges=[]
    for row in matrix:
        lo=hi=0
        for x,k in zip(q,row):
            z=x if k>0 else -x
            v,w=h[abs(k)-1];w0=z*v;w1=z*w
            lo+=min(w0,w1);hi+=max(w0,w1)
        ranges.append((lo,hi))
    for rr in ([(z,z) for z in q],ranges):
        s=[(0 if a<=0<=b else min(a*a,b*b),max(a*a,b*b)) for a,b in rr]
        lower=s[1][0]*s[2][0];upper=(s[0][1]+s[1][1])*(s[2][1]+s[3][1])
        if lower<=h1*upper:raise ValueError("atom not strictly skew and separated from both ends")


def check(kernel,atoms):
    qs=atoms["quaternions"];w=atoms["weights"];W=sum(w);scale=4096
    if len(qs)!=len(w) or any(type(z)!=int or z<=0 for z in w):raise ValueError("bad probability weights")
    for q in qs:
        if len(q)!=4 or any(type(z)!=int for z in q):raise ValueError("bad quaternion")
        check_point(q)
    witness=atoms["kernel_witness"]
    if witness!=[0,1,1,0]:raise ValueError("unrecognized far-pair witness")
    # Its pair distance is exactly 2 (t=1/2, y=z=1).
    energy=F(0);S=0;test=F(0)
    for term in kernel["terms"]:
        ell=term["ell"];n=2*ell;c=term["c"]
        S+=sum(comb(n,i)*z*z for i,z in enumerate(c))
        aa,bb=features(witness,n,c)
        test+=F(sum(x*z for x,z in zip(aa,c)),2**ell)
        lows=[[0]*(n+1) for j in range(2)]
        for q,weight in zip(qs,w):
            norm=sum(z*z for z in q);div=W*norm**ell
            for dest,vals in zip(lows,features(q,n,c)):
                for i,z in enumerate(vals):dest[i]+=z*weight*scale//div
        for i in range(n+1):
            energy+=F(sum(max(abs(arr[i]),abs(arr[i]+len(qs)))**2 for arr in lows),scale**2*comb(n,i))
    bound=energy/S;f=test/S
    if not f>F(-121,1000) or not bound<F(39,1000)<(1+6*f)/7:
        raise ValueError("this fractional measure does not obstruct the marker test")
    print("Orthogonal contact:",len(qs),"positive rational atoms, individually strictly compatible")
    print("Squared mean norm / S <",F(39,1000),"and F(far pair)/S >",F(-121,1000))
    print("PASS: no auxiliary vector of this fixed kernel separates its full marked domain by Cauchy-Schwarz")


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("kernel",type=Path);p.add_argument("atoms",type=Path);a=p.parse_args()
    check(json.loads(a.kernel.read_text()),json.loads(a.atoms.read_text()))

