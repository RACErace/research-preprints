# Gilbert–Steiner branching degrees: reproducibility materials

The PDF contains an analytic proof. CHECKS.md records the scope and a second derivation of the probabilistic estimate. No simulation or unpublished inputs are required.

Compile the editable source with Typst 0.15.2:

    typst compile main.typ gilbert-steiner-degrees.pdf

Or install the Python package typst==0.15.2 and run python build.py. The source uses Libertinus Serif.
