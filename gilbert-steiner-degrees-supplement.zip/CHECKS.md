# Verification notes

The proof is analytic; randomization proves the existence of a deterministic configuration and does not insert any numerical tolerance. Variables: fixed p in (1/2,1), q=2p-1, n=2N sinks, D=d-1.

## Independent check of the random-vector estimate

Use a 1/2-net of the unit sphere in R^D with at most 5^D points (by a disjoint-ball volume packing). For a fixed subset of m sinks, cancel opposite pairs. The sum U then uses at most m independent sign vectors, hence its projection on any unit vector z has moment generating function at most exp(m t²/(2D)). If |U| > R, some net direction has projection > R/2. Thus the probability of |U|² > c m^(1+q) is at most exp(D log 5 - D c m^q/8). Taking a sufficiently large fixed M makes this at most exp(-D c m^q/16) for m >= M. The union bound over subsets gives the claimed order with a larger constant K_q. This independently gives the large-subset estimate without the paper's Gaussian integral.

The slack for a subset or its complement is bounded separately: for s=m<=n/2, it is at least (1-2^(q-1))m^(1+q); for s=n-m, convexity gives at least (1-q)n^q m/4. The zero and full subsets follow from balance. Singleton norms are exactly one. The finitely many small sizes use pairwise coherence, whose failure probability is at most N(N-1)exp(-D delta²/2).

## Independent check of the upper estimates

One may replace Gaussian expectation in the comparable-mass bound by averaging |projection| over the unit sphere: its mean for a fixed unit vector is of order d^(-1/2). Each direction yields a partition into two signs; apply the subset norm inequality to both pieces. For the separated-bin estimate, if G is the Gram matrix of J representatives, then rank(G)<=d and ||G||_F²>=J²/d. The entrywise inequality for off-diagonal t in [-1,eta] is t² <= eta-(1-eta)t. Use sum_{i,j} G_ij >= 0 with eta=1/(2d); then ||G||_F² <= 2(1-eta)J+eta J². These estimates need neither equality of masses across bins nor any restriction on mass dynamic range.

## Literature and scope

- [Original public question](https://arxiv.org/html/2611.03403v1#S1): fixed p>1/2 and large d, not the separate bound uniform in p.
- [Cherkashin](https://arxiv.org/html/2507.13532v1): Theorem 2 yields degree d+1; Section 6 discusses a pairwise spherical-code bound. The example of degree 2d there is a terminal degree at p=1/2, not an interior branching point at fixed p>1/2.
- [Volz et al.](https://arxiv.org/html/0909.4270v2): Theorem 1 is the balance and no-splitting criterion, written with exchange of source and sink. Concavity lets a global competitor for a single source be taken cycle-free, so the arborescence criterion applies.
- [Xia](https://arxiv.org/html/2611.13338): Proposition 1.8 counts vertices of degree at least 3 in a cycle-free path for fixed data; it does not give polynomial dependence on ambient dimension for maximum vertex degree.
- The [Lippmann et al.](https://arxiv.org/abs/2210.07702) branching calculation is for the plane; its general-looking title and abstract should not be used as a high-dimensional bound.
- Searches by author, source identifier, latest version, equal masses, superlinear and polynomial branching degrees, and public GitHub repositories found no matching bounds as of 26 November 2026 UTC.
