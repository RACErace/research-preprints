#set document(title: "Polynomial bounds for branching degrees in the Gilbert–Steiner problem")
#set page(paper: "a4", margin: (x:23mm,y:23mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: .58em)
#set heading(numbering: "1.")
#align(center)[
#text(size: 21pt, weight: "semibold")[Polynomial bounds for branching degrees \ in the Gilbert–Steiner problem]
#v(4pt)
#text(size: 9pt, fill: luma(100))[26 November 2026 · Research preprint, version 1.0]
]

*Abstract.* Fix $1/2 < p < 1$ and set $a_p=1/(2-2p)$. We bound the maximum degree of an interior branching point in an optimal Euclidean Gilbert–Steiner flow with cost $m^p$ between $c_p d^(a_p)$ and $C_p d^(a_p+1) log(2d)$. This supplies a superlinear lower bound and a polynomial upper bound for Question 1.2 of \[2\]. The lower bound is achieved by single-source stars with identical sink masses. Within this subclass, the exponent $a_p$ is sharp. The lower bound uses lifted antipodal random sign vectors and estimates all splitting inequalities. The upper bound uses local perturbations, Gaussian projections, and a spherical-code bound for separated mass scales.

*Keywords:* branched optimal transport; Gilbert–Steiner problem; spherical codes.

= Statement and local inequalities
The Gilbert–Steiner functional for a finite flow is the sum of
$lr(|m|)^p$ times Euclidean edge length over its edges, where $m$ is the
signed mass on the edge. A branching point is a vertex outside the
supports of the terminal measures. Write $B_p (d)$ for the supremum of
its degree over all optimal flows and all finite terminal data in
$bb(R)^d$. Write $A_p (d)$ for the corresponding supremum in
single-source stars with equal sink masses, with the central vertex
distinct from the terminals. Earlier work gives a degree-$d + 1$ example
and asks for better asymptotic bounds in large dimension
\[1, Theorem 2 and Section 6\], \[2, Question 1.2\].
The one-source optimality criterion we use is due to Volz et al.
\[3, Theorem 1\].

#block[
#strong[Theorem 1.] #emph[For each fixed $1 \/ 2 < p < 1$, there are
positive constants $c_p , C_p$ such that, for all sufficiently large
$d$,
$ c_p d^(a_p) lt.eq A_p (d) lt.eq C_p d^(a_p) , #h(2em) A_p (d) lt.eq B_p (d) lt.eq C_p d^(a_p + 1) log (2 d) . $
Neither the sharp exponent for general terminal data nor a bound uniform
over $p$ is asserted.]

]
Let $v_i$ be the unit direction of an edge pointing away from an
interior vertex and let $m_i > 0$ be its absolute mass. For any subset
$I$ of edges all carrying mass into the vertex, or all carrying mass out
of it, optimality implies
$ norm(sum_(i in I) m_i^p v_i) lt.eq (sum_(i in I) m_i)^p . #h(1em) "(1)" $
Indeed, detach these edges from the vertex and reattach them at a point
displaced by $t w$, where $w$ is a unit direction. Join the new point to
the old one by the edge carrying the net mass. The right derivative at
$t = 0$ is $(sum_I m_i)^p - chevron.l w , sum_I m_i^p v_i chevron.r$ and
must be nonnegative for each $w$. One may first use generic
displacements and then take limits. If $n$ sink edges have unit mass and
the sole source edge has mass $n$, the criterion of \[3\] says
that (1) on all sink subsets, together with
$sum_(i = 1)^n v_i + n^p v_0 = 0$, is sufficient for global optimality
of the star.

= Superlinear lower bound
Put $q = 2 p - 1 in (0 , 1)$. Let $n = 2 N$ be even, set
$b = n^(q - 1)$, and work in $bb(R)^(D + 1)$ with an axis vector $e_0$
and orthogonal transverse space $bb(R)^D$. Take $N$ independent random
vectors $u_j in bb(R)^D$ with independent entries
$plus.minus 1 \/ sqrt(D)$. Define the sink directions to be the $n$
vectors
$ v_j^plus.minus = sqrt(b) thin e_0 plus.minus sqrt(1 - b) thin u_j #h(2em) (1 lt.eq j lt.eq N) . $
Choose the source direction $- e_0$; all terminals can be chosen at
distance one from zero. The balance identity holds because
$n sqrt(b) = n^p$. With probability tending to one the directions are
distinct, as follows from the coherence bound below.

For a subset of $s$ sinks, let $U$ be the sum of the selected signed
transverse vectors. Its complement has transverse sum $- U$. Write
$m = min (s , n - s)$. The required inequality is
$ b s^2 + (1 - b) norm(U)^2 lt.eq s^(1 + q) . #h(1em) "(2)" $
There are no
restrictions for $s = 0 , n$, and the inequality is exact for singleton
subsets. For $1 lt.eq m lt.eq n \/ 2$, in both cases $s = m , n - m$, we
have
$ s^(1 + q) - b s^2 med gt.eq med c thin m^(1 + q) , #h(2em) c = (1 - q) \/ 4 . #h(1em) "(3)" $
If $s = m$, the ratio on the left to $m^(1 + q)$ is
$1 - (m \/ n)^(1 - q) gt.eq 1 - 2^(q - 1) gt.eq (1 - q) \/ 2$; the last
inequality is concavity of $1 - 2^(- x)$ on $[0 , 1]$. If $s = n - m$,
let $t = s \/ n gt.eq 1 \/ 2$. By convexity
$t^(q - 1) gt.eq 1 + (1 - q) (1 - t)$. Thus the slack is at least
$b s^2 (1 - q) m \/ n$. Using $s^2 \/ n gt.eq n \/ 4$ and
$m^q lt.eq n^q$ gives (3).

Fix an integer $M$ large enough that $c M^q gt.eq 4 log 2$. For
$m gt.eq M$, it suffices to prove
$norm(U)^2 lt.eq c m^(1 + q)$ for every subset of $m$ sinks,
using the complement to cover the larger subsets. For a fixed subset,
opposite transverse pairs cancel. At most $m$ independent signs then
contribute to each coordinate; coordinates are independent. The
inequality $cosh x lt.eq exp (x^2 \/ 2)$ shows
$bb(E) exp (t U_ell) lt.eq exp (t^2 m \/ (2 D))$. If $G$ is a standard
Gaussian independent of $U$, the identity
$bb(E)_G exp (z G) = exp (z^2 \/ 2)$ consequently gives
$ bb(E) exp lr(( (D U_ell^2)/(4 m) ))
 = bb(E)_(U,G) exp lr(( sqrt(D/(2m)) G U_ell ))
 lt.eq bb(E)_G exp(G^2/4) = sqrt(2). $
Taking products over the coordinates and using Markov’s inequality
yields
$ bb(P) lr({ norm(U)^2 > c m^(1 + q) }) lt.eq exp lr(( - D c m^q \/ 8 )) , #h(2em) m gt.eq M . $
Since $x^(q - 1) log (e x)$ has finite supremum for $x gt.eq 2$, there
is a constant $K_q$ such that
$ D gt.eq K_q n^(1 - q) quad arrow.r.double quad D c m^q \/ 8 gt.eq 3 m log (e n \/ m) quad (1 lt.eq m lt.eq n \/ 2) . $
For example one can take
$K_q = (24 \/ c) sup_(x gt.eq 2) x^(q - 1) log (e x)$. The union bound
and $binom(n, m) lt.eq (e n \/ m)^m$ now bound the probability of any
large-subset violation by $sum_(m = M)^(floor(n \/ 2)) (e n \/ m)^(- 2 m)$,
which tends to zero by comparison with a geometric series and termwise
convergence.

For the remaining small subsets, fix $delta in (0 , 1)$ with
$1 + delta (M - 1) < 2^q$. For each $i eq.not j$ the inner product
$chevron.l u_i , u_j chevron.r$ is the mean of $D$ independent signs;
exponential Markov and $cosh x lt.eq exp (x^2 \/ 2)$ give
$bb(P) lr({ lr(|chevron.l u_i , u_j chevron.r|) > delta }) lt.eq 2 exp (- D delta^2 \/ 2)$.
Therefore with probability tending to one all these absolute inner
products are at most $delta$. For $2 lt.eq m < M$, cancellation of
opposite pairs then gives
$norm(U)^2 lt.eq m [1 + delta (M - 1)]$. If $s = m$,
(2) follows for sufficiently large $n$ since
$b M arrow.r 0$ and $s^q gt.eq 2^q$. If $s = n - m$ with
$1 lt.eq m < M$, the convexity estimate for $t$ gives slack at least
$(1 - q) n^q m \/ 4$, which dominates the same transverse bound for
large $n$ (with $norm(U)^2 = 1$ when $m = 1$). Thus with
positive probability all subsets satisfy (2)
and all directions are distinct.

For a given large $d$, take $D = d - 1$ and the largest even $n$ with
$K_q n^(1 - q) lt.eq D$. Since $1 \/ (1 - q) = a_p$, the resulting
degree $n + 1$ proves the lower bound.

#pagebreak()
= Upper bounds for equal and arbitrary masses
#block[
#strong[Lemma 1.] #emph[A block of $k$ same-sign edges with masses in
$\[ L , 2 L \)$ at an interior branching point has
$k lt.eq (2^p sqrt(2 pi) sqrt(d))^(1 \/ (1 - p))$.]

]
#block[
#emph[Proof.] Given $g in bb(R)^d$, divide this block into the edges
with nonnegative projection on $g$ and the others. Apply
(1) to each subset and project to obtain
$ sum_i m_i^p lr(|chevron.l g , v_i chevron.r|) lt.eq 2 (2 L k)^p norm(g) . $
For a standard $d$-dimensional Gaussian $g$, each projection has mean
absolute value $sqrt(2 \/ pi)$, while
$bb(E) norm(g) lt.eq sqrt(d)$. Taking expectations and using
$m_i gt.eq L$ gives the claim. #h(1fr) □

]
For the equal-sink star the lemma applies to all sink edges, and the one
source edge contributes only one more to the degree. To treat arbitrary
masses, divide each sign group into dyadic bins $\[ 2^j , 2^(j + 1) \)$.
We bound the number of occupied bins. For two same-sign edges with mass
ratio $r lt.eq 1$, squaring (1) gives
$ chevron.l v_i , v_j chevron.r lt.eq frac((1 + r)^(2 p) - 1 - r^(2 p), 2 r^p) lt.eq 2 r^(1 - p) , $
where the last bound follows from the mean value theorem on $[1 , 2]$.
Choose $ H = 1 + ceil(frac(log_2 (4 d), 1 - p)) . $ In each residue class of
bins modulo $H$, pick one representative from each occupied bin.
Distinct representatives have mass ratio at most $2^(1 - H)$, hence
inner product at most $eta = 1 \/ (2 d)$.

For any such set of $J$ unit vectors write $t_(i j)$ for their inner
products. Since $f (t) = (t + 1) (t - eta)$ is nonpositive on
$[- 1 , eta]$, $sum_(i , j) f (t_(i j)) lt.eq 2 (1 - eta) J$. The Gram
matrix has rank at most $d$ and trace $J$, so
$sum t_(i j)^2 gt.eq J^2 \/ d$; also $sum t_(i j) gt.eq 0$. Expanding
$f$ therefore gives $sum f (t_(i j)) gt.eq (1 \/ d - eta) J^2$, and
consequently $J lt.eq 4 d$. There are at most $4 d H$ occupied bins for
each sign. Lemma 1 applied to every bin, followed by
addition of the two signs, establishes the asserted
$O_p (d^(a_p + 1) log (2 d))$ bound. In particular, no restriction on
the ratio between the smallest and largest edge masses is used.

#heading(numbering: none, level: 2)[Scope]
For $p = 3 \/ 4$, the equal-sink exponent is $2$, and the general upper
bound has order at most $d^3 log (2 d)$. This result addresses the
fixed-$p$ asymptotic bounds in Question 1.2 of \[2\], not its
separate question about a bound depending only on dimension for all $p$.
The proof is analytic and does not depend on numerical experiments. This
note was developed with AI assistance and has not undergone external
peer review.


#heading(numbering: none)[References]

\[1\] D. Cherkashin, On branching points in the Gilbert–Steiner problem, #link("https://arxiv.org/abs/2507.13532")[arXiv:2507.13532], 2025.

\[2\] Y. Teplitskaya (ed.), Open problems from the Length Optimization event at MDS 2026, #link("https://arxiv.org/abs/2611.03403")[arXiv:2611.03403], 2026.

\[3\] M. G. Volz, M. Brazil, C. J. Ras, K. J. Swanepoel, and D. A. Thomas, The Gilbert arborescence problem, _Networks_ 61 (2013), 238–247. #link("https://arxiv.org/abs/0909.4270")[arXiv:0909.4270].
