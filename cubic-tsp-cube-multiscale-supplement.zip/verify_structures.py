"""Independent finite parts of the common-order obstruction and the nine-label example."""
from itertools import permutations,product
from fractions import Fraction
import spring_base as spring


def require(test):
    if not test:
        raise ValueError("structural witness failed")


def symmetry_obstruction():
    frames=set()
    for p in permutations("ijk"):
        for signs in product((False,True),repeat=3):
            symbols="".join(c.upper() if s else c for c,s in zip(p,signs))
            frames.add(spring.perm(symbols))
    require(len(frames)==48)
    states={(k,f) for k in (0,1) for f in frames}
    word=(0,7,1,2,1,0,0,2)
    trace=[len(states)]
    for symbol in word:
        child_states=set()
        for kind,frame in states:
            for rev in (False,True):
                children=spring.parts((kind,frame,rev))
                selected=[x for pos,x in children if pos==spring.CORNERS[symbol]]
                require(len(selected)==1)
                k,f,_=selected[0]
                child_states.add((k,f))
        states=child_states
        trace.append(len(states))
    require(len(states)==1)
    print("spatial word",word,"ranks",trace,"final oriented spatial state",next(iter(states)))
    t1,t2=Fraction(145,2044),Fraction(183,1022)
    points=((Fraction(1,2),0,Fraction(1,2)),(0,1,0))
    for p,t in zip(points,(t1,t2)):
        slot=int(8*t)
        pos,state=spring.RULES[0][slot]
        local=tuple(2*a-b for a,b in zip(p,pos))
        require(local in spring.CORNERS and 8*t==slot+spring.corner_time(state,local))
    dist2=sum((a-b)**2 for a,b in zip(*points))
    require(dist2**3==spring.D_SQUARED*(t2-t1)**2)
    require(any(st[0]==0 for _,st in spring.RULES[1]))
    print("common sharp prototype interval",t1,t2,"length",t2-t1)


def collinear_nine():
    # 2 denotes the far corner. Remove it temporarily, leaving a path of 8 labels.
    # The position of the other pinned label (0) can be any of the eight.
    max_costs=[]
    for pinned in range(8):
        worst=0
        for bits in product((0,1),repeat=7):
            v=list(bits);v.insert(pinned,0)
            cycle=[2]+v+[2]
            cost=sum(abs(b-a)**3 for a,b in zip(cycle,cycle[1:]))
            worst=max(worst,cost)
        max_costs.append(worst)
    require(max_costs==[22]*8)
    print("collinear fixed-order maxima in (sqrt(3)/2)^3 units",max_costs)


def noncrossing_regression():
    # Exhaust all noncrossing partial matchings of the cyclically ordered original edges.
    def matchings(ids):
        if not ids:
            yield ()
            return
        first=ids[0]
        yield from matchings(ids[1:])
        for j in range(1,len(ids)):
            partner=ids[j]
            for inside in matchings(ids[1:j]):
                for outside in matchings(ids[j+1:]):
                    yield ((first,partner),)+inside+outside

    count=0
    for n in range(4,11):
        for pairs in matchings(tuple(range(n))):
            used={p for pair in pairs for p in pair}
            edges=[(i,(i+1)%n) for i in range(n) if i not in used]
            for a,b in pairs:
                edges.extend(((a,b),((a+1)%n,(b+1)%n)))
            adjacent=[[] for _ in range(n)]
            for a,b in edges:
                adjacent[a].append(b)
                adjacent[b].append(a)
            require(all(len(x)==2 for x in adjacent))
            seen={0}
            queue=[0]
            while queue:
                for j in adjacent[queue.pop()]:
                    if j not in seen:
                        seen.add(j);queue.append(j)
            require(len(seen)==n)
            count+=1
    print("supplemental noncrossing matching checks",count)


if __name__=="__main__":
    symmetry_obstruction()
    collinear_nine()
    noncrossing_regression()
