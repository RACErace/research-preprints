"""Regenerate a probe table from settings alone. All accepting tests use verify_probes.
Usage: python3 -B generate_probes.py settings.json out.json
"""
import json
import sys
from functools import lru_cache
from math import isqrt
from pathlib import Path
import verify_probes as v


class Search:
    def __init__(self, settings):
        self.settings=settings
        self.check=v.Checker(dict(settings,leaves=[]))
        self.hints={}
        self.memo={}

    @lru_cache(None)
    def samples(self,cell):
        # Spatial centers only guide which times to try first.
        cells=v.expand(v.refine(cell))
        S,T=self.check.S,self.check.T
        return tuple((tuple((2*a+1)*(S//8) for a in p),(2*i+1)*(T//128))
                     for i,(p,_) in enumerate(cells))

    def candidates(self,word,depth,i,j):
        c=self.check
        q=len(word)-2*c.radius-1
        scale=8**depth
        unit=c.T//scale
        side=c.S//(2**depth)
        lower=max(c.T//2,(j-i-1)*unit)
        a=v.lower_corner(v.subcell(word[c.radius],i,depth),side)
        b=v.lower_corner(v.subcell(word[c.radius+q],j-q*scale,depth),side)
        result=[]
        for slot in range(-c.radius,1):
            for z,t in self.samples(word[c.radius+slot]):
                w=slot*c.T+t
                if w>=i*unit or 100*((i+1)*unit-w)>c.a*lower:
                    continue
                za=sum((2*x-2*y-side)**2 for x,y in zip(z,a))
                zb=sum((2*x-2*y-side)**2 for x,y in zip(z,b))
                score=isqrt(za**3)+isqrt(zb**3)+2*((i+1)*unit-w)
                result.append((score,w))
        return result

    def choose(self,word,h,i,j):
        c=self.check
        q=len(word)-2*c.radius-1
        size=(q+1)*8**h
        rev=v.normalize(v.reverse(word),c.radius)
        views=((word,i,j),(rev,size-1-j,size-1-i))
        options=sorted((score,d,w) for d,(seq,lo,hi) in enumerate(views)
                       for score,w in self.candidates(seq,h,lo,hi))
        tried=([],[])
        for clearance,cap in ((c.T//14,8),(c.T//48,18),(0,len(options)+1)):
            for _,d,w in options:
                if len(tried[0])+len(tried[1])>=cap:
                    break
                if any(abs(w-x)<=clearance for x in tried[d]):
                    continue
                tried[d].append(w)
                seq,lo,hi=views[d]
                try:
                    c.partner(seq,h,lo,hi,w)
                except ValueError as exc:
                    if str(exc)!="unproved partner inequality":
                        raise
                    continue
                self.memo[(rev,h,size-1-j,size-1-i)]=(1-d,w)
                return d,w
        return None

    def word(self,q,number,seq):
        c=self.check
        stack=[(0,0,seq[c.radius],q,seq[c.radius+q])]
        while stack:
            h,i,x,j,y=stack.pop()
            n=8**h
            if 2*(j+1-i)<n or j-i-1>=4*n:
                continue
            sq=sum((abs(a-b)+1)**2 for a,b in zip(x[0],y[0]))
            if 40000*sq**3<=c.b**2*max(n,2*(j-i-1))**2:
                continue
            if h>=3:
                k=(seq,h,i,j)
                if k not in self.memo:
                    self.memo[k]=self.choose(seq,h,i,j)
                hit=self.memo[k]
                if hit is not None:
                    self.hints[(q,number,h,i,j)]=hit
                    continue
            v.need(h<c.idepth,"generation depth exhausted")
            stack.extend((h+1,8*i+u,a,8*j+l,b)
                         for u,a in enumerate(v.refine(x)) for l,b in enumerate(v.refine(y)))

    def build(self):
        for q in range(5):
            for k,seq in enumerate(v.small_words(q,self.check.radius)):
                self.word(q,k,seq)
        rows=[list(k+value) for k,value in sorted(self.hints.items())]
        return dict(self.settings,leaves=rows)


if __name__=="__main__":
    spec=json.loads(Path(sys.argv[1]).read_text())
    out=Search(spec).build()
    Path(sys.argv[2]).write_text(json.dumps(out,separators=(",",":"))+"\n")
    print("generated probe leaves",len(out["leaves"]))
