#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
scratch=$(mktemp -d)
trap 'rm -r -- "$scratch"' EXIT
sha256sum -c --quiet SHA256SUMS
python3 -B spring_base.py > "$scratch/curve.log"
diff -u curve.log "$scratch/curve.log"
python3 -B verify_probes.py probes.json > "$scratch/probes.log"
diff -u probes.log "$scratch/probes.log"
python3 -B verify_structures.py > "$scratch/structures.log"
diff -u structures.log "$scratch/structures.log"
c++ -O2 -std=c++17 verify_boxes.cpp -o "$scratch/verify_boxes"
for n in 7 8; do
    gzip -dc "prior-small/n$n.boxes.gz" | "$scratch/verify_boxes" > "$scratch/boxes$n.log"
    diff -u "prior-small/boxes$n.log" "$scratch/boxes$n.log"
done
sha256sum -c --quiet NINE-SHA256.txt
xz -dc n9.boxes.xz | "$scratch/verify_boxes" > "$scratch/boxes9.log"
diff -u boxes9.log "$scratch/boxes9.log"
python3 -B prior-small/verify_finite.py > "$scratch/finite.log"
diff -u prior-small/finite.log "$scratch/finite.log"
cat "$scratch/curve.log" "$scratch/probes.log" "$scratch/structures.log" "$scratch/boxes9.log" "$scratch/boxes7.log" "$scratch/boxes8.log" "$scratch/finite.log"
