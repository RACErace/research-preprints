// Cover normalized point configurations by octants, pinned faces, and sub-boxes.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <limits>
#include <sstream>
#include <vector>
using namespace std;
// Positive tokens are one plus a tour index, zero applies the parity corner lemma,
// and negative tokens split a single scalar coordinate at its midpoint.
constexpr int N=9, D=128, U=1<<16, TARGET=4*U;
constexpr int TourCount=20160;
using V=array<int,3>;
using Order=array<int,N>;
struct Box{V l,h;}; using Boxes=array<Box,N>;
using Pattern=array<int,N>;
const array<array<int,6>,8> anchors={{{0,1,0,1,0,1},{0,1,0,1,0,2},{0,1,0,1,2,3},
 {0,1,0,2,0,3},{0,1,0,2,1,2},{0,1,0,2,1,3},{0,1,0,2,3,4},{0,1,2,3,4,5}}};
using Perm=array<int,64>;
vector<Order> tours;
vector<Perm> group;
vector<int> wt;
struct Counters{uint64_t edge=0,cycle=0,local=0,mixed=0,fail=0,split=0;int deepest=0;} count_all;
int depth_limit=38;
vector<int> proof;
int edgepos[N][N];
array<array<unsigned char,N>,TourCount> edgelist;
vector<int> pair_tours[N*N];
uint64_t nodes=0,inherit_hits=0,contract_hits=0,new_tries=0;
const int trials=9;
using Pool=array<int,trials>;
int rawcost(V a,V b){int d=0;for(int i=0;i<3;++i){int g=a[i]-b[i];d+=g*g;}return wt[d];}
void init(){
 for(int s=0;s<=3*D*D;++s){
    using Wide=unsigned __int128;
    Wide den=Wide(8)*D*D*D*D*D*D, num=Wide(U)*U*s*s*s;
    int w=int(sqrtl((long double)num/(long double)den));
    while(Wide(w)*w*den<num)++w;
    while(w>0&&Wide(w-1)*(w-1)*den>=num)--w;
    wt.push_back(w);
 }
 Order t{};for(int i=0;i<N;++i)t[i]=i;
 do{if(t[1]<t[N-1])tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));
 V axis{0,1,2};
 do{for(int flip=0;flip<8;++flip){
    Perm g{};
    for(int i=0;i<64;++i){int val=0;for(int j=0;j<3;++j){
      int s=(i>>(2*axis[j]))&3;
      val|=((flip>>j)&1?3-s:s)<<(2*j);
    }g[i]=val;}group.push_back(g);
 }}while(next_permutation(axis.begin(),axis.end()));
}
Boxes decode(const Pattern& codes){
 Boxes boxes{};
 for(int i=0;i<N;++i)for(int a=0;a<3;++a){
   int e=(codes[i]>>(2*a))&3;
   boxes[i].l[a]=array<int,4>{0,0,D/2,D}[e];
   boxes[i].h[a]=array<int,4>{0,D/2,D,D}[e];
 }
 return boxes;
}
int color(const Box& box){
 int par=0;
 for(int a=0;a<3;++a){
    if(box.h[a]<=D/4)continue;
    if(box.l[a]>=3*D/4)par^=1;
    else return -1;
 }
 return par;
}
struct Node{
 int M[N][N]{}, pt[N]{}, w[N][N][8][8]{};
 V corners[N][8]{};
 int edge_weight[N*N]{};
 Node(const Boxes& boxes){
  for(int i=0;i<N;++i){
   const Box& b=boxes[i];corners[i][0]=b.l;pt[i]=1;
   for(int k=0;k<3;++k)if(b.l[k]!=b.h[k]){
    int pre=pt[i];for(int h=0;h<pre;++h){corners[i][pre+h]=corners[i][h];corners[i][pre+h][k]=b.h[k];}pt[i]*=2;
   }
  }
  for(int i=0;i<N;++i)for(int j=0;j<i;++j){
   int bound=0;
   for(int a=0;a<pt[i];++a)for(int b=0;b<pt[j];++b){
     int c=rawcost(corners[i][a],corners[j][b]);w[i][j][a][b]=w[j][i][b][a]=c;bound=max(bound,c);
   } M[i][j]=M[j][i]=bound; edge_weight[edgepos[i][j]]=bound;
  }

 }
 int score(int k)const{
    const auto& e=edgelist[k];
    return edge_weight[e[0]]+edge_weight[e[1]]+edge_weight[e[2]]+edge_weight[e[3]]+
      edge_weight[e[4]]+edge_weight[e[5]]+edge_weight[e[6]]+edge_weight[e[7]]+edge_weight[e[8]];
 }
 void candidates(Pool& pool, bool merged)const{
    int closest=-1, best=INT32_MAX;
    for(int i=1;i<N;i++)for(int j=0;j<i;j++)if(M[i][j]<best){
       best=M[i][j]; closest=edgepos[i][j];
    }
    pair<int,int> ranked[trials];int used=0;
    auto insert=[&](int k){
      pair<int,int> v{score(k),k};
      if(used==trials && v>=ranked[used-1])return;
      int p=used<trials?used++:used-1;
      while(p>0&&v<ranked[p-1]){ranked[p]=ranked[p-1];--p;}
      ranked[p]=v;
    };
    if(merged){for(int k:pair_tours[closest])insert(k);}
    else {for(int k=0;k<TourCount;k++)insert(k);}
    for(int i=0;i<trials;i++)pool[i]=ranked[i].second;
 }
 int worst(const Order& tour,int stop,int *witness=nullptr){
    int off=0;for(int i=1;i<N;++i)if(pt[tour[i]]<pt[tour[off]])off=i;
    Order t{};for(int i=0;i<N;++i)t[i]=tour[(off+i)%N];
    int best=0;
    for(int a=0;a<pt[t[0]];++a){
        int pre[8],nex[8],arg[N][8]{};
        for(int b=0;b<pt[t[1]];++b)pre[b]=w[t[0]][t[1]][a][b];
        for(int k=2;k<N;++k){
            for(int c=0;c<pt[t[k]];++c){
                int val=-1,idx=0;
                for(int b=0;b<pt[t[k-1]];++b){int x=pre[b]+w[t[k-1]][t[k]][b][c];if(x>val){val=x;idx=b;}}
                nex[c]=val;if(witness)arg[k][c]=idx;
            }
            copy(nex,nex+pt[t[k]],pre);
        }
        for(int b=0;b<pt[t[N-1]];++b){
            int z=pre[b]+w[t[N-1]][t[0]][b][a];
            if(z>best){best=z;if(witness){
                witness[t[0]]=a;int v=b;
                for(int k=N-1;k>=1;--k){witness[t[k]]=v;v=arg[k][v];}
            }}
            if(best>stop)return best;
        }
    }
    return best;
 }
};


void index_tours(){
  int eid=0;for(int i=1;i<N;i++)for(int j=0;j<i;j++)edgepos[i][j]=edgepos[j][i]=eid++;
  for(int k=0;k<TourCount;k++)for(int j=0;j<N;j++){
    int e=edgepos[tours[k][j]][tours[k][(j+1)%N]];
    edgelist[k][j]=e;pair_tours[e].push_back(k);
  }
}
bool leaf(Node& node,const Pool& pool,int& best,int& bestcost){
  for(int k:pool)if(k>=0){
     if(node.score(k)<TARGET){proof.push_back(k+1);++count_all.edge;return true;}
     int w=node.worst(tours[k],TARGET-1);++new_tries;
     if(w<TARGET){proof.push_back(k+1);++count_all.cycle;return true;}
     if(w<bestcost){best=k;bestcost=w;}
  }
  return false;
}
bool solve(const Boxes& b,int depth,const Pool& inherited){
 ++nodes;if(nodes>3500000)throw runtime_error("node budget");
 count_all.deepest=max(count_all.deepest,depth);
 int c=color(b[0]);
 if(c>=0&&all_of(b.begin()+1,b.end(),[c](const Box& a){return color(a)==c;})){
      proof.push_back(0);++count_all.local;return true;
 }
 Node v(b);
 int best=-1,bestcost=INT32_MAX;
 if(leaf(v,inherited,best,bestcost)){++inherit_hits;return true;}
 Pool merged;v.candidates(merged,true);
 if(leaf(v,merged,best,bestcost)){++contract_hits;return true;}
 Pool full;v.candidates(full,false);
 if(leaf(v,full,best,bestcost))return true;
 if(depth>=depth_limit){++count_all.fail;return false;}
 // A worst corner assignment for the best unsuccessful cycle. Estimate
 // the drop in its two incident edge bounds when bisecting one coordinate.
 int witness[N]{};auto& tour=tours[best];v.worst(tour,INT32_MAX,witness);
 int split_i=-1,split_j=-1;long long merit=-1;
 for(int h=0;h<N;h++){
    int i=tour[h],p=tour[(h+N-1)%N],q=tour[(h+1)%N];
    V a=v.corners[i][witness[i]],x=v.corners[p][witness[p]],y=v.corners[q][witness[q]];
    int cost=rawcost(a,x)+rawcost(a,y);
    for(int j=0;j<3;j++){
      int width=b[i].h[j]-b[i].l[j];if(width<2)continue;
      V mid=a;mid[j]=(b[i].l[j]+b[i].h[j])/2;
      int drop=max(0,cost-rawcost(mid,x)-rawcost(mid,y));
      long long value=static_cast<long long>(width)*(3000+drop);
      if(value>merit){merit=value;split_i=i;split_j=j;}
    }
 }
 if(split_i<0){++count_all.fail;return false;}
 int mid=(b[split_i].h[split_j]+b[split_i].l[split_j])/2;
 Boxes left=b,right=b;left[split_i].h[split_j]=right[split_i].l[split_j]=mid;
 Pool child{};child[0]=best;
 for(int i=1;i<trials;i++)child[i]=(i%2==1?full[(i-1)/2]:merged[(i-1)/2]);
 proof.push_back(-1-3*split_i-split_j);++count_all.split;
 return solve(left,depth+1,child)&&solve(right,depth+1,child);
}
uint64_t encode(Pattern p){
 sort(p.begin(),p.end());uint64_t s=0;for(int x:p)s=(s<<6)|x;return s;
}
void roots(ostream& out){
 unordered_set<uint64_t> seen;seen.reserve(5100000);
 uint64_t total=0;
 for(const auto& how:anchors){
   int base[N][3]{};for(int k=0;k<3;k++){base[how[2*k]][k]=-1;base[how[2*k+1]][k]=1;}
   for(int mask=0;mask<1<<(3*N-6);mask++){
     int bit=0;Pattern p{};
     for(int i=0;i<N;i++)for(int a=0;a<3;a++){
        int d=base[i][a];int s=d?(d<0?0:3):1+((mask>>bit++)&1);p[i]|=s<<(2*a);
     }
     sort(p.begin(),p.end());uint64_t key=0;for(int x:p)key=(key<<6)|x;
     if(seen.count(key))continue;
     for(const auto& g:group){Pattern h{};for(int i=0;i<N;i++)h[i]=g[p[i]];seen.insert(encode(h));}
     for(int x:p)out<<x<<' ';out<<'\n';++total;
   }
 }
 cerr<<"root representatives "<<total<<" labelled-box multisets "<<seen.size()<<'\n';
}
int main(int argc,char** argv){
 if(argc<3){cerr<<"Usage: generate9 roots outfile | solve rootfile outfile part parts cap\n";return 2;}
 init();index_tours();
 if(string(argv[1])=="roots"){ofstream out(argv[2]);roots(out);return !out;}
 if(argc!=7)return 2;
 ifstream in(argv[2]);ofstream out(argv[3]);if(!in||!out)return 2;
 int start=stoi(argv[4]),mod=stoi(argv[5]),cap=stoi(argv[6]);int nr=0,index=-1;
 Pool none;none.fill(-1);string line;
 while(getline(in,line)){
    ++index;if(index%mod!=start)continue;
    Pattern p{};istringstream s(line);for(int& x:p)if(!(s>>x))return 2;
    proof.clear();
    if(!solve(decode(p),0,none)){cerr<<"unresolved root "<<index<<" depth "<<count_all.deepest<<'\n';return 1;}
    out<<line;for(int tok:proof)out<<tok<<' ';out<<'\n';++nr;
    if(nr%2000==0)cerr<<"part "<<start<<" completed "<<nr<<" nodes "<<nodes<<" depth "<<count_all.deepest<<'\n';
    if(cap&&nr==cap)break;
 }
 cerr<<"shard "<<start<<" roots "<<nr<<" nodes "<<nodes<<" cycle "<<count_all.cycle<<" additive "<<count_all.edge
     <<" parity "<<count_all.local<<" inherited "<<inherit_hits<<" contracted "<<contract_hits
     <<" tries "<<new_tries<<" depth "<<count_all.deepest<<'\n';
 return !out;
}
