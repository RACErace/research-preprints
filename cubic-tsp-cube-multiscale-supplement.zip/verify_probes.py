"""Independent integer replay of the interval and 2-opt certificate (Python standard library).
Usage: python3 -B verify_probes.py probes.json
"""
import json
import sys
from collections import Counter, defaultdict
from functools import lru_cache
from math import isqrt
from pathlib import Path

import spring_base as spring


def need(ok, message):
    if not ok:
        raise ValueError(message)


@lru_cache(None)
def refine(cell):
    origin, state = cell
    return tuple((tuple(2*x+y for x,y in zip(origin,offset)), child)
                 for offset,child in spring.parts(state))


def expand(seq):
    return tuple(ch for cell in seq for ch in refine(cell))


def reverse(seq):
    return tuple((v,(k,g,not r)) for v,(k,g,r) in seq[::-1])


@lru_cache(None)
def frame_change(frame):
    # Orthogonal matrix of the original cube frame. Its transpose is the inverse.
    cc = spring.CORNERS
    origin = cc[frame[0]]
    columns = tuple(tuple(x-y for x,y in zip(cc[frame[i]],origin)) for i in (4,2,1))
    inverse = tuple(frame.index(j) for j in range(8))
    return columns,inverse


@lru_cache(None)
def transformed(frame,rel,kind,orient,backwards):
    columns,inverse=frame_change(frame)
    lower=tuple(sum(x*y for x,y in zip(col,rel)) for col in columns)
    return lower,(kind,tuple(inverse[i] for i in orient),backwards)


def normalize(seq, pivot=0):
    origin, (_,frame,_) = seq[pivot]
    return tuple(transformed(frame,(p[0]-origin[0],p[1]-origin[1],p[2]-origin[2]),k,h,r)
                 for p,(k,h,r) in seq)

@lru_cache(None)
def adjacent_pairs():
    seqs = [spring.parts((k,spring.ID,r)) for k in (0,1) for r in (False,True)]
    seqs.append(spring.TOP+(spring.TOP[0],))
    pairs = {normalize(seq[i:i+2]) for seq in seqs for i in range(len(seq)-1)}
    previous = set()
    while previous != pairs:
        previous = pairs
        pairs = pairs | {normalize((refine(a)[-1],refine(b)[0])) for a,b in pairs}
    return frozenset(pairs)


@lru_cache(None)
def language(length):
    if length == 2:
        return adjacent_pairs()
    needed_parents = (length+14)//8
    out = set()
    for parent in language(needed_parents):
        seq = expand(parent)
        for j in range(8):
            part = seq[j:j+length]
            need(len(part)==length,"incomplete parent word")
            out.add(normalize(part))
    ring = spring.TOP*((length+14)//8)
    for j in range(8):
        out.add(normalize(ring[j:j+length]))
    return frozenset(out)


def stream_windows(length):
    """Generate the long words without retaining the full unprocessed language."""
    if length<=2:
        yield from adjacent_pairs()
        return
    for parent in language((length+14)//8):
        expanded=expand(parent)
        for offset in range(8):
            word=expanded[offset:offset+length]
            need(len(word)==length,"short extended word")
            yield word
    ring=spring.TOP*((length+14)//8)
    for first in range(8):
        yield ring[first:first+length]


@lru_cache(None)
def small_words(lag,radius):
    seqs = language(lag+2*radius+1)
    return tuple(sorted({normalize(word,radius) for s in seqs for word in (s,reverse(s))}))


def subcell(cell, digits, depth):
    for j in range(depth-1,-1,-1):
        cell = refine(cell)[(digits >> (3*j)) & 7]
    return cell


@lru_cache(None)
def norm_weights(squared_distance):
    radicand = squared_distance**3
    floor = isqrt(radicand)
    ceiling = floor + int(floor*floor < radicand)
    return floor,ceiling


def min_weight(p,a,q,b):
    gaps = (max(0, x-y-b, y-x-a) for x,y in zip(p,q))
    return norm_weights(sum(g*g for g in gaps))[0]


def max_weight(p,a,q,b):
    spans = (max(x+a-y,y+b-x) for x,y in zip(p,q))
    return norm_weights(sum(g*g for g in spans))[1]


def lower_corner(cell, scale):
    return tuple(z*scale for z in cell[0])


class Checker:
    def __init__(self, data):
        need(data.get("format")=="MDS41-REACH-1","format")
        self.b, self.target, self.tau, self.a, self.D = data["constants_hundredths_except_D"]
        self.radius=data.get("context_radius",2)
        need(2<=self.radius<=12,"context radius")
        self.level,self.idepth,self.jdepth=data["depths"]
        self.T=8**self.level
        self.S=2**self.level
        need(3<=self.idepth<=self.level<=8 and 1<=self.jdepth<=self.level,"depth policy")
        E=1700-self.target
        need(0<E<self.tau<=1700-self.b and 0<self.b<self.target<1700,"coefficient ranges")
        need(2*(100+self.a)*self.tau <= 100*self.D*(self.tau-E),"long-partner range")
        # All high chords have duration < (sqrt(3))^3 / b in global units.
        # This suffices for choosing a finer level and guarantees that the probe is outside I.
        need(4*27*100**2 < self.b**2,"first nontrivial level")
        need(27*(100+self.a)**2 < self.b**2,"probe lies on complementary arc")
        self.hints={}
        for row in data["leaves"]:
            need(len(row)==7 and all(type(x) is int for x in row),"integer leaf")
            lag,word,depth,i,j,direction,probe=row
            key=(lag,word,depth,i,j)
            need(key not in self.hints and direction in (0,1),"duplicate/invalid hint")
            self.hints[key]=(direction,probe)
        self.used=set()
        self.stats=Counter()
        self.hist=Counter()

    @lru_cache(None)
    def previous_words(self,lag):
        offset=self.D*min(lag+1,4)+self.radius+1
        length=offset+lag+self.radius+1
        completions=defaultdict(set)
        for seq in stream_windows(length):
            for word in (seq,reverse(seq)):
                norm=normalize(word,offset)
                completions[norm[offset-self.radius:]].add(norm[:offset+1])
        return offset,completions

    @lru_cache(None)
    def endpoints(self,core,iu,iv):
        # Chronological order: first partner endpoint u, then v, then I.
        offset,groups=self.previous_words(len(core)-2*self.radius-1)
        need(0<=offset+iu<=offset+iv<=offset and core in groups,"incomplete extension")
        return tuple(sorted({(s[offset+iu],s[offset+iv]) for s in groups[core]}))

    def partner(self,core,h,i,j,probe):
        T,S=self.T,self.S
        lag=len(core)-2*self.radius-1
        block=8**h
        it=T//block
        si,st=i*it,(i+1)*it
        tt=(j+1)*it
        lo_i=max(T//2,(j-i-1)*it)
        hi_i=min(4*T,(j-i+1)*it)
        need(probe<si and 100*(st-probe)<=self.a*lo_i, "probe clearance")
        side_i=S//(2**h)
        a=lower_corner(subcell(core[self.radius],i,h),side_i)
        b=lower_corner(subcell(core[self.radius+lag],j-lag*block,h),side_i)
        # Minimum original I cost in units scaled by 10000.
        cost_i=max(100*self.b*lo_i,10000*min_weight(a,side_i,b,side_i))
        roots=set()
        for left in range((probe-self.D*hi_i)//T,probe//T+1):
            for right in range(probe//T,min(0,st//T)+1):
                for first,last in self.endpoints(core,left,right):
                    roots.add((0,left*T,first,right*T,last))
        need(roots,"empty partner cover")
        pending=list(roots)
        while pending:
            k,u,x,v,y=pending.pop()
            self.stats["partner_rectangles"]+=1
            time=T//(8**k)
            # Intersect each closed parameter cylinder with the probe and gap constraints.
            u_low=max(u,probe-self.D*hi_i)
            u_high=min(u+time,probe)
            v_low=max(v,probe)
            v_high=min(v+time,st)
            if u_low>u_high or v_low>v_high:
                continue
            lower=max(0,v_low-u_high)
            upper=v_high-u_low
            if lower>self.D*hi_i:
                continue
            side=S//(2**k)
            c=lower_corner(x,side)
            e=lower_corner(y,side)
            j_upper=max_weight(c,side,e,side)
            j_lower=min_weight(c,side,e,side)
            reach=tt-v_low
            # Let z=17-rate(J), E=17-target. Evaluate a lower bound on |J| V(z)
            # where V=max(z-E, min(z+tau-E, 17-b-E)).
            credit=200*self.tau*reach
            basic=100*self.target*lower-10000*j_upper
            boost=100*self.tau*lower
            plateau=100*(self.target-self.b)*lower
            if max(basic,min(basic+boost,plateau))>=credit:
                self.stats["credit_terminals"]+=1
                continue
            # If the credit test is actually false, the cost of J has this lower bound.
            conditional=100*self.target*lower-credit
            if plateau>=credit:
                conditional+=boost
            before=cost_i+max(10000*j_lower,conditional)
            after=10000*(max_weight(a,side_i,c,side)+max_weight(b,side_i,e,side))
            extra=0 if 100*j_upper<=self.b*lower else min(upper,reach)
            required=100*self.tau*(3*reach+extra)
            if before-after>=required:
                self.stats["exchange_terminals"]+=1
                continue
            need(k<self.jdepth,"unproved partner inequality")
            child_time=time//8
            for kx,cx in enumerate(refine(x)):
                for ky,cy in enumerate(refine(y)):
                    pending.append((k+1,u+kx*child_time,cx,v+ky*child_time,cy))

    def check_word(self,lag,wordno,seq):
        pending=[(0,0,seq[self.radius],lag,seq[self.radius+lag])]
        while pending:
            h,i,x,j,y=pending.pop()
            self.stats["localization_rectangles"]+=1
            time=8**h
            if 2*(j+1-i)<time or j-i-1>=4*time:
                continue
            sq=sum((abs(s-t)+1)**2 for s,t in zip(x[0],y[0]))
            if 40000*sq**3 <= self.b**2*max(time,2*(j-i-1))**2:
                continue
            key=(lag,wordno,h,i,j)
            if key in self.hints:
                direction,probe=self.hints[key]
                core=seq
                if direction:
                    core=normalize(reverse(seq),self.radius)
                    i,j=(lag+1)*time-1-j,(lag+1)*time-1-i
                self.partner(core,h,i,j,probe)
                self.used.add(key)
                self.hist[lag]+=1
                continue
            need(h<self.idepth,"missing high-chord certificate")
            for ix,cx in enumerate(refine(x)):
                for iy,cy in enumerate(refine(y)):
                    pending.append((h+1,8*i+ix,cx,8*j+iy,cy))

    def run(self):
        for lag in range(5):
            for i,s in enumerate(small_words(lag,self.radius)):
                self.check_word(lag,i,s)
            self.endpoints.cache_clear()
            self.previous_words.cache_clear()
            transformed.cache_clear()
            refine.cache_clear()
        need(self.used==self.hints.keys(),"unused leaf")
        print("total cost upper bound", f"{self.target//100}.{self.target%100:02d}")
        print("hints",len(self.used),"by lag",sorted(self.hist.items()))
        print("coverage",sorted(self.stats.items()))


if __name__=="__main__":
    data=json.loads(Path(sys.argv[1]).read_text())
    Checker(data).run()
