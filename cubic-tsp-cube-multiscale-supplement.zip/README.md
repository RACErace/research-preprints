# MDS 2026 立方体巡回 · 多尺度换边与九点证明

研究预印本，2026-11-26。仓库中的 cubic-tsp-cube-multiscale.pdf 与 proof-multiscale.md 组成同一中文证明稿。C 表示最优 Hamilton 闭巡回的边长立方和的全体点数上确界。

- 任意点数有 8√2 ≤ C ≤ 82/5 = 16.40。相对于 16.9725027614，降低约 0.572503。
- 九点上确界等于 8√2，每个九点互异构型都严格低于它。结合以前的至八点证书，反例至少需要十点。
- 对闭合 Spring 环的全部 48 个立方体对称像，取成本最小的固定排序，其上确界仍为 1533√6/221。
- 一般等式仍未闭合。数字 82/5 是证明的上界；文中的近似小数用于表示降幅及尺度。

## 离线重放
 
九点证书文本较大。按文件名顺序拼接仓库中 [cubic-tsp-cube-multiscale-data](https://github.com/RACErace/research-preprints/tree/main/cubic-tsp-cube-multiscale-data) 的六个 n9.boxes.xz.part-* 文件，将生成的 n9.boxes.xz 放到本目录，再运行 bash reproduce.sh。NINE-SHA256.txt 校验拼接后的原件。

在解压后的目录运行下面的命令。新结果需要 Python 3.9+ 标准库、bash、gzip、xz 和支持 unsigned __int128 的 C++17 编译器。复核附录引用的四至六点证书还需 NumPy。SHA256SUMS 可检查源文件、证明树和日志；将 PDF 与 PDF-SHA256.txt 放在同一文件夹即可另查其哈希。

~~~bash
bash reproduce.sh
~~~

新结果的各个入口如下。

~~~bash
python3 -B spring_base.py
python3 -B verify_probes.py probes.json
python3 -B verify_structures.py
c++ -O2 -std=c++17 verify_boxes.cpp -o /tmp/mds41_nine_check
xz -dc n9.boxes.xz | /tmp/mds41_nine_check
~~~

## 全局换边证书

settings.json 保存精确参数。constants_hundredths_except_D 的前四项分别为高比率门槛、全局上界、每单位时间所需节省与探测距离上限，均以 1/100 计；末项 D 为整数。depths 依次为空间整数网格层数、端点定位最大深度及伴随间隙最大深度。

probes.json 包含 124 行探测记录，每行七个整数依次表示末块相对首块的编号、窗口编号、子块深度、两个端点的时间子块编号、是否颠倒方向、所选方向下探测时间。最后一项用 1/8^6 为单位。窗口按相对于首块的空间坐标架标准化，再按 Python 元组的字典序编号。verify_probes.py 自动重建窗口语言、全部高比率盒和所有兼容的伴随间隙，检查阈值分支和向外取整的不等式。它只读探测表，不需要猜测最短巡回或寻找探测点。

generate_probes.py 可以仅从参数重新生成探测表。探测候选的排序仅用于提高发现速度；成功的候选需要逐盒复核。

~~~bash
python3 -B generate_probes.py settings.json rebuilt-probes.json
python3 -B verify_probes.py rebuilt-probes.json
~~~

spring_base.py 保存递归规格与单弦常数的精确核验。verify_structures.py 单独检查八个空间角码把 96 个空间状态变为一个、原型取等弦的有理时间与九标签共线例。它还对 4 至 10 条原边的全部非交错部分匹配作组合回归；一般点数的嵌套结论由正文的归纳证明给出。

## 九点证明森林

解压 n9.boxes.xz 后的文本记录六个标记面和各坐标半区间的根盒及分叉树。首行为 MDS41BOX1 9。每行先列九个盒码，再按前序列出证明树。负数 -1-3i-k 表示等分第 i 点第 k 坐标，零表示使用角簇引理，正数表示巡回编号。巡回从 0 开始，按其余标签排列的字典序列举，保留第二标签小于末标签的方向，编号从 1 开始。

verify_boxes.cpp 独立计算合法根多重集的总数，检查对称轨道覆盖，并以整数边权与最大值动态规划复核每个叶。generate9.cpp 生成根、沿用父巡回、将最接近的双点视作连续访问候选，并按最坏盒顶点的移动影响选择分叉。提供的森林由六个有限分片拼接。generation9.log 记录各分片的节点数和候选来源。下面是单分片重建命令；集合相同，输出行次序可因分片而异。

~~~bash
c++ -O3 -std=c++17 generate9.cpp -o /tmp/mds41_g9
/tmp/mds41_g9 roots roots.txt
/tmp/mds41_g9 solve roots.txt rows.txt 0 1 0
{ echo 'MDS41BOX1 9'; cat rows.txt; } | /tmp/mds41_nine_check
~~~

prior-small/ 保存四至八点的既有证书。七、八点与九点共用 verify_boxes.cpp。四至六点的独立核验器位于该子目录。各 .log 文件是实际重放记录。

## 一手来源

- [MDS §4](https://arxiv.org/html/2611.03403v1#S4)
- [Balogh–Clemen–Dumitrescu](https://arxiv.org/abs/2310.02839)
- [Gordeev 的定理 1.7 与附录 A](https://arxiv.org/html/2603.22010v1)
- [Malykhin–Shchepin 的 Spring 递归构造](https://arxiv.org/html/2103.07344v2#S3.SS2)
