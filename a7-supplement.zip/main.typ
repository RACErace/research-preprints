#set document(title: "A certified A7 minimizer for two-site Lennard–Jones crystals")
#set page(paper: "a4", margin: (x: 26mm, y: 24mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.63em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#let eq = math.equation
#let RR = math.bb("R")
#let ZZ = math.bb("Z")
#let q = math.italic("q")
#let note(body) = block(inset: 10pt, fill: luma(245), width: 100%, breakable: true, body)
#align(center)[
  #text(size: 22pt, weight: "semibold")[A certified A7 minimizer \ for two-site Lennard–Jones crystals]
  #v(7pt)
  #text(size: 11pt)[A fixed-density computer-assisted proof]
  #v(5pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(8pt)

#note[
  *Abstract.* For the classical three-dimensional Lennard–Jones interaction
  $U(r)=r^(-12)-2r^(-6)$ at volume $269/250$ per particle, we minimize the energy
  over all periodic point sets admitting a cell with two identical particles.
  The unique minimizer up to Euclidean isometry is a rhombohedral A7 crystal.
  The proof allows arbitrary cell shape and continuous displacement of the
  two sites. It combines compactness estimates, certified lattice-sum
  enclosures, stationarity in six short-bond coordinates, and an
  eight-dimensional strict-convexity certificate. A compact-domain replay and
  a separate three-dimensional Ewald energy calculation accompany the proof.
  The restriction on period size is essential: an explicit three-site
  periodic set at the same density has strictly lower energy.
]

*Keywords:* Lennard–Jones potential; crystallization; rhombohedral A7; periodic point sets; interval arithmetic. *MSC 2020:* 82B20, 65G40, 52C07.

= Problem and main result

Let $B$ be a real invertible $3 times 3$ matrix with $|det B|=2V$ and
let $tau in RR^3 "/" (B ZZ^3)$ be nonzero. The configurations are
$X = B ZZ^3 union (B ZZ^3 + tau)$; two choices of $B,tau$ may describe the same
point set. With an unordered-pair normalization the energy per particle is
$ E(B,tau) = 1/2 sum_(n in ZZ^3, n != 0) U(|B n|) + 1/2 sum_(n in ZZ^3) U(|B n + tau|). $ <energy>
The inversion $x arrow.r.bar tau - x$ interchanges the two site types, so each term
in the cell average gives the same neighbor sum. Both series are absolutely
convergent. A one-site Bravais lattice is included by choosing an index-two
sublattice for its period.

#note[
  *Theorem 1.* At $V=269/250$, the minimum of @energy is attained by exactly
  one point set up to Euclidean isometry. Its crystal type is A7 (the
  $alpha$-arsenic prototype). The minimum energy lies in
  $[-5.91931549031815437239796, -5.91931549031815437239792]$.
]
A representative is given by
$ a_1=a(1,0,0), quad a_2=a(1/2,sqrt(3)/2,0), quad h=(a_1+a_2)/3, $
$ B=(a_1,a_2,h+H e_3), quad tau=h+w H e_3, quad H=4V/(sqrt(3)a^2). $ <a7>
Here $a=0.9902761977649663 dots$ and $w=0.3195605718688901 dots$.
Across the short gap the two triangular layers are offset to a triangular
hole; across the long gap they are aligned. In a conventional hexagonal
cell the height is $3H$; after placing the origin at the midpoint of an
aligned long gap, the two axial positions have fractional coordinates
$plus.minus (1-w)/6$, with rhombohedral centering. This identifies the
standard hR2, space group 166 prototype @aflow. A7 itself is not a new
crystal geometry.

#table(
 columns: (1fr, 1fr, 1fr), align: (left, right, right),
 inset: 6pt, stroke: (x: none, y: 0.4pt + luma(190)),
 [Parameter], [Lower endpoint], [Upper endpoint],
 [$a$], [0.99027619776496630691944], [0.99027619776496630691948],
 [$w$], [0.31956057186889011095709], [0.31956057186889011095713],
 [Short gap], [0.809752213763179], [0.809752213763180],
 [Long gap], [1.724203114416062], [1.724203114416063],
)

== Relation to earlier work

Luo and Wei classify the minima of the same normalized energy over
three-dimensional *Bravais* lattices at prescribed covolume @luowei.
Their simple-hexagonal branch includes the volume selected here, just
above their tetragonal-to-simple-hexagonal transition. Their displacement
variables describe changes of a one-site lattice basis, not an independent
two-site basis. Bétermin, Šamaj, and Travěnec numerically compare Bravais
families and include the ideal HCP geometry as an additional competitor
@betermin3d. The Burgers–Bain calculations of Robles-Navarro et al. treat a
symmetry-broken transformation path with a two-site basis and exact
lattice sums, but their path does not range over all fixed-volume
two-site cells @burgers. The model of Das, Sengupta, and Sinha constrains
particles to two planes rather than allowing a freely periodic
three-dimensional cell @das.

There are also prior A7 examples for other isotropic interactions
@saija @jain, and computer-assisted optimality results for
two-dimensional Bravais lattices @betermin2d. The contribution here is
the combination of the *unmodified 12–6 potential*, the stated volume,
and a global certificate over the full two-site domain. We found no
earlier proof of this combination in the sources examined. This is a
bounded literature assessment, not a claim of priority over every
unindexed or unpublished result.

= Compactness and stationarity

In a reduced basis, write
$ B=mat(a,a u,a v;0,b,b s;0,0,H), quad H=2V/(a b), quad theta=B^(-1)tau. $ <reduced>
The chart removes rigid rotations. Reduced bases and sign changes give
$0 <= u,s <= 1/2$, $|v| <=1/2$, and $theta in [-1/2,1/2]^3$.
By choosing the basis site, $w=theta_3$ is taken nonnegative.
The reduced Gram–Schmidt lengths satisfy $b >= sqrt(3)a/2$ and
$H >= sqrt(3)b/2$. Only configurations with energy no larger than the
A7 trial value must be retained. The compactification certificate first
bounds the attraction by separated-point packing, uses short-distance
repulsion to exclude collisions, and separates positive and negative
Mellin kernels for a bound depending on the three Gram–Schmidt lengths.
The shifted Gaussian bound uses that a one-dimensional Gaussian theta
sum is largest at zero shift; this follows from Poisson summation with
positive Fourier coefficients. The certificate, linked below, gives
$a >= 0.75$, $a < 1.50$, $0.66 <= b <= 1.79$, $1.10 <= H <= 4.24$, and
every inter-sublattice separation greater than $0.73$. Using the
slightly larger upper bound $1.50$ permits a simple compact-domain
replay. Uniform summability on the sublevel set gives attainment. A
minimizer on a face of the reduced-coordinate domain still satisfies
unconstrained physical stationarity at fixed volume: the reduced domain
is only a representation of those same crystals.

Put $f(q)=q^(-6)/2-q^(-3)$ and $g(q)=2 f'(q)$, and write
$xi=B n+o tau$ with $o in {0,1}$ and the origin omitted from the $o=0$
sum. The three force equations are $sum_(o=1) g(|xi|^2) xi=0$.
With $P=sum_xi g(|xi|^2) xi xi^T$, the five strain equations are
$ P_(11)-P_(33)=P_(22)-P_(33)=P_(12)=P_(13)=P_(23)=0. $ <stationary>
These follow by differentiating @energy along trace-free linear strains
of both the cell and the basis.

For a point set with separation at least $d$, disjoint balls of radius
$d/2$ and the sub-mean property of $|x|^(-p)$ give the bound
$ sum_(|xi|>R) |xi|^(-p) <=
  T_p(R,d):= (24(R-d/2)^(3-p))/(d^3(p-3)), quad p>3, R>d/2. $ <tail>
Indeed the balls centered at the omitted points are outside radius
$R-d/2$, and dividing the radial integral by their volume gives @tail.
Positive far-field energy terms may be dropped from a lower bound;
derivative tails use absolute values. Distances whose enclosures cross
the cutoff are included in the explicit sum.

= From the compact domain to the A7 basin

== Exclusion over all cell shapes

Let $G$ denote the upper-left $2 times 2$ block in @reduced and $A=a b$.
The lateral shifts across the short and long gaps can be taken independently
on the two-torus, denoted $p,z$. In these coordinates the primitive lateral
drift is $p+z$ modulo the basal lattice, and the short and long gaps have
heights $w H$ and $(1-w)H$. For a horizontal shift $y$, introduce the sheet sum
$ Phi_t(y)=sum_(j in ZZ^2) U(sqrt(|G(j+y)|^2+t^2)). $
Its two-dimensional Poisson series has a zero mode
$pi/(10 A t^10)-pi/(2 A t^4)$, and for $m!=0$, with
$rho=|G^(-T)m|$, it has coefficient
$ C_m(t)=pi^6/(120 A)(rho/t)^5 K_5(2pi rho t)
          -pi^3/A (rho/t)^2 K_2(2pi rho t). $ <poisson>
This follows from the Mellin integral for inverse powers and the Gaussian
transform. The nonzero Fourier modes are controlled with
$K_nu(x) <= sqrt(pi/(2x)) exp(-x+nu^2/(2x))$ for $x>0$,
from the integral representation and $cosh t >= 1+t^2/2$.
The resulting geometric tails are evaluated with outward rounding.
Sheet zero modes of the distant layers are summed by Hurwitz zeta.

The exterior check encloses all four translations at once when bounding
the energy for each shape box. For near layers, linear lower supports for
several bonds are combined before minimizing, retaining the dependence
between bonds sharing a shift. A second lower bound treats shared Fourier
phases with interval or trigonometric inequalities. The larger of the
two lower bounds is used. For stationary candidates with $(1-w)H>=1$,
an additional bound follows from @stationary and the vertical optical force:
$ gamma=P_(33)=2(S_6-S_12)=sum_xi g(|xi|^2) xi_3 H n_3 >=0,
  quad S_j=sum_xi |xi|^(-j). $ <virial>
The $n_3=0$ summands vanish; for $n_3!=0$, $xi_3$ has the same sign as
$n_3$ and $|xi_3|>=1$. Thus if the preliminary lower bound is $E>=-7$,
then $S_6,S_12<=14$ by @energy and @virial. This bounds distances and
derivative sizes along box segments. Taylor estimates about virtual
reference points can use zero first derivative at the unknown stationary
point, not at the virtual reference point.

The full compact domain is divided into two shape pieces at
$a=5899/4096$. Each starts with 512 subboxes, retaining the full lateral
tori. A preliminary energy floor of $-7$ is certified in 1,558 and 512
evaluations, respectively. The exterior pass then covers the complement
of the shape region
$ [0.984,0.997] times [0.849,0.869] times [0.481,0.5] times [0.314,0.3255] $
in $(a,b,u,w)$, with boundaries included and decimal target endpoints
rounded inward. The two exterior passes require 124,276 and 1,378
evaluations; neither leaves an unresolved exterior box. They use the
compactification and the A7 upper bound, not the ordering or shape of the
earlier eight-dimensional search frontier. The alternative inherited
frontier route is retained in the supplement.

== Translations and the six short bonds

For fixed shape and $p$, compare a minimizing $z$ with $z=0$. On a
fundamental square for $z$, the long-gap terms exceed their value at
zero by a strictly positive multiple of $|z|^2$. The two leading
negative Fourier coefficients yield this term through
$1-cos(2pi t)>=8t^2$ for $|t|<=1/2$; the other coefficients have a
bounded opposing contribution. The remaining layers have bounded slip
gradient. The ratio in the certificate gives
$|z|<=0.013012279688513$. For the short gap, energy comparison with a
triangular-hole shift, vanishing force, and nonnegative second
variation give a rectangular bound for $p$, modulo simultaneous sign
reversal of the two shifts:
$ 0.26953125<=p_1<=0.46484375, quad
  0.265625<=p_2<=0.46484375. $

Put $t=G p+w H e_3$ and introduce short-bond squares
$ Q=(|a_1|^2,|a_2|^2,|a_1-a_2|^2,|t|^2,|t-a_1|^2,|t-a_2|^2). $
They are smooth coordinates together with $z$. To invert them set
$g_0=(Q_1+Q_2-Q_3)/2$,
$v_i=(Q_4+Q_i-Q_(4+i))/2$ for $i=1,2$, and
$G_0=mat(Q_1,g_0;g_0,Q_2)$. Then $p=G_0^(-1)(v_1,v_2)^T$,
$A=sqrt(det G_0)$, and $(w H)^2=Q_4-p dot.op (v_1,v_2)$.
Every basal and central short-sheet bond square is linear in $Q$.
Separating the six designated bonds from the rest of the energy gives
$ m_i f'(Q_i)=-partial_(Q_i) E_"rest", quad
  (m_1,dots,m_6)=(2,2,2,1,1,1). $ <bonds>
Certified enclosure of the right sides, including the complete
real-space and Fourier tails, reduces the distance from the A7 bond
vector $Q_*$ to under $0.019969$ in the maximum norm.

== Strict convexity and uniqueness

The candidate @a7 is obtained by certifying a stationary point
in $(a,w)$. Its threefold symmetry makes the optical force purely
vertical, the planar stress isotropic, and the axial shears zero.
The two restricted stationarity equations then force the remaining
vertical force and the axial deviatoric stress to vanish.

In the region $|Q-Q_*|_infinity<=0.020$ and $|z|_infinity<=0.014$,
an interval $L D L^T$ test certifies $E_(Q Q) succ.eq I_6$.
At $Q=Q_*$, the mixed Hessian has Frobenius norm below $0.001285034$.
Integration of the two derivative bounds, using stationarity at the
candidate and the minimizing point, yields
$ |Q-Q_*|_2 <= 0.001285034 |z|_2 < 0.000016722. $
On the convex product box with radii $0.01$ for each of the six bond
coordinates and $0.03$ for the two slip coordinates, the algorithm
verifies the full matrix inequality
$ D^2 E succ.eq op("diag")(0.01,0.01,0.01,0.01,0.01,0.01,10^(-5),10^(-5)). $
The real-space Hessian calculation preserves the quadratic-form lower
bound for each rank-one term, and adds the complete tail before the
test. The long-slip second derivatives use the Fourier series; the
mixed entries are enclosed componentwise. This convex region contains
every possible minimizing configuration in equivalent coordinates
and contains the exact A7 stationary point, so there is only one
minimizer up to the stated equivalences. The certified restricted energy
interval is independently checked by three-dimensional Ewald summation
with separate real and reciprocal Gaussian tail bounds.

= Why the two-site restriction matters

A finite, explicit competitor suffices. Take the unit triangular
basal vectors $e_1=(1,0,0)$, $e_2=(1/2,sqrt(3)/2,0)$, shift
$delta=(e_1+e_2)/3$, and spacing $d=7/(5 sqrt(3))$. Put the three
sites at $k delta+k d e_3$, $k=0,1,2$, with third period
$6V e_3/sqrt(3)$. The determinant is $3V$, so this is exactly the
same mean density. The nearest squared distance is $74/75$, larger
than the zero of the energy as a function of squared distance,
$2^(-1/3)$. The normal gap between neighboring trilayers exceeds
two. Thus all omitted pair terms are attractive. Sum over
$-2<=i,j<=2$ and the three possible nonnegative intratrilayer
separations $k$. The squared distances are
$ ((3i+k)^2+(3j+k)^2+(3i+k)(3j+k))/9 + 49k^2/75. $
Drop the origin and multiply the group sums for $k=0,1,2$ by
$1/2,2/3,1/3$, respectively. The exact rational 74-term sum is below
$-6.328428$. This is an upper bound on the full energy, strictly below
the A7 lower endpoint. No conclusion about the minimum among
three-site cells, longer-period modulations, the unrestricted ground
state, or a density interval is asserted.

= Reproducibility and disclosure

The companion archive provides the exact cell certificate, generators
for Arb tables, C++20 fixed-point arithmetic kernels, analytic
tail estimates, original checkpoints, an independently restartable
compact-domain cover, scripts, and SHA-256 checksums.
The finite computational assertions are part of the proof, not
results of an unconstrained random search. Endpoint choices and
heuristic search suggestions do not provide lower bounds unless
verified by the interval steps. All replays should run with
assertions enabled. Start with the compact-domain route:

```sh
unzip lj-A7-V1076-proof.zip -d proof
cd proof
sha256sum -c SHA256SUMS
python -m pip install -r requirements.txt
bash reproduce.sh outer
```

The compact, shape exterior, long-slip, short-slip, six-bond and final
convexity steps can be inspected independently in the accompanying
source files. The high-precision Ewald calculation is separate from
the layer reduction for the energy at the same certified point.
The three-site calculation is independently reproducible with the
small exact-rational script supplied alongside the archive.

This preprint is not peer reviewed. AI-assisted research tools were
used to explore the construction, develop certificates and code, and
prepare this manuscript. The public artifacts expose the proof
and computational checks for scrutiny; no independent human referee
endorsement is implied.

#pagebreak(weak: true)
#bibliography("references.bib", title: "References", style: "ieee")
