"""Exact upper bound for a three-site competitor at volume 269/250 per site."""
from fractions import Fraction as Q

V = Q(269, 250)
A7_LOWER = Q("-5.91931549031815437239796")
# H=6V/sqrt(3), d=7/(5 sqrt(3)); gap H-2d>2 and min squared distance above LJ zero.
assert (6 * V - Q(14, 5)) ** 2 / 3 > 4 and 6 * V > Q(14, 5)
assert 2 * Q(74, 75) ** 3 > 1

def u(q):
    return q ** -6 - 2 * q ** -3

partial = Q(0)
n = 0
for k, weight in enumerate((Q(1, 2), Q(2, 3), Q(1, 3))):
    for i in range(-2, 3):
        for j in range(-2, 3):
            if k == i == j == 0:
                continue
            x, y = 3 * i + k, 3 * j + k
            q = Q(x*x + x*y + y*y, 9) + Q(49 * k*k, 75)
            assert u(q) < 0
            partial += weight * u(q)
            n += 1
assert n == 74
assert partial < Q("-6.328428")
assert A7_LOWER - partial > Q("0.4091125")
print("74 exact terms passed: E_trilayer < -6.328428; certified gain > 0.4091125.")
