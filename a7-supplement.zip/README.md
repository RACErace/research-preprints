# A certified A7 minimizer for two-site Lennard–Jones crystals

**Result.** For the untruncated potential U(r) = r^(-12) − 2r^(-6) at volume **269/250 per particle**, the rhombohedral A7 crystal uniquely minimizes the energy among periodic point sets with at most two sites per primitive cell, up to isometry. The proof covers skew cells and arbitrary relative site positions. The energy per particle is in the interval [−5.91931549031815437239796, −5.91931549031815437239792].

A7 is an established structural prototype. What appears new in the literature surveyed is the **global optimality certificate for this potential, volume, and full two-site class**. The [literature audit](NOVELTY.md) lists the nearest precedents. This is a research preprint, not a peer-reviewed publication. The result does not prove that A7 minimizes over larger cells: a strict three-site counterexample is included.

## Files

- [Preprint PDF](A7-Lennard-Jones.pdf), [Typst source](main.typ), and [bibliography](references.bib).
- [Computational supplement](lj-A7-V1076-proof.zip): source, interval arithmetic, certificates, reference data, analytic bounds, and clean-directory replay entry points. The archive has its own checksums. [Technical proof notes in Chinese](PROOF.zh.md) are also available separately.
- [A7 coordinates](A7-V1.076.extxyz) for visualization. The element symbol X means an identical model particle, not a prediction about real arsenic.
- [Three-site witness](verify_trilayer.py): standalone exact rational arithmetic using only the Python standard library.
- [Release checksums](SHA256SUMS) for these top-level files.

## Reproduce

Use Bash, unzip, Python 3.12 with the supplied pinned dependencies, and GCC with C++20 support. Do not disable assertions.

    sha256sum -c SHA256SUMS
    python3 verify_trilayer.py

    unzip lj-A7-V1076-proof.zip -d proof
    cd proof
    sha256sum -c SHA256SUMS
    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install -r requirements.txt
    bash reproduce.sh outer

The outer mode rebuilds the compact-domain exterior cover and reruns the remaining proofs through eight-dimensional closure and a separate three-dimensional Ewald check. The last mode starts from the saved shape cover; full replays the earlier eight-dimensional search and certification route. Outer replay was verified from a fresh extraction. Numerical random-start optimization is not an exclusion certificate.

Build the paper from this directory with:

    typst compile main.typ A7-Lennard-Jones.pdf

The bibliography is local; the external sources themselves are linked, not redistributed. AI-assisted tools contributed to the research, computation, and manuscript.
