# Literature and priority check

Search date: 26 November 2026. **No matching prior theorem was found in the public sources checked.** That is evidence for originality of the narrowly stated result, not proof of priority or a novelty determination by a journal.

## Claim tested

Classical, untruncated, one-component 12–6 Lennard–Jones with minimum pair energy −1 at distance 1. Three dimensions. Volume 269/250 per particle. All invertible period cells of determinant magnitude 2V and all noncoincident two-site bases are admissible. The theorem is global, with uniqueness up to isometry and reproducible interval certificates. Comparison of prescribed structures, local Hessians, or solutions under extra metric or registry constraints would not anticipate it.

A7 itself is not new. Nor is the expression of inverse-power lattice sums by Poisson or Ewald series. The proof does not classify volumes other than the one stated or solve unrestricted crystallization.

| Primary source | What overlaps | Why it is not the same claim |
|---|---|---|
| [Luo & Wei, 2026, Theorem 1.1](https://arxiv.org/html/2611.19696v1#S1) | Same energy and fixed volume, rigorous interval techniques. The relevant Bravais branch is simple hexagonal. | The variable is a Bravais lattice with one point per primitive cell. A7 requires an independent two-site basis. |
| [Bétermin, Šamaj & Travěnec, 2023, §§1.2 and 3.1](https://doi.org/10.1111/sapm.12533) | Fixed-density Lennard–Jones lattice energies and a non-Bravais competitor. | Extends Bravais comparisons by one homothetic ideal HCP geometry, not generic two-site cells. |
| [Robles-Navarro et al., v3, §§II.1.3 and III.2](https://arxiv.org/html/2406.09635v3) | Two-site basis, shear and sliding, exact sums along Burgers–Bain transformations. | Restricted metric and basis displacement families; no global A7 certificate across arbitrary skew cells. |
| [Das, Sengupta & Sinha, 2009](https://doi.org/10.1088/0953-8984/21/19/195408) | Lennard–Jones crystalline bilayers. | Particles are confined to two planes with controlled planar density and separation, not freely periodic in three dimensions. |
| [AFLOW A7 prototype](https://aflow.org/p/F2V5) and [arsenic DFT](https://arxiv.org/abs/0810.1692) | A7 geometry and material transformations. | Geometry and electronic-structure calculations are not a classical 12–6 variational theorem. |
| [Saija et al., 2009](https://doi.org/10.1103/PhysRevE.80.031502) and [Jain et al., 2014](https://doi.org/10.1103/PhysRevX.4.031049) | A7 occurs or is considered for isotropic interactions. | Different pair potentials and optimization domains. |
| [Luo & Xie, 2026](https://arxiv.org/abs/2610.26553) | Fixed-volume two-site global optimization and uniqueness. | Squared-distance quantization energy, not Lennard–Jones; rectangular cells. |
| [Bétermin, 2021](https://arxiv.org/abs/2104.09795) | Computer-assisted Lennard–Jones lattice optimality. | Two-dimensional Bravais class. |

Queried combinations of “Lennard-Jones” with “A7”, “alpha-arsenic”, “hR2”, “rhombohedral bilayer”, “bilattice”, “two-site”, “two-point periodic”, “two atoms per unit cell”, “fixed density”, “non-Bravais”, and “computer-assisted global optimality”. Searched for 1.076 and the closest one-site preprint identifier, and compared publisher or author versions. Searches can miss work that is unpublished, not indexed, or described with different terminology.

## 中文结论

A7 结构本身不是新发现。最近的工作分别只覆盖单点布拉菲晶格、指定候选结构、受限变形路径，或不同势函数。本次公开检索没有发现已经证明「纯 12–6 势、每粒子体积 269/250、全体双点周期晶体、A7 唯一全局最优」的工作。可以将这一具体结果作为看来有原创性的计算机辅助预印本发布，不能据此宣称已经确认世界首创或已经同行评议。
