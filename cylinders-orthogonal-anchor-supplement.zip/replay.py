"""Replay the fixed-edge joint certificates with Python 3.9+ and a C++17 compiler."""
import json,shutil,subprocess,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from fractions import Fraction as F
from check_bands import one
from check_axes import check as axes
from check_cycle import cycle
from check_identity import verify
from check_obstruction import check_point
from check_outer_clique import check as outer
from check_pairs import check as pairs
from triple import tensors,boxes,T

ROOT=Path(__file__).resolve().parent

def data(p):return json.loads(p.read_text())
def compile_one(name,tmp,cc):
    target=tmp/name
    subprocess.run([cc,"-O3","-std=c++17",str(ROOT/(name+".cpp")),"-o",str(target)],check=True)
    return target
def main():
    cc=shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
    if not cc or sys.byteorder!="little":raise RuntimeError("little-endian system and GCC/Clang C++17 required")
    ker=data(ROOT/"marked-edge.json")
    if F(ker["h"])!=F(3661,25000) or F(ker["pair_upper"])!=F(-119,1000):raise ValueError("bad pair bound")
    one(ker,False)
    one({**ker,"h":"73/500"},False)
    pairs(ker,data(ROOT/"pair-obstruction.json"));outer();cycle()
    check_point((2083,1997,-8766,-3850))
    with TemporaryDirectory() as d:
        tmp=Path(d);exe=compile_one("place_graph",tmp,cc);subprocess.run([str(exe)],check=True)
        exe=compile_one("check_triple",tmp,cc)
        geom=[p for p in sorted(ROOT.glob("*.json")) if isinstance(data(p),dict) and "geometry" in data(p)]
        if not {"frame-c.json","orth-zero.json","triad-d.json","orth-diagonal.json","orth-quarter-point.json"}.issubset({p.name for p in geom}):raise ValueError("missing a required mark")
        for p in geom:
            mark=data(p);verify(mark)
            f=tmp/"mark.bin";b=tmp/"boxes.txt";bound=tensors(mark,ker,f);boxes(mark,b)
            print(p.name,"exact lower bound on squared norm",bound,">",T,flush=True)
            subprocess.run([str(exe),str(f),str(b)],check=True)
    print("PASS: combinatorial parameter bound, compatible-edge obstruction, outer clique, and all conditional six-line domain covers")
if __name__=="__main__":main()
