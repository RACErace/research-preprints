"""Exact obstruction to every affine-shifted pair inequality of this fixed kernel."""
from fractions import Fraction as F
from math import comb
from check_obstruction import features,check_point,intervals

def relative(a,b):
    rows=((1,2,3,4),(-2,1,4,-3),(-3,-4,1,2),(-4,3,-2,1))
    return tuple(sum((1 if v>0 else -1)*a[abs(v)-1]*x for v,x in zip(row,b)) for row in rows)

def check(kernel,doc):
    q=doc["q"];edges=doc["edges"];weights=doc["weights"];W=sum(weights)
    if len(edges)!=len(weights) or len(edges)==0 or any(type(v)!=int or v<=0 for v in weights):
        raise ValueError("invalid weights")
    for row in q:
        if len(row)!=4 or any(type(z)!=int for z in row):raise ValueError("bad integer frame")
        check_point(row)
    _,hhi=intervals();rel=[];marginal=[0]*len(q)
    for (i,j),wi in zip(edges,weights):
        if not (type(i)==int and type(j)==int and 0<=i<j<len(q)):raise ValueError("bad edge")
        z=relative(q[i],q[j]);s=[a*a for a in z]
        if not s[1]*s[2]>hhi*(s[0]+s[1])*(s[2]+s[3]):raise ValueError("incompatible pair")
        rel.append(z);marginal[i]+=wi;marginal[j]+=wi
    if min(marginal)<=0 or sum(marginal)!=2*W:raise ValueError("bad marginals")
    S=0;scale=1<<24;energy_hi=F(0);pair_lo=0
    for term in kernel["terms"]:
        n=2*term["ell"];c=term["c"];ell=n//2
        S+=sum(comb(n,i)*z*z for i,z in enumerate(c))
        vertex_terms=[features(qi,n,c) for qi in q]
        for (i,j),v,wi in zip(edges,rel,weights):
            re,im=features(v,n,c);f=sum(x*y for x,y in zip(re,c))
            direct=sum(F(vertex_terms[i][0][k]*vertex_terms[j][0][k]+vertex_terms[i][1][k]*vertex_terms[j][1][k],comb(n,k)) for k in range(n+1))
            if direct!=f:raise ValueError("vertex inner product disagrees with relative quaternion kernel")
            pair_lo+=wi*f*scale//(W*sum(u*u for u in v)**ell)
        lower=[[0]*(n+1) for _ in range(2)]
        for z,wi,coefs in zip(q,marginal,vertex_terms):
            den=2*W*sum(u*u for u in z)**ell
            for out,vs in zip(lower,coefs):
                for k,v in enumerate(vs):out[k]+=v*wi*scale//den
        for k in range(n+1):
            energy_hi+=F(sum(max(abs(v[k]),abs(v[k]+len(q)))**2 for v in lower),scale**2*comb(n,k))
    face=F(pair_lo,scale*S);norm=energy_hi/S
    gap=(1+6*face)/7-norm
    if gap<=F(4,1000):raise ValueError("inconclusive edge obstruction")
    print(f"Verified {len(q)} rational frames, {len(edges)} strictly compatible weighted edges")
    print("Exact lower bound on the expected pair shift is strictly above 1/250")
    print(f"Outward bound as a float for display only: {float(gap):.12f}")
    return gap
if __name__=="__main__":
    from pathlib import Path
    import json
    root=Path(__file__).resolve().parent
    read=lambda n:json.loads((root/n).read_text())
    check(read("marked-edge.json"),read("pair-obstruction.json"))
