"""Independent, direct enumeration of all keep/remove decisions and placement orders for C9."""
from itertools import combinations,permutations

def cycle():
    # Remove adjacent anchors of a 9-cycle. The seven candidates form a path.
    V=set(range(7))
    adj={i:({i-1,i+1}&V) for i in V}
    b=(1,0,0,0,0,0,1)
    best=99;example=None;ns=0
    for k in range(8):
        for I in combinations(range(7),k):
            if any(y in adj[x] for x,y in combinations(I,2)):continue
            for perm in permutations(sorted(V-set(I))):
                old=set();n=0
                for i in perm:
                    n+=3-min(2,b[i]+len(old&adj[i]));old.add(i)
                ns+=1
                if n<best:best=n;example=(I,perm)
    if best!=9:raise ValueError("cycle test failed")
    print("C9 fixed-edge cost",best,"over",ns,"independent-set/order choices; optimum",example)

if __name__=="__main__":cycle()
