"""Verify the physical-axis parametrization as bivariate polynomial identities."""
from fractions import Fraction as F

def check():
    # Write c=2k/(1+k^2), s=(1-k^2)/(1+k^2).
    # After cross multiplication every claimed identity has bidegree <= (4,4).
    for k in range(5):
        for w in range(5):
            c=F(2*k,1+k*k);s=F(1-k*k,1+k*k)
            x=F(w*w-1,1+w*w);y=F(-2*w,1+w*w)
            a,b,u,v=1-k*w,k+w,-1-k*w,w-k
            n=a*a+b*b+u*u+v*v
            direction=(a*a+b*b-u*u-v*v,2*(b*u+a*v),2*(b*v-a*u))
            foot=(2*(b*v+a*u),2*(u*v-a*b),a*a-b*b-u*u+v*v)
            if direction!=(0,-n*c,n*s) or foot!=(n*x,n*y*s,n*y*c):
                raise ValueError("wrong quaternion parametrization")
    # Inclusion of the symmetric point w=sqrt(2)-1.
    if not (1+F(413,1000))**2<2<(1+F(415,1000))**2:raise ValueError("symmetric point omitted")
    print("Third-frame direction and tangency point: 25 exact unisolvent evaluations; symmetric point included")
if __name__=="__main__":check()
