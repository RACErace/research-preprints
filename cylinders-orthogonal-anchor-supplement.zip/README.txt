九根切线的接触图与正交锚边
2026-11-26  云端研究记录

仓库中的 cylinders-orthogonal-anchor.pdf 和归档中的 proof.md 给出全部论证。运行 python3 -B replay.py 可重放本轮计算。需要 Python 3.9+、小端系统和 GCC 或 Clang C++17 编译器。在当前目录运行 sha256sum -c SHA256SUMS 可校验归档内容。

本轮结果

* 任意一条已确定相对标架的 P 或 S 锚边，九线可行性可通过至多 9 个连续参数和有限的单线代数候选测试。一般全非平行目标问题至多为 11 参数；有平行对或仅指定一条正交接触边时至多为 10 参数。这是存在性代表的归约。九环的参数分支仍未解决。
* 对 62 点见证所用的具体正交接触边，四段第三切点角度、各自的对称像和一个一般第三标架盒无法承载目标九线。后者即使放宽线距至 2 sqrt(73/500) 仍不可行。
* 67 个标架、50 条严格分离边的正有理分布阻断同一全局核的仿射平移边判据。另有 7 个区间格盒构成 N=32 上包图的七团。两项均为方法边界，完整标记边可行性仍未决。

核验文件

place_graph.cpp  生成并覆盖全部 2^21 张七顶点标号图。对 1044 个同构类计算独立集选择、顺序优化、锚边附件和必为平行对的桥。check_cycle.py 以所有独立集/排列独立检查九环达到代价 9。人工几何引理和样本恢复的半代数依据见 proof.md。

triple.py 与 check_triple.cpp  在整数 Bernstein 盒上合并三个锚点的必要条件。subdivide.hpp 实现向下取整的 de Casteljau 二分。check_axes.py 以 25 个决定点交叉检验第三线参数化。moments.py 与 check_identity.py 独立计算高斯整数多项式。bernstein_homogeneous.py、bernstein_power.py 和 check_bands.py 复核全域成对核上界。

frame-c.json  一般第三标架盒，以 (2083,1997,-8766,-3850)/10000 为中心。
orth-zero.json  包含第三切点 -U 的闭区间。
triad-d.json  包含 w=0.145 的闭区间。
orth-quarter-point.json  包含 w=0.25 的闭区间。
orth-diagonal.json  包含第三切点 -(U+V)/sqrt(2) 的闭区间。
各文件的 geometry、h、local_lower 和整数特征记录足以重建证明。H 和第三标架使用文中指定的齐次尺度。replay.py 按 geometry 读取全部已认证区间，并要求五份核心证书都存在。

marked-edge.json  来自第三轮，提供同一 14 项全局正型核。check_pairs.py 对 pair-obstruction.json 的每条边同时检查相对四元数核和两端特征内积。check_obstruction.py 提供精确特征及与正交锚点严格分离的检查。check_outer_clique.py 遍历整个 N=32 盒覆盖，独立重建上包图七团的 21 条边。
replay.txt  最终整套重放日志。
Previous certificates: https://github.com/RACErace/research-preprints/blob/main/cylinders-skew-contact-supplement.zip

文献核查

Matić、Radoičić、Spomer 的 arXiv:2610.13972 当前标为 v2，2026-10-14 修订，第 13 节提出猜想。Glazyrin 的 arXiv:2611.00251 当前标为 v1，2026-10-30 提交，第 1 节明确八柱环插入仍开放，定理 1 给出的九柱半径上界为 0.726。2026-11-26 从云端对这两篇论文的题名、编号、九柱与八柱环插入进行了检索；未查到完整解答。两份公开仓库用 git ls-remote 复核，本次 HEAD 与前次记录一致。上一轮归档内保留详细原始文献记录。

https://arxiv.org/html/2610.13972v2#S13
https://arxiv.org/html/2611.00251v1#S1
https://github.com/maticivan/cylie/tree/c306097711481fcaf359bcda94f7c32fbab13273
https://github.com/alexey-glazyrin/cylinder_verifier/tree/82538c9cbf262fc30981d9bd7bc59512a5a35024
https://doi.org/10.1006/jcom.1997.0434
