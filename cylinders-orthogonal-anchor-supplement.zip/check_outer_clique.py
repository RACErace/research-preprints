"""A 7-clique of cells in the N=32 rigorous outer graph, not a physical packing."""
from itertools import product,combinations
from math import floor,ceil
from triple import SBOX,CBOX,H
from check_obstruction import intervals
U=1<<14
ROWS=((1,2,3,4),(-2,1,4,-3),(-3,-4,1,2),(-4,3,-2,1))
def relative(a,b):
    out=[]
    for row in ROWS:
        lo=hi=0
        for z,(x,y) in zip(row,b):
            u,v=a[abs(z)-1];vals=(u*x,u*y,v*x,v*y)
            l=min(vals);r=max(vals)
            if z>0:lo+=l;hi+=r
            else:lo-=r;hi-=l
        out.append((lo//U,-((-hi)//U)))
    return out
def possible(b):
    sq=[(0 if u<=0<=v else min(u*u,v*v),max(u*u,v*v)) for u,v in b]
    l,u=zip(*sq);n=H.numerator;d=H.denominator
    return ((d-n)*(u[1]+u[2])>=n*(l[0]+l[3]) and
            d*u[1]*u[2]>=n*(l[0]+u[1])*(u[2]+l[3]))
def check():
    intervals()
    h=[(0,0),(U,U)]+[(floor(a*U),ceil(b*U)) for a,b in (SBOX,CBOX)]
    v=[]
    for axis,i,j,k in product(range(2),range(32),range(32),range(32)):
        q=[(U*(-16+t)//16,U*(-15+t)//16) for t in (i,j,k)]
        q.insert(axis,(U,U))
        if possible(q) and possible(relative(h,q)):v.append(q)
    ids=(20826,17786,16613,14044,13751,11299,2799)
    if len(v)!=20860 or any(not possible(relative(v[min(i,j)],v[max(i,j)])) for i,j in combinations(ids,2)):
        raise ValueError("reported outer clique not reproduced")
    if any(possible(relative(q,q)) for q in v):raise ValueError("a cell permits two occupants")
    print("Outer graph N=32:",len(v),"candidate cells. Seven distinct cells pass all 21 interval edge tests")
    return [v[i] for i in ids]
if __name__=="__main__":check()
