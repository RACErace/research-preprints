// Enumerate every labelled 7-vertex contact graph via permutation orbits.
// Two lines are already fixed. Each free line costs 3, 2, or 1 parameters
// for 0, 1, or at least 2 earlier contact neighbors. An independent set is
// recovered from finite component representatives after the other sites.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>
using Seven=std::array<int,7>;
constexpr int ALL=(1<<7)-1;
int pc(int v){return __builtin_popcount(static_cast<unsigned>(v));}
int bit(int v){return __builtin_ctz(static_cast<unsigned>(v));}
struct Counter {
    std::array<unsigned long long,24> hist{};
    int types=0,choices=0,maximum=-1,example=0,choice=0;
};
std::array<std::array<int,7>,7> edge_bits(){
    std::array<std::array<int,7>,7> id{};int k=0;
    for(int j=1;j<7;j++)for(int i=0;i<j;i++)id[i][j]=id[j][i]=1<<(k++);
    return id;
}
std::vector<std::array<int,21>> actions(){
    auto id=edge_bits();Seven p{0,1,2,3,4,5,6};std::vector<std::array<int,21>> out;
    do{std::array<int,21> s;int k=0;for(int j=1;j<7;j++)for(int i=0;i<j;i++)s[k++]=id[p[i]][p[j]];out.push_back(s);}
    while(std::next_permutation(p.begin(),p.end()));return out;
}
std::vector<int> components(const Seven& adj){
    std::vector<int> c;int left=ALL;
    while(left){int current=left&-left,seen=0;
        while(current){int i=bit(current);current&=current-1;seen|=1<<i;current|=adj[i]&~seen;}
        c.push_back(seen);left&=~seen;
    }
    return c;
}
int bound(const Seven& adj,const std::vector<int>& independent,const Seven& ends,const Seven& parallel=Seven{},int root_parallel=0){
    std::array<int,128> dp{};
    for(int m=1;m<=ALL;m++){int best=99;
        for(int s=m;s;s&=s-1){int i=bit(s);int prev=m^(1<<i);
            int earlier=ends[i]+pc(adj[i]&prev);
            int cost=((root_parallel&(1<<i))||(parallel[i]&prev))?1:3-std::min(2,earlier);
            best=std::min(best,dp[prev]+cost);}
        dp[m]=best;
    }
    int best=99;for(int i:independent)best=std::min(best,dp[ALL^i]);
    return best;
}
void evaluate(const Seven& a,const std::vector<int>& stable,const Seven& b,int code,int key,Counter& x){
    int d=bound(a,stable,b);x.choices++;x.hist[d]++;
    if(d>x.maximum){x.maximum=d;x.example=code;x.choice=key;}
}
void connected_cases(const Seven& a,const std::vector<int>& stable,const std::vector<int>& comp,
                     int t,Seven& b,int code,int selected,Counter& x){
    if(t==int(comp.size())){evaluate(a,stable,b,code,selected,x);return;}
    for(int s=comp[t];s;s&=s-1){
        int i=bit(s);b[i]=1;connected_cases(a,stable,comp,t+1,b,code,selected|(1<<i),x);b[i]=0;}
}
// A component without a bridge needs two contacts to the anchored pair.
// Otherwise every leaf of its bridge-block tree needs at least one attachment.
std::vector<int> minimal_blocks(const Seven& a){
    Seven stripped=a;
    for(int i=0;i<7;i++)for(int j=i+1;j<7;j++)if(a[i]&(1<<j)){
        Seven cut=a;cut[i]^=1<<j;cut[j]^=1<<i;
        auto parts=components(cut);
        bool same=false;for(int p:parts)if((p&(1<<i))&&(p&(1<<j)))same=true;
        if(!same){stripped[i]^=1<<j;stripped[j]^=1<<i;}
    }
    std::vector<int> targets;
    for(int block:components(stripped)){
        int crossing=0;for(int s=block;s;s&=s-1)crossing+=pc(a[bit(s)]&~block);
        if(crossing==0){targets.push_back(block);targets.push_back(block);}
        else if(crossing==1)targets.push_back(block);
    }
    return targets;
}
void bridge_cases(const Seven& a,const std::vector<int>& stable,const std::vector<int>& blocks,
                 int t,Seven& b,int code,Counter& x){
    if(t==int(blocks.size())){int key=0;for(int i=6;i>=0;i--)key=3*key+b[i];evaluate(a,stable,b,code,key,x);return;}
    for(int s=blocks[t];s;s&=s-1){
        int i=bit(s);b[i]++;bridge_cases(a,stable,blocks,t+1,b,code,x);b[i]--;}
}
// Only graphs capable of reaching 10 in the connected relaxation enter here.
// Inspect all actual attachment multiplicities and charge a parallel bridge 1.
void forced_bridge(const Seven& a,const std::vector<int>& stable,const std::vector<int>& comp,int graph,Counter& x){
    x.types++;
    for(int code=0;code<2187;code++){
        Seven b{};int supported=0,t=code;
        for(int i=0;i<7;i++){b[i]=t%3;t/=3;if(b[i])supported|=1<<i;}
        if(std::any_of(comp.begin(),comp.end(),[&](int w){return !(w&supported);}))continue;
        if(bound(a,stable,b)<=9)continue;
        std::array<int,8> extended{};Seven p{};int bp=0;
        for(int i=0;i<7;i++)extended[i]=a[i]|(b[i]?128:0);
        extended[7]=supported;
        for(int j=1;j<8;j++)for(int i=0;i<j;i++)if(extended[i]&(1<<j)){
            if(j==7 && b[i]==2)continue;
            auto cut=extended;cut[i]^=1<<j;cut[j]^=1<<i;
            int todo=128,seen=0;
            while(todo){int k=bit(todo);todo&=todo-1;seen|=1<<k;todo|=cut[k]&~seen;}
            if(seen!=255){
                if(j==7)bp|=1<<i;else{p[i]|=1<<j;p[j]|=1<<i;}
            }
        }
        int d=bound(a,stable,b,p,bp);x.choices++;x.hist[d]++;
        if(d>x.maximum){x.maximum=d;x.example=graph;x.choice=code;}
    }
}
void report(const Counter& x,const char* name){
    std::cout<<name<<" isomorphism classes "<<x.types<<", cases checked "<<x.choices<<"\n";
    for(int i=0;i<=x.maximum;i++)if(x.hist[i])std::cout<<"dimension "<<i<<" cases "<<x.hist[i]<<"\n";
    std::cout<<"Maximum "<<x.maximum<<", representative graph integer "<<x.example<<", attachment code "<<x.choice<<"\n";
}
int main(){
    auto perms=actions();auto id=edge_bits();
    std::vector<unsigned char> seen(1<<21,0);
    Counter x,y,z;int covered=0;
    for(int code=0;code<(1<<21);code++){
        if(seen[code])continue;
        Seven a{};for(int j=1;j<7;j++)for(int i=0;i<j;i++)if(code&id[i][j]){a[i]|=1<<j;a[j]|=1<<i;}
        for(auto& p:perms){int result=0;for(int s=code;s;s&=s-1)result|=p[bit(s)];
            if(!seen[result]){seen[result]=1;covered++;}}
        std::array<bool,128> ok{};ok[0]=true;std::vector<int> stable{0};
        for(int m=1;m<=ALL;m++){
            int i=bit(m),rest=m^(1<<i);ok[m]=ok[rest]&&!(a[i]&rest);
            if(ok[m])stable.push_back(m);}
        auto count10=x.hist[10];Seven b{};auto comp=components(a);connected_cases(a,stable,comp,0,b,code,0,x);
        x.types++;if(x.hist[10]>count10)forced_bridge(a,stable,comp,code,z);auto blocks=minimal_blocks(a);bridge_cases(a,stable,blocks,0,b,code,y);y.types++;
    }
    if(covered!=(1<<21) || x.types!=1044)throw std::runtime_error("incomplete graph inventory");
    std::cout<<"Labelled graphs covered "<<covered<<"\n";
    report(x,"Connected");report(y,"Bridgeless after contraction");report(z,"Residual actual attachment cases with forced parallel bridges");
    if(x.maximum!=10 || y.maximum!=9 || z.maximum!=9 || z.types!=19 || z.choices!=28 || z.hist[7]!=2 || z.hist[8]!=6 || z.hist[9]!=20)throw std::runtime_error("unexpected graph bound");
}
