"""Exact six-neighbor norm threshold and boxes for the three reference frames."""
from fractions import Fraction as F
from itertools import product
from math import ceil, floor
from struct import pack
from moments import marker, chart
from check_obstruction import intervals

UNIT=1<<20
H=F(3661,25000)
T=F(27,400)
SBOX=(F(382683432,10**9),F(382683433,10**9))
CBOX=(F(923879532,10**9),F(923879533,10**9))

def mul(a,b):
    v=[x*y for x,y in product(a,b)]
    return min(v),max(v)

def boxes(doc,path):
    intervals()
    s0,s1=SBOX;c0,c1=CBOX
    kval=((1-s1)/c1,(1-s0)/c0)
    g=doc["geometry"]
    w0,w1=map(F,g["w"])
    eh=F(g["endpoint_error"]);ej=F(g["third_error"]);n=g["partition"]
    if not (0<=eh<F(1,10) and 0<=ej<F(1,10) and -1<=w0<=w1<=2 and 1<=n<=1000):
        raise ValueError("invalid third-frame boxes")
    def form(box,epsilon):
        return " ".join(str(y) for a,b in box for y in (floor((a-epsilon)*UNIT),ceil((b+epsilon)*UNIT)))
    threshold=F(doc["h"])
    data=[f"{n} {threshold.numerator} {threshold.denominator}",form([(0,0),(1,1),SBOX,CBOX],eh)]
    for j in range(n):
        u=w0+(w1-w0)*j/n;v=w0+(w1-w0)*(j+1)/n
        p,q=mul(kval,(u,v))
        box=((1-q,1-p),(kval[0]+u,kval[1]+v),(-1-q,-1-p),(u-kval[1],v-kval[0]))
        if "site" in g:
            site=list(map(F,g["site"]))
            if len(site)!=4 or max(abs(z) for z in site)>1 or max(abs(z) for z in site)<F(1,2):raise ValueError("invalid site")
            data.append(form([(z,z) for z in site],ej))
        else:data.append(form([(a/2,b/2) for a,b in box],ej))
    path.write_text("\n".join(data)+"\n")

def tensors(doc,kernel,path):
    if not (F(73,500)<=F(doc["h"])<=H) or F(doc["pair_upper"])!=F(-119,1000) or T!=(1+5*F(doc["pair_upper"]))/6:
        raise ValueError("wrong six-neighbor threshold")
    if [(v["ell"],v["c"]) for v in doc["terms"]]!=[(v["ell"],v["c"]) for v in kernel["terms"]]:
        raise ValueError("changed pair kernel")
    cut=F(doc["local_lower"])
    gap,s,c,_=marker(doc,cut)
    if cut<=0 or cut*cut<=T*c/s:
        raise ValueError("insufficient strict norm gap")
    degree=2*doc["degree"]
    with path.open("wb") as f:
        for k in range(4):
            for signs in product((-1,1),repeat=3):
                data=chart(gap,degree,k,signs);mag=max(abs(z) for z in data)
                exact_lower=[(z*(1<<51))//mag for z in data]
                f.write(pack("<i",degree));f.write(pack("<"+"q"*len(data),*exact_lower))
    return cut*cut*s/c
