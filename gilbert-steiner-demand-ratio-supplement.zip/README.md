# Demand ratios and branching in Gilbert–Steiner stars
Build the entire analytic note with `typst compile main.typ paper.pdf`. No numerical input is required. The published layout used the Libertinus fonts. The cost power ranges over (0,1); the fixed-dimension asymptotics are in the mass ratio, not in dimension. The lower and upper exponents differ by one half.
