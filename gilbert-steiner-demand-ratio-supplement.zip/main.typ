#set document(title: "Demand ratios and branching in Gilbert–Steiner stars")
#set page("a4", margin: (x: 23mm, top: 18mm, bottom: 17mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 10.55pt)
#set par(justify: true, leading: .61em, spacing: .62em)
#show heading.where(level: 2): set text(fill: rgb("#19354a"))
#align(center)[
  #text(20pt, weight: "bold", fill: rgb("#19354a"))[Demand ratios and branching#linebreak() in Gilbert–Steiner stars]
  #v(.4em)
  #text(9pt)[Research note · 26 November 2026]
]
#v(.6em)
#block(inset: 11pt, fill: rgb("#eef4f7"), radius: 3pt)[
  *Abstract.* Fix $d >= 3$. Over all choices of the cost power, the largest sink count in an optimal single-source star with demand ratio at most $K$ is between $c_d (log K)^((d-2)/2)$ and $C_d (1+log K)^((d-1)/2)$ for large $K$. The upper bound uses a cap constraint on every outgoing direction. The lower bound is a grid construction with exact force balance and exponentially unequal demands. In dimension three the bounds have order $sqrt(log K)$ and $log K$, respectively.
]

== Setting and result
For $0 < p < 1$, an edge of length $ell$ carrying mass $m$ costs $ell m^p$. In a single-source star, let the positive sink masses $q_i$ sum to one and let $u_i$ be the unit directions from the branch to the sinks. The source direction is $-e$. The balance and no-splitting criterion of Volz et al. [1], with all flows reversed, is
$ sum_i q_i^p u_i = e, quad norm(sum_(i in I) q_i^p u_i) <= (sum_(i in I) q_i)^p quad ("every" I). $
It applies with other normalisations by homogeneity. The degree of the branch is one more than the number of sinks. Write $M_d(K)$ for the supremum of sink counts among these optimal stars, varying $p$ and requiring $max_i q_i/min_i q_i <= K$.

*Theorem.* For each fixed $d >= 3$, there are positive constants $c_d,C_d$ such that for all sufficiently large $K$,
$ c_d (log K)^((d-2)/2) <= M_d(K) <= C_d (1+log K)^((d-1)/2). $
In fact, with $epsilon=1-p$, every such star has $O_d(min(epsilon^(-(d-1)/2),(1+log K)^((d-1)/2)))$ sinks. For every sufficiently small $epsilon>0$, there is one with at least $c_d epsilon^(-(d-2)/2)$ sinks and ratio $K=exp(1/epsilon)$.

== Upper bound: separation and concentration
For a pair of sinks, normalise their demands to $x<=y$ with $x+y=1$. Write $B=x^p+y^p$. The pair inequality implies
$ norm(u_i-u_j)^2 >= (B^2-1)/(x^p y^p) >= 2(1-2^(-epsilon)) >= epsilon. $
Indeed, $B >= 1$, $y^p >= y$ and $x <= 2^(-epsilon)x^p$. The last inequality follows from concavity of $2(1-2^(-epsilon))$ between $0$ and $1$.

For $p>=1/2$, the subset of all sinks except $i$ gives
$ 2q_i^p(e dot u_i) >= 1-(1-q_i)^(2p)+q_i^(2p) >= 2p q_i. $
The final difference starts at zero and has nonnegative derivative, by $x^(2p-1)+(1-x)^(2p-1)>=1$ on $(0,1)$. Thus $e dot u_i >= p q_i^epsilon$. Since $q_i>=1/(K n)$ and $1-p exp(-s)<=epsilon+s$ for $s>=0$, every $u_i$ lies in a chordal cap about $e$ of radius
$ R<=min(2, sqrt(2epsilon(1+log K+log n))). $

Packing chordally separated points with separation $sigma=sqrt(epsilon)$ in this cap yields at most $C'_d(1+R/sigma)^(d-1)$ points. The disjoint spherical caps of radius $sigma/2$ lie in the enlarged cap of radius $R+sigma/2$, and cap area is comparable to radius to the power $d-1$ on $[0,2]$, with the whole sphere used above radius $2$. Taking the full radius gives the stated power-dependent estimate, including $p<1/2$ using separation alone. The smaller radius gives $n<=C''_d(1+log K+log n)^b$ with $b=(d-1)/2$. Setting $z=n^(1/b)$ gives $z<=C'''_d(1+log K+b log z)$; for $z$ above a constant cutoff the logarithmic term can be absorbed in $z/2$. This proves the ratio bound.

== Lower bound: directions for the small sinks
Put $m=d-2$, $a=1/(4sqrt(m))$, and $L=floor(a/(16sqrt(m epsilon)))$, for small enough $epsilon$ that $L>=2$. Take the $n=L^m$ points of the mesh $delta=a/L$ in $[0,a)^m$ and lift each $x_i$ to a unit vector $v_i=(sqrt(1-norm(x_i)^2),x_i)$ in $bb(R)^(m+1)$. Then $delta>=16sqrt(m epsilon)$ and $v_i dot v_j>=15/16$.

In any $k$-point subset with $k>=2$, at most half the points are within projected Euclidean distance $r=delta k^(1/m)/8$ of each fixed point. If $k^(1/m)<4$ there is only the fixed point itself. Otherwise the coordinate box bound is $(1+2r/delta)^m <=(k^(1/m)/2)^m<=k/2$. The lift cannot reduce projected separation. Summing the squared distances of ordered pairs and using the unit-vector variance identity therefore gives
$ 1-norm(frac(1,k)sum_(i in I) v_i)^2 >= delta^2 k^(2/m)/256. $
This lower bound, even after multiplying by $1/2$, exceeds $2epsilon log k$: use $delta^2>=256m epsilon$ and $k^(2/m)>=(2 exp(1)/m)log k$, from $exp(s)>=exp(1) s$ for $s>=0$.

== Lower bound: exact balance and the subset checks
Give a heavy sink unit mass along a unit vector $E$ perpendicular to the transverse space. Give each small sink mass $t=exp(-1/epsilon)$, putting $x=t^p$, $T=n t$ and
$ f(y)=(1+y)^(2p), quad ell=(f(T)-1)/T. $
Write $u_i=A_i E+sqrt(1-A_i^2)v_i$ with $A_i in [0,1/2]$ and set $S=sum_i x u_i$. Choose the $A_i$ to satisfy
$ 2 A_i+u_i dot S=ell t^epsilon quad (1<=i<=n). $
This is a fixed point of the continuous map whose $i$th coordinate is $(ell t^epsilon-u_i dot S)/2$. Since $ell -> 2$, $t^epsilon=exp(-1)$ and $norm(S)<=n t^p ->0$ uniformly on the cube as $epsilon ->0$, this map sends the cube into itself for sufficiently small $epsilon$. Brouwer's theorem supplies a fixed point.

For a set $I$ of small sinks put $y=|I|t$ and $S_I=sum_(i in I) x u_i$. Multiplying the fixed-point equations by $x$ and summing over $I$ gives exactly
$ norm(E+S_I)^2-f(y)=1+ell y-f(y)-sum_(i in I, j in.not I) x^2 (u_i dot u_j). $
The first three terms are at most $y(T-y)$: $y^2-f(y)$ is convex since $f''<=2$ for $p$ close to $1$, and comparison with its chord gives the inequality. Every inner product in the cross term is at least $(3/4)(15/16)>exp(-2)=t^(2epsilon)$, so the cross term is at least $y(T-y)$. This proves the no-splitting test for sets including the heavy sink. For the full set the identity gives equality; choose the source direction opposite $E+S$, which now has the required norm $(1+T)^p$.

For sets of only small sinks, the squared pair distances of the $u_i$ are at least half those of the $v_i$. In fact, writing $B_i=sqrt(1-A_i^2)$, the transverse distance squared is $(B_i-B_j)^2+B_i B_j norm(v_i-v_j)^2$ with $B_i B_j>=3/4$. The preceding variance estimate then gives $1-norm(frac(1,k)sum_(i in I)u_i)^2>2epsilon log k>=1-k^(-2epsilon)$ for $k>=2$. The singleton and empty sets pass directly. This proves all inequalities and hence global optimality.

Place every sink at its unit direction and the source at distance one in its indicated direction. The transverse coordinates are strictly positive in the first transverse component, and the $v_i$ are distinct, so all terminals and the branch are distinct. Since $n=L^m$ has order $epsilon^(-m/2)$ and $1/t=exp(1/epsilon)$, this proves the lower bound at every sufficiently large prescribed ratio $K$.

== Scope and references
These bounds improve the ratio dependence in [4] at fixed dimension and quantify the divergence demonstrated in [5]. They do not settle the half-power gap, and concern single-source stars rather than general many-source optima. The general dependence on dimension and cost power is discussed in [2, 3]. AI assistance was used in the research and preparation.

[1] Volz, Brazil, Ras, Swanepoel and Thomas. #link("https://arxiv.org/html/0909.4270v2")[The Gilbert Arborescence Problem], §§3, 5 (2012 version).

[2] Cherkashin. #link("https://arxiv.org/html/2507.13532v1#S6")[On branching points in the Gilbert–Steiner problem], §6 (2025).

[3] Teplitskaya. #link("https://arxiv.org/html/2611.03403v1#S1")[Open problems from the Length Optimization event at MDS 2026], §1 (2026).

[4] #link("https://github.com/RACErace/research-preprints/blob/main/gilbert-steiner-comparable.pdf")[The dimension scale of equal-demand Gilbert–Steiner stars] (2026).

[5] #link("https://github.com/RACErace/research-preprints/blob/main/gilbert-steiner-unbounded.pdf")[Unbounded branching degree in three-dimensional Gilbert–Steiner flows] (2026).
