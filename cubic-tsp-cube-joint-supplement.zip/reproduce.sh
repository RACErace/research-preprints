#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
scratch=$(mktemp -d)
trap 'rm -r -- "$scratch"' EXIT
sha256sum -c --quiet SHA256SUMS
python3 -B spring_base.py > "$scratch/curve.log"
diff -u curve.log "$scratch/curve.log"
python3 -B verify_joint.py > "$scratch/joint.log"
diff -u joint.log "$scratch/joint.log"
c++ -O2 -std=c++17 verify_boxes.cpp -o "$scratch/verify_boxes"
for n in 7 8; do
    gzip -dc "n$n.boxes.gz" | "$scratch/verify_boxes" > "$scratch/boxes$n.log"
    diff -u "boxes$n.log" "$scratch/boxes$n.log"
done
python3 -B prior-small/verify_finite.py > "$scratch/finite.log"
diff -u prior-small/finite.log "$scratch/finite.log"
cat "$scratch/curve.log" "$scratch/joint.log" "$scratch/boxes7.log" "$scratch/boxes8.log" "$scratch/finite.log"
