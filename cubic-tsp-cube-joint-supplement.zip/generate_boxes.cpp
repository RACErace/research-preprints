// Cover normalized point configurations by octants, pinned faces, and sub-boxes.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <map>
#include <set>
#include <vector>
using namespace std;
// Positive tokens are one plus a tour index, zero applies the parity corner lemma,
// and negative tokens split a single scalar coordinate at its midpoint.
#ifndef SIZE_N
#define SIZE_N 7
#endif
constexpr int N=SIZE_N, D=128, U=1<<16, TARGET=4*U;
static_assert(N>=7&&N<=9);
constexpr int TourCount=N==7?360:(N==8?2520:20160);
using V=array<int,3>;
using Order=array<int,N>;
struct Box{V l,h;}; using Boxes=array<Box,N>;
using Pattern=array<int,N>;
const array<array<int,6>,8> anchors={{{0,1,0,1,0,1},{0,1,0,1,0,2},{0,1,0,1,2,3},
 {0,1,0,2,0,3},{0,1,0,2,1,2},{0,1,0,2,1,3},{0,1,0,2,3,4},{0,1,2,3,4,5}}};
using Perm=array<int,64>;
vector<Order> tours;
vector<Perm> group;
vector<int> wt;
struct Counters{uint64_t edge=0,cycle=0,local=0,mixed=0,fail=0,split=0;int deepest=0;} count_all;
int depth_limit=30, trial_cycles=28;
vector<int> proof;
int rawcost(V a,V b){int d=0;for(int i=0;i<3;++i){int g=a[i]-b[i];d+=g*g;}return wt[d];}
void init(){
 for(int s=0;s<=3*D*D;++s){
    using Wide=unsigned __int128;
    Wide den=Wide(8)*D*D*D*D*D*D, num=Wide(U)*U*s*s*s;
    int w=int(sqrtl((long double)num/(long double)den));
    while(Wide(w)*w*den<num)++w;
    while(w>0&&Wide(w-1)*(w-1)*den>=num)--w;
    wt.push_back(w);
 }
 Order t{};for(int i=0;i<N;++i)t[i]=i;
 do{if(t[1]<t[N-1])tours.push_back(t);}while(next_permutation(t.begin()+1,t.end()));
 V axis{0,1,2};
 do{for(int flip=0;flip<8;++flip){
    Perm g{};
    for(int i=0;i<64;++i){int val=0;for(int j=0;j<3;++j){
      int s=(i>>(2*axis[j]))&3;
      val|=((flip>>j)&1?3-s:s)<<(2*j);
    }g[i]=val;}group.push_back(g);
 }}while(next_permutation(axis.begin(),axis.end()));
}
Boxes decode(const Pattern& codes){
 Boxes boxes{};
 for(int i=0;i<N;++i)for(int a=0;a<3;++a){
   int e=(codes[i]>>(2*a))&3;
   boxes[i].l[a]=array<int,4>{0,0,D/2,D}[e];
   boxes[i].h[a]=array<int,4>{0,D/2,D,D}[e];
 }
 return boxes;
}
int color(const Box& box){
 int par=0;
 for(int a=0;a<3;++a){
    if(box.h[a]<=D/4)continue;
    if(box.l[a]>=3*D/4)par^=1;
    else return -1;
 }
 return par;
}
struct Node{
 int M[N][N]{}, pt[N]{}, w[N][N][8][8]{};
 V corners[N][8]{};
 array<pair<int,int>,TourCount> candidates{};
 int ntest=0;
 Node(const Boxes& boxes){
  for(int i=0;i<N;++i){
   const Box& b=boxes[i];corners[i][0]=b.l;pt[i]=1;
   for(int k=0;k<3;++k)if(b.l[k]!=b.h[k]){
    int pre=pt[i];for(int h=0;h<pre;++h){corners[i][pre+h]=corners[i][h];corners[i][pre+h][k]=b.h[k];}pt[i]*=2;
   }
  }
  for(int i=0;i<N;++i)for(int j=0;j<i;++j){
   int bound=0;
   for(int a=0;a<pt[i];++a)for(int b=0;b<pt[j];++b){
     int c=rawcost(corners[i][a],corners[j][b]);w[i][j][a][b]=w[j][i][b][a]=c;bound=max(bound,c);
   } M[i][j]=M[j][i]=bound;
  }
  for(int j=0;j<int(tours.size());++j){
    int z=0;const auto& t=tours[j];for(int k=0;k<N;++k)z+=M[t[k]][t[(k+1)%N]];
    candidates[j]={z,j};
  }
  if(trial_cycles<TourCount)nth_element(candidates.begin(),candidates.begin()+trial_cycles,candidates.end());
  sort(candidates.begin(),candidates.begin()+trial_cycles);
 }
 int worst(const Order& tour,int stop,int *witness=nullptr){
    int off=0;for(int i=1;i<N;++i)if(pt[tour[i]]<pt[tour[off]])off=i;
    Order t{};for(int i=0;i<N;++i)t[i]=tour[(off+i)%N];
    int best=0;
    for(int a=0;a<pt[t[0]];++a){
        int pre[8],nex[8],arg[N][8]{};
        for(int b=0;b<pt[t[1]];++b)pre[b]=w[t[0]][t[1]][a][b];
        for(int k=2;k<N;++k){
            for(int c=0;c<pt[t[k]];++c){
                int val=-1,idx=0;
                for(int b=0;b<pt[t[k-1]];++b){int x=pre[b]+w[t[k-1]][t[k]][b][c];if(x>val){val=x;idx=b;}}
                nex[c]=val;if(witness)arg[k][c]=idx;
            }
            copy(nex,nex+pt[t[k]],pre);
        }
        for(int b=0;b<pt[t[N-1]];++b){
            int z=pre[b]+w[t[N-1]][t[0]][b][a];
            if(z>best){best=z;if(witness){
                witness[t[0]]=a;int v=b;
                for(int k=N-1;k>=1;--k){witness[t[k]]=v;v=arg[k][v];}
            }}
            if(best>stop)return best;
        }
    }
    return best;
 }
};

bool solve(const Boxes& b,int depth){
 count_all.deepest=max(count_all.deepest,depth);
 int c=color(b[0]);
 if(c>=0&&all_of(b.begin()+1,b.end(),[c](const Box& a){return color(a)==c;})){proof.push_back(0);++count_all.local;return true;}
 Node node(b);
 if(node.candidates[0].first<TARGET){proof.push_back(node.candidates[0].second+1);++count_all.edge;return true;}
 for(int k=0;k<trial_cycles;++k){
   const auto& t=tours[node.candidates[k].second];
   if(node.worst(t,TARGET-1)<TARGET){proof.push_back(node.candidates[k].second+1);++count_all.cycle;return true;}
 }
 if(depth>=depth_limit){++count_all.fail;return false;}
 int amax=-1,imax=-1,width=0;
 for(int i=0;i<N;++i)for(int a=0;a<3;++a)if(b[i].h[a]-b[i].l[a]>width){
    width=b[i].h[a]-b[i].l[a];imax=i;amax=a;
 }
 if(width<=1){++count_all.fail;return false;}
 Boxes left=b,right=b;int mid=(b[imax].h[amax]+b[imax].l[amax])/2;
 left[imax].h[amax]=right[imax].l[amax]=mid;
 proof.push_back(-1-3*imax-amax);++count_all.split;
 bool ok1=solve(left,depth+1);bool ok2=solve(right,depth+1);return ok1&&ok2;
}
int main(int argc,char** argv){
 if(argc!=2){cerr<<"Usage: generate output.txt\n";return 2;}
 ofstream out(argv[1]);if(!out)throw runtime_error("cannot open output");
 out<<"MDS41BOX1 "<<N<<'\n';
 init();set<Pattern> seen;uint64_t roots=0,ok=0;
 for(int ai=0;ai<int(anchors.size());++ai){
  const auto& how=anchors[ai];int base[N][3]{};
  for(int k=0;k<3;++k){base[how[2*k]][k]=-1;base[how[2*k+1]][k]=1;}
  for(int mask=0;mask<(1<<(3*N-6));++mask){
   int bit=0;Pattern codes{};
   for(int i=0;i<N;++i)for(int a=0;a<3;++a){
     int d=base[i][a];int s=d?(d<0?0:3):1+((mask>>bit++)&1);
     codes[i]|=s<<(2*a);
   }
   sort(codes.begin(),codes.end());
   if(seen.count(codes))continue;
   for(const auto& g:group){Pattern p{};for(int i=0;i<N;++i)p[i]=g[codes[i]];sort(p.begin(),p.end());seen.insert(p);}
   ++roots;proof.clear();
   if(!solve(decode(codes),0))throw runtime_error("unresolved box");
   ++ok;for(int code:codes)out<<code<<' ';
   for(int tok:proof)out<<tok<<' ';out<<'\n';
  }
  cout<<"anchor "<<ai<<" roots "<<roots<<" ok "<<ok<<" edge "<<count_all.edge
      <<" cycle "<<count_all.cycle<<" local "<<count_all.local<<" splits "<<count_all.split
      <<" failed_leaves "<<count_all.fail<<" max_depth "<<count_all.deepest<<endl;
 }
 out.flush();if(!out)throw runtime_error("incomplete output");
}
