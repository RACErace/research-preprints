# MDS 2026 问题 4.1 · 换边与连续坐标证书

研究预印本，日期 2026-11-26。主稿为仓库中的 cubic-tsp-cube-joint.pdf，排版源文件为 proof-joint.md。

本次结果以边长立方和为单位。任意点数的上界是
U=(3(424/25)+2(1533√6/221))/5 ≈ 16.972502761423733。
固定环排序总成本的上确界却恰为 K=1533√6/221。
七点、八点连续坐标的上确界同为 8√2，且互异点集不能达到。结合此前至六点证书，严格反例至少九点。
这些结论给出计算机辅助证明，一般等式仍待判定。

## 完整复核

在解压目录内运行以下命令。主结果需要 Python 3.9+ 标准库、bash、gzip 和支持 unsigned __int128 的 C++17 编译器。附录 C 的复核还需要 NumPy。脚本使用临时目录，审核各核验器的退出状态并逐行比对已保存的输出。无需联网。

~~~bash
bash reproduce.sh
~~~

如只重放本次新结果，可独立运行以下命令。

~~~bash
python3 -B spring_base.py
python3 -B verify_joint.py
g++ -std=c++17 -O2 verify_boxes.cpp -o /tmp/mds41_verify_boxes
gzip -dc n7.boxes.gz | /tmp/mds41_verify_boxes
gzip -dc n8.boxes.gz | /tmp/mds41_verify_boxes
~~~

- spring_base.py 保存两条原型、顶层环、角点的有理时间和精确单弦界核验器。
- verify_joint.py 重建相邻块窗口及全部自适应几何盒证书，检查两种取等类型、探测点、三个换边界、全局合并后的常数，以及从另一种块得到的明确障碍弦。
- generate_boxes.cpp 生成七点、八点的盒乘积覆盖。verify_boxes.cpp 使用不同的根计数、对称群生成、整数边权计算和动态规划，独立重放。
- n7.boxes.gz 与 n8.boxes.gz 保存证明森林。首行为版本标记 MDS41BOX1 及点数。每行的前 n 个整数是根盒码，之后按前序遍历编码二叉树。负数 -1-3i-k 平分第 i 点第 k 坐标，零采用四分之一角簇引理，正数为巡回编号（编号从 1 开始）。巡回先固定 0 首点，按字典序枚举其余排列，并保留第二点编号小于末点编号的方向。
- prior-small/ 保存此前四至六点核验器及证书，仅用于重放九点门槛的低点数部分。
- 四个 .log 文件和 prior-small/finite.log 是实际复核输出。SHA256SUMS 记录所有源码、证书及报告源文件的哈希。配套 PDF 的哈希记入 PDF-SHA256.txt。

## 从头生成七点、八点证明森林

下列命令使用生成器默认规则。生成器负责选择巡回与分叉，核验器没有使用生成器的搜索逻辑。单个证书文本比较用 gzip -dc 解压当前证书即可。

~~~bash
g++ -std=c++17 -O3 -DSIZE_N=7 generate_boxes.cpp -o /tmp/mds41_g7
/tmp/mds41_g7 /tmp/mds41_new7.txt
g++ -std=c++17 -O3 -DSIZE_N=8 generate_boxes.cpp -o /tmp/mds41_g8
/tmp/mds41_g8 /tmp/mds41_new8.txt
~~~

## 一手来源

- [MDS 开放问题 4.1](https://arxiv.org/html/2611.03403v1#S4)
- [Balogh–Clemen–Dumitrescu](https://arxiv.org/abs/2310.02839)
- [Gordeev，含定理 1.7 与附录 A](https://arxiv.org/html/2603.22010v1)
- [Malykhin–Shchepin，Spring](https://arxiv.org/html/2103.07344v2#S3.SS2)
