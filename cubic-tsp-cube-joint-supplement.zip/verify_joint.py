"""Finite certificate for the localization and simultaneous 2-opt proof.
Uses exact arithmetic and closed spatial/time boxes. Run with Python 3.9+.
The fixed recursive curve is defined in spring_base.py.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt

import spring_base as curve

B = F(424, 25)
PROBE = F(2473, 16352)
RIGHT = F(570, 1000)
MIN_LENGTH = F(1, 32)
WEIGHT_SCALE = 10**6


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def add(p, q):
    return tuple(x + y for x, y in zip(p, q))


def expand(cells):
    """Double the space resolution and refine each time slot into eight."""
    return tuple((add(tuple(2*x for x in pos), offset), child)
                 for pos, state in cells for offset, child in curve.parts(state))


def reverse(cells):
    return tuple((p, (kind, frame, not backwards))
                 for p, (kind, frame, backwards) in reversed(cells))


@lru_cache(None)
def normalize(cells):
    """Translate the first lower corner to 0. Express frames in its own axes.
    Under a signed permutation the displacement of cube lower corners,
    like that of their centers, transforms by the linear part.
    """
    start, (_, frame, _) = cells[0]
    inverse = tuple(frame.index(i) for i in range(8))
    corners = curve.CORNERS
    zero = corners[inverse[0]]
    basis = []
    for j in range(3):
        unit = tuple(int(i == j) for i in range(3))
        vertex = corners[inverse[corners.index(unit)]]
        basis.append(tuple(x-y for x, y in zip(vertex, zero)))

    def changed_cell(cell):
        p, (kind, h, rev) = cell
        lower = tuple(sum((p[j]-start[j])*basis[j][k] for j in range(3))
                      for k in range(3))
        return lower, (kind, tuple(inverse[i] for i in h), rev)
    return tuple(map(changed_cell, cells))


@lru_cache(None)
def windows(length):
    require(2 <= length <= 9, "unsupported window length")
    pairs = set()
    sequences = [curve.parts((k, curve.ID, r)) for k in (0, 1) for r in (False, True)]
    sequences.append(curve.TOP + (curve.TOP[0],))
    for seq in sequences:
        for j in range(len(seq)-1):
            pairs.add(normalize(seq[j:j+2]))
    queue = list(pairs)
    while queue:
        pair = normalize(expand(queue.pop())[7:9])
        if pair not in pairs:
            pairs.add(pair)
            queue.append(pair)
    result = set()
    for pair in pairs:
        children = expand(pair)
        for j in range(8):
            result.add(normalize(children[j:j+length]))
    ring = curve.TOP*2
    for j in range(8):
        result.add(normalize(ring[j:j+length]))
    return frozenset(result)


@lru_cache(None)
def sharp_corners(pair):
    (p, a), (q, b) = pair
    hits = []
    for c in curve.CORNERS:
        for e in curve.CORNERS:
            s = curve.corner_time(a, c)
            t = 1 + curve.corner_time(b, e)
            x, y = add(p, c), add(q, e)
            dist2 = sum((i-j)**2 for i, j in zip(x, y))
            if dist2 and dist2**3 == curve.D_SQUARED*(t-s)**2:
                hits.append((s, t, x, y))
    return tuple(hits)


def locate_vertex(seq, time, point):
    """Time in a unit prototype. Point must be a corner of its selected child."""
    slot = int(8*time)
    p, state = seq[slot]
    local = tuple(2*x-a for x, a in zip(point, p))
    require(local in curve.CORNERS, "point not a child vertex")
    require(slot + curve.corner_time(state, local) == 8*time, "incorrect vertex time")


def verify_anchors():
    t1, t2 = F(145, 2044), F(183, 1022)
    witnesses = ((t1, t2, (F(1,2), 0, F(1,2)), (0, 1, 0)),
                 (F(1823,4088), F(2265,4088), (1, F(1,2), 1), (0, 1, F(1,2))))
    for s, t, x, y in witnesses:
        locate_vertex(curve.RULES[0], s, x)
        locate_vertex(curve.RULES[0], t, y)
        dist2 = sum((i-j)**2 for i,j in zip(x,y))
        require(dist2**3 == curve.D_SQUARED*(t-s)**2 and t-s == F(221,2044),
                "sharp A interval")
    require(any(st[0] == 0 for _, st in curve.RULES[1]), "missing A child in B")

    cases = sorted(pair for pair in windows(2) if sharp_corners(pair))
    require(len(cases) == 2, "unclassified adjacent equality context")
    expected_states = {(0, True, 1, False), (1, True, 0, False)}
    for pair in cases:
        (p, (k, g, r)), (q, (l, h, v)) = pair
        expected_states.remove((k, r, l, v))
        require(p == (0,0,0) and q == (0,0,-1), "positions of the sharp pair")
        hit, = sharp_corners(pair)
        s,t,x,y = hit
        expected = ((0,0,1),(1,1,-1)) if k == 1 else ((1,1,1),(0,0,-1))
        require((x,y) == expected and (s,t) == (F(290,511), F(732,511)), "sharp pair")
        require(normalize(reverse(pair)) in cases, "time reversal does not identify the two cases")
        if k == 1:
            midpoint = tuple(F(i+j, 2) for i,j in zip(x,y))
            locate_vertex(curve.parts(pair[0][1]), PROBE, midpoint)
    require(not expected_states, "missing sharp pair")
    print("sharp A intervals 2; adjacent equality types 2; probe time", PROBE)


def close_to_corner(cell, vertex, side):
    return all(32*max(abs(x-side*y), abs(x+1-side*y)) <= side
               for x,y in zip(cell[0], vertex))


def classify_high():
    roots = set()
    for seq in windows(5):
        for lag in range(5):
            first, last = normalize((seq[0], seq[lag]))
            roots.add((first, last, lag))
    rectangles = hits = deepest = 0
    for first, last, lag in sorted(roots):
        exact = sharp_corners((first,last)) if lag == 1 else ()
        pending = [(0, 0, first, lag, last)]
        while pending:
            depth, i, a, j, b = pending.pop()
            rectangles += 1
            deepest = max(deepest,depth)
            time, side = 8**depth, 2**depth
            if 2*(j+1-i) < time or j-1-i > 4*time:
                continue
            if exact and 566*time <= 1000*i and 1000*(i+1) <= 570*time \
                     and 1430*time <= 1000*j and 1000*(j+1) <= 1434*time:
                _, _, x, y = exact[0]
                if close_to_corner(a,x,side) and close_to_corner(b,y,side):
                    hits += 1
                    continue
            max_sq = sum((abs(x-y)+1)**2 for x,y in zip(a[0], b[0]))
            min_time = max(F(time,2), j-1-i)
            if max_sq**3 <= B**2 * min_time**2:
                continue
            require(depth < 12, "unresolved localization rectangle")
            for k, child_a in enumerate(expand((a,))):
                for l, child_b in enumerate(expand((b,))):
                    pending.append((depth+1, 8*i+k, child_a, 8*j+l, child_b))
    print("localization: windows", len(windows(5)), "root pairs", len(roots),
          "rectangles", rectangles, "accepted high boxes", hits, "max depth", deepest)


@lru_cache(None)
def contexts_before_probe():
    contexts = set()
    seqs = set(windows(9))
    seqs.update(normalize(reverse(s)) for s in tuple(seqs))
    for seq in seqs:
        # Put the high pair first to normalize relative to its first spatial frame.
        rotated = normalize(seq[7:]+seq[:7])
        if rotated[0][1][0] == 1 and sharp_corners(rotated[:2]):
            contexts.add(rotated[2:]+rotated[:2])
    return contexts


@lru_cache(None)
def rounded_weight(squared, den, upper):
    numerator = WEIGHT_SCALE**2 * squared**3
    divisor = den**6
    w = isqrt(numerator // divisor)
    return w + int(upper and w*w*divisor < numerator)


def box_dist2(a,b,upper):
    if upper:
        return sum(max(abs(l-y), abs(h-x))**2 for (l,h),(x,y) in zip(a,b))
    return sum(max(0,l-y,x-h)**2 for (l,h),(x,y) in zip(a,b))


def corner_box(pos, vertex):
    require(all(c in (x,x+1) for x,c in zip(pos,vertex)), "invalid endpoint corner")
    return tuple((32*x,32*x+1) if c == x else (32*c-1,32*c)
                 for x,c in zip(pos,vertex))


def scale_box(box, factor):
    return tuple((x*factor, y*factor) for x,y in box)


def spatial_box(cell, unit):
    return tuple((x*unit,(x+1)*unit) for x in cell[0])


def verify_partner(rate, maximum):
    roots = set()
    for seq in contexts_before_probe():
        _, _, a, b = sharp_corners(seq[7:])[0]
        left = corner_box(seq[7][0], a)
        right = corner_box(seq[8][0], b)
        for i in range(-7,1):
            roots.add((left, right, i, seq[i+7], seq[7]))
    rectangles = repaired = deepest = 0
    for left, right, start_slot, first, last in sorted(roots):
        pending = [(0,start_slot,first,0,last)]
        while pending:
            depth,i,x,j,y = pending.pop()
            rectangles += 1
            deepest = max(deepest,depth)
            time, side = 8**depth, 2**depth
            if i > PROBE*time or j+1 < PROBE*time or j > RIGHT*time:
                continue
            if j-1-i > maximum*time or j+1-i < MIN_LENGTH*time:
                continue
            dt = max(time*MIN_LENGTH, j-1-i)
            upper_sq = sum((abs(a-b)+1)**2 for a,b in zip(x[0],y[0]))
            if rate > 0 and upper_sq**3 <= rate**2 * dt**2:
                continue

            den = max(32,side)
            a = scale_box(left, den//32)
            b = scale_box(right, den//32)
            c = spatial_box(x, den//side)
            e = spatial_box(y, den//side)
            new_upper = (rounded_weight(box_dist2(a,c,True),den,True)
                         +rounded_weight(box_dist2(b,e,True),den,True))
            old_j = max(F(rounded_weight(box_dist2(c,e,False),den,False), WEIGHT_SCALE),
                        rate*dt/time)
            if F(new_upper, WEIGHT_SCALE) + 1 <= B*F(86,100) + old_j:
                repaired += 1
                continue
            require(depth < 10, "unresolved partner rectangle")
            for k, cx in enumerate(expand((x,))):
                for l, cy in enumerate(expand((y,))):
                    pending.append((depth+1,8*i+k,cx,8*j+l,cy))
    print("partner: upper duration", maximum, "rate threshold", rate,
          "windows", len(contexts_before_probe()), "root pairs", len(roots),
          "rectangles", rectangles, "repair terminals", repaired, "max depth", deepest)


def verify_secondary_chord():
    """Explicit obstacle to changing the localization threshold to 16.95."""
    pair = normalize(expand(curve.TOP)[6:8])
    require(not sharp_corners(pair), "secondary chord must use another pair")
    s, t = F(3287,4088), F(675,511)
    x, y = (1,F(1,2),1), (0,-1,0)
    for (pos,state), time, point in zip(pair, (s,t-1), (x,y)):
        local = tuple(v-o for v,o in zip(point,pos))
        locate_vertex(curve.parts(state),time,local)
    sq = sum((a-b)**2 for a,b in zip(x,y))
    rate_sq = sq**3 / (t-s)**2
    require(F(339,20)**2 < rate_sq == F(17*8687**2,2113**2) < B**2, "secondary slope")
    print("secondary chord: squared slope", rate_sq)


def verify_constants():
    # Exact inequalities used for the tiny-gap argument and charging.
    require(curve.D_SQUARED < 17**2 and F(17,64) < F(13,20)**3, "tiny-gap root")
    require(F(6,4) < F(49,40)**2, "distance to center")
    require(B*F(86,100) > 1+2*F(15,8)**3, "tiny-gap gain")
    require(0 < curve.D_SQUARED-B**2 and curve.D_SQUARED < (B+F(4,125))**2,
            "slope difference")
    upper_d = F(4,125)
    require(upper_d < F(5,117) and upper_d*F(26,3) < B-15
            and upper_d*F(13,15) < B-F(84,5), "charging coefficients")
    require(F(1434,1000)-PROBE < F(13,10), "probe distance")
    require(F(13,2)+F(13,10) < 8, "hulls shorter than the full circle")


if __name__ == "__main__":
    verify_anchors()
    verify_secondary_chord()
    classify_high()
    verify_partner(0,F(3,10))
    verify_partner(15,F(3))
    verify_partner(F(84,5),F(13,2))
    verify_constants()
