
#set document(title: "The leading energy correction for irrigation of a sphere")
#set page("a4", margin: (x: 25mm, top: 20mm, bottom: 20mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 10.7pt)
#set par(justify: true, leading: .60em, spacing: .73em)
#set heading(numbering: "1.")
#show heading: set text(fill: rgb("#173c52"))
#align(center)[
  #text(24pt, weight: "bold", fill: rgb("#173c52"))[The leading energy correction \ for irrigation of a sphere]
  #v(.3em)
  #text(10pt)[Research preprint (AI-assisted) · 26 November 2026]
]
#block(inset: 10pt, fill: rgb("#edf3f7"), radius: 3pt)[
  *Abstract.* We prove that the minimum power-law irrigation energy from the center of the unit sphere in dimension $d$ to its normalized surface measure is $1 + frac(d-1,2) (1-p) log(1 \/ (1-p)) + O_d(1-p)$ as $p$ approaches $1$. Every optimizer has mean excess path length of order $1-p$. For the circle, this quantifies the limiting regime proposed in the MDS 2026 question, without identifying the minimizing networks.
]
= Setting and results
<setting-and-results>
For $d gt.eq 2$, let $sigma$ be normalized surface measure on the unit
sphere $S^(d - 1)$. A traffic plan $bb(P)$ is a probability measure on
$1$-Lipschitz paths $gamma$ starting at the origin with terminal
distribution $sigma$. Finite-length paths can be parametrized by arclength,
stationary after arrival. This leaves energy and length unchanged. Write $ell (gamma)$ for
length, $y (gamma)$ for the terminal point and
$ theta (x) = bb(P) { gamma : x in "im" gamma } , #h(2em) D (bb(P)) = integral (ell (gamma) - 1) thin d bb(P) (gamma) . $
The energy is
$ cal(E)_p (bb(P)) = integral integral theta (gamma (t))^(p - 1) lr(|dot(gamma) (t)|) thin d t thin d bb(P) (gamma) . $
The quantity $E_p$ is its infimum. We use the Lagrangian convention of
Pegon [2] and of the MDS problem list [1, §2.2], so
occupation counts repeated traversals, even though the mass $theta$
counts a path only once.

#block[
*Theorem 1.* #emph[Put $k = d - 1$ and $epsilon = 1 - p$. Then
$ E_p = 1 + k / 2 epsilon log (1 \/ epsilon) + O_d (epsilon) quad (epsilon arrow.b 0) . $
For each fixed $M gt.eq 0$, there are constants
$0 < c_(d , M) lt.eq C_(d , M) < oo$ such that, for all sufficiently
small $epsilon$, every plan satisfying
$cal(E)_p (bb(P)) lt.eq E_p + M epsilon$ obeys
$ c_(d , M) epsilon lt.eq D (bb(P)) lt.eq C_(d , M) epsilon . $ In
particular such estimates hold for every optimizer.]

]
It suffices to work in the closed unit ball. Indeed its nearest-point
projection fixes the endpoints, is nonexpansive, and increases path mass
at projected points: every original path through $x$ produces a
projected path through its projection. Consequently both energy and mean
length do not increase. The same energy inequality is strict if the
original plan gives positive probability to excursions outside the ball:
where the radius is greater than one the derivative of the projection
has norm at most the reciprocal of the radius, and an excursion has
positive arclength in that open set. Compact-target existence then
follows from the standard direct method [2, §1.3] and
the finite upper construction below. To apply the near-optimal length
assertion to unrestricted competitors, we use the lower-bound proof
directly for any plan, as explained in Section~#link(<sec:carrier>)[3];.

= Upper bound by angular subdivision
<upper-bound-by-angular-subdivision>
Choose an integer $m gt.eq 1$. Radial projection of the $2 d$ faces of
$[- 1 , 1]^d$ covers the sphere. Divide each face into $m^k$ equal cubes
at level $0$, then refine each cube dyadically in all $k$ coordinates at
every step. Null seams may be assigned consistently. At depth $j$ there
are at most $N_j = 2 d (m 2^j)^k$ cells. Pick a representative direction
in each cell and place its node at radius $r_j = 1 - 2^(- j - 1)$.
Connect the level-zero nodes straight to the origin and each subsequent
node to its parent. For a destination in a cell, follow its nested chain
of nodes. The construction gives a measurable plan, since the cylinder
labels are Borel and the polygonal chains converge; they can be
parametrized by arclength so each has a terminal point at its assigned
destination. Uniform convergence of the tails follows from the edge
estimates below.

Between successive levels, the two directions $u , v$ are in the same
parent cell and satisfy $lr(|u - v|) lt.eq C_d m^(- 1) 2^(- j)$. For
$j gt.eq 1$,
$ lr(|r_j u - r_(j - 1) v|)^2 = (r_j - r_(j - 1))^2 + r_j r_(j - 1) lr(|u - v|)^2 , #h(2em) r_j - r_(j - 1) = 2^(- j - 1) . $
Thus the edge length is at most $2^(- j - 1) (1 + C prime_d m^(- 2))$.
The level-zero trunk length is $1 \/ 2$. On an edge carrying the mass
$a$ of its cell, the actual pointwise mass is at least $a$. Integrating
pathwise gives energy at most the sum of length times $a^p$ over the
construction edges, whether or not they overlap. The positive cell
masses at each level sum to one, so their $p$th powers have sum
$lt.eq N_j^epsilon$ by concavity. Hence
$ E_p lt.eq (2 d m^k)^epsilon (1 / 2 + (1 + C prime_d m^(- 2)) sum_(j gt.eq 1) 2^(- j - 1) 2^(j k epsilon)) . $
The convergent geometric sum is $1 \/ 2 + O_d (epsilon)$ near zero. With
$m = ⌈ epsilon^(- 1 \/ 2) ⌉$ the bracket is $1 + O_d (epsilon)$, and
$(2 d m^k)^epsilon = 1 + k / 2 epsilon log (1 \/ epsilon) + O_d (epsilon)$.
Here the square of $epsilon log (1 \/ epsilon)$ is $o (epsilon)$.

= A lower bound in terms of mean detour
<sec:carrier>
Fix a finite-energy plan and abbreviate $D = D (bb(P))$. Since
$theta lt.eq 1$, its mean arclength is at most its energy. Invoke
finite-energy rectifiability [2, Theorem 2.7]: there is a
Borel countably $1$-rectifiable carrier $S$ of its occupation measure
with $sigma$-finite $cal(H)^1$ measure. Only the part inside the unit
ball is used. For unrestricted paths the carrier assertion has the
following direct proof: for each $a > 0$, finitely many sampled images
can cover all but arbitrarily small occupation of the set
${ theta gt.eq a }$. Indeed $N$ independent path images miss each such
point with probability at most $(1 - a)^N$. Occupation is finite; take a
countable sequence of finite samples with misses tending to zero, then a
union over $a = 1 \/ n$. The set ${ theta = 0 }$ has zero occupation by
finite energy. The countable union of sampled images is the required
carrier. Image incidence is Borel, for paths constant after arrival, by
expressing it as a union over compact time intervals.

Call a path short if $ell lt.eq 2$, and write $theta_s , theta_l$ for
the corresponding masses through a point for short and long paths. A
long path has $ell - 1 > 1$ and $ell lt.eq 2 (ell - 1)$. Thus the mass
of long paths is at most $D$ and their total arclength at most $2 D$. In
particular
$ integral_(S inter { theta_l > theta_s }) theta_s thin d cal(H)^1 lt.eq integral_S theta_l thin d cal(H)^1 lt.eq 2 D . $

For a short path and a radius $r in (0 , 1)$, take its first point $x$
at distance $r$ from the origin. This is a Borel map of the path and
$r$: first hitting of ${ lr(|gamma|) gt.eq r }$ is expressed using the
running radius maximum on compact time intervals. Push forward
$d bb(P) (gamma) thin d r$ under this map to obtain $lambda_s$. For each
path, the selected radii landing in a Borel set $A$ are contained in the
radial image of $A inter "im" gamma$. The norm is $1$-Lipschitz, so their
Lebesgue measure is at most $cal(H)^1 (A inter "im" gamma)$, which itself
is bounded by the arclength occupation of $A$. Integrating, $lambda_s$
is supported on $S$ and dominated by $theta_s thin cal(H)^1 bar.v_S$.
Restrict $lambda_s$ to ${ theta_l lt.eq theta_s }$ and denote the result
by $lambda$, of mass $b gt.eq 1 - 3 D$. Its radial marginal is bounded
by Lebesgue measure on $(0 , 1)$. It is dominated by the full occupation
and satisfies $theta lt.eq 2 theta_s$ on its support in the
measure-theoretic sense.

For $x = r u$, $0 < r < 1$, and $y in S^(d - 1)$, a path through $x$
ending at $y$ has excess length at least
$ r + lr(|y - x|) - 1 = frac(r lr(|y - u|)^2, lr(|y - x|) + 1 - r) med gt.eq med r / 2 lr(|y - u|)^2 . $
The endpoint submeasure of short paths through $x$ is dominated by
$sigma$ and has mass $theta_s (x)$. The $sigma$-mass of a chordal cap of
radius $a$ is $lt.eq K_d a^k$, by elementary spherical geometry. Take
$K_d gt.eq 1$. At least half of this submeasure is outside the cap of
radius $(theta_s (x) \/ (2 K_d))^(1 \/ k)$ about $u$. Therefore
$ r thin theta_s (x)^(1 + 2 \/ k) lt.eq A_d integral_({ gamma : thin ell (gamma) lt.eq 2 , med x in "im" gamma }) (ell (gamma) - 1) thin d bb(P) (gamma) . $
Integrate over $S inter { 0 < lr(|x|) < 1 }$. By Tonelli and the short
path bound, the right side is at most $2 A_d D$. As
$lambda lt.eq theta_s cal(H)^1 bar.v_S$, this proves
$ integral r thin theta_s^(2 \/ k) thin d lambda lt.eq 2 A_d D . $ For
$D = 0$ this contradicts $b = 1$, because $r theta_s^(2 \/ k) > 0$
almost everywhere for $lambda$. Now assume $0 < D lt.eq 1 \/ 6$.
Concavity of $log$ for the probability measure $lambda \/ b$ and
$integral log r thin d lambda gt.eq - 1$ yield
$ integral log (1 \/ theta) thin d lambda & gt.eq k / 2 b log (frac(b, 2 A_d D)) - k / 2 - b log 2\
 & gt.eq k / 2 log (1 \/ D) - B_d . $ Indeed $b gt.eq 1 - 3 D$ and
$D log (1 \/ D)$ is bounded. Jensen is valid by truncation if an
integral is infinite. Finally, with $mu$ the arclength occupation,
$mu (bb(R)^d) = 1 + D$ and
$cal(E)_p = integral theta^(- epsilon) thin d mu$. The inequality
$e^t gt.eq 1 + t$, the domination $lambda lt.eq mu$, and nonnegativity
of $log (1 \/ theta)$ give
$ cal(E)_p (bb(P)) med gt.eq med 1 + D + k / 2 epsilon log (1 \/ D) - B_d epsilon . quad "(1)" $
The argument uses no assumptions of simplicity or uniqueness of paths.

= Conclusion
<conclusion>
When $D > 1 \/ 6$, the length alone gives energy at least $1 + 1 \/ 6$,
enough for the stated lower asymptotic. Otherwise the $D$-dependent
expression in (1) is globally minimized at
$D = k epsilon \/ 2$, giving the matching leading coefficient. Moreover,
any plan within $M epsilon$ of the infimum has $D lt.eq 1 \/ 6$ for
sufficiently small $epsilon$, by the upper bound. Subtracting the shared
leading term from the upper and lower estimates gives
$ D / epsilon - k / 2 log (D \/ epsilon) lt.eq C_d + M . $ The function
on the left diverges at both endpoints of $(0 , oo)$, proving the length
assertion.

In particular, when $d = 2$ the coefficient is $1 \/ 2$. The proof does
not identify a minimizer for a specified $p < 1$, establish symmetry,
count branchings or settle their presence at the origin. These questions
in the original formulation [1] remain separate.

= Scope and preparation

The angular tree and the radial-crossing lower bound yield opposite
bounds for the same Lagrangian energy. The cited stability
theorem [3] concerns limits of optimal plans under
perturbation of the terminal measures at fixed exponent, not this
expansion in the exponent. This preprint was prepared with AI assistance
and has not undergone peer review.


#heading(numbering: none)[References]
[1] Yana Teplitskaya. #link("https://arxiv.org/html/2611.03403v1#S2.SS2")[Open problems from the Length Optimization event at MDS 2026], Section 2.2. arXiv:2611.03403 (2026).

[2] Paul Pegon. #link("https://arxiv.org/abs/1709.01414")[On the Lagrangian branched transport model and the equivalence with its Eulerian formulation]. arXiv:1709.01414.

[3] Maria Colombo, Antonio De Rosa, Andrea Marchese, Paul Pegon and Antoine Prouff. #link("https://arxiv.org/abs/2003.11793")[Stability of optimal traffic plans in the irrigation problem]. _Discrete and Continuous Dynamical Systems_ 42 (2022), 1647–1667.
