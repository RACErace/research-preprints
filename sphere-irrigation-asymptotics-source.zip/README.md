# The leading energy correction for irrigation of a sphere

This is an analytic preprint. `main.typ` is the complete typeset source; a parallel LaTeX source is also included. With Typst 0.15.2, build using:

```sh
SOURCE_DATE_EPOCH=1795734000 typst compile main.typ sphere-irrigation-asymptotics.pdf
```

No numerical data or computation is needed for the proof. See `AUDIT.md` for scope and proof checkpoints.
