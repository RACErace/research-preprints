"""Exact checks of the Farey vertex formulas in the research note.

Run with Python 3, for instance: python3 verify.py --depth 10.
The verifier uses the standard library. Plotting with --figure also needs Matplotlib. Infinite convergence is proved in proof.md.
"""

import argparse
from fractions import Fraction as F

ETA = F(2, 5)
ROOT = ((0, 1), (1, 0))


def add(p, q):
    return p[0] + q[0], p[1] + q[1]


def sub(p, q):
    return p[0] - q[0], p[1] - q[1]


def mul(c, p):
    return c * p[0], c * p[1]


def rot(p):
    return -p[1], p[0]


def dot(p, q):
    return p[0] * q[0] + p[1] * q[1]


def parameter(p):
    return F(p[0], sum(p))


def h(t, eta):
    return 1 + t * t - t + eta * min(t, 1 - t)


def intercept(u, eta):
    return sum(u) * h(parameter(u), eta)


def potential(u, v, eta):
    return intercept(u, eta) + intercept(v, eta) - intercept(add(u, v), eta)


def solve(u, v, a, b):
    det = u[0] * v[1] - u[1] * v[0]
    assert det == -1
    return (a * v[1] - b * u[1]) / det, (u[0] * b - a * v[0]) / det


def endpoint(t, left):
    x, y = 2 * t - t * t, 1 - t * t
    return (x + ETA, y) if left else (x, y + ETA)


def endpoint_for_normal(u):
    t = parameter(u)
    p = endpoint(t, t <= F(1, 2))
    if t == F(1, 2):
        assert dot(u, p) == dot(u, endpoint(t, False))
    return p


def secant(l, r):
    return (h(r, ETA) - h(l, ETA)) / (r - l)


def verify_tree(depth):
    # Each stored position is obtained from the parent's signed tropical edge.
    cells = [(ROOT[0], ROOT[1], (F(0), F(0)), F(1))]
    checked = 0
    for level in range(depth + 1):
        children = []
        for u, v, parent_position, parent_a in cells:
            w = add(u, v)
            U, V = sum(u), sum(v)
            l, m, r = parameter(u), parameter(w), parameter(v)
            assert r - l == F(1, U * V)
            a = potential(u, v, ETA)
            baseline = F(1, U * V * (U + V))
            assert a == (baseline - ETA if level == 0 else baseline)
            assert a > 0
            cu, cv = intercept(u, ETA), intercept(v, ETA)
            G = solve(u, v, cu, cv)
            direction = rot(sub(v, u))
            z = add(parent_position, mul(parent_a - a, direction))
            assert z == sub(G, mul(a, direction))
            for normal in (u, v, w):
                c = intercept(normal, ETA)
                assert dot(normal, z) == c - a
                assert dot(normal, endpoint_for_normal(normal)) == c
            m_left, m_right = secant(l, m), secant(m, r)
            assert m_left == secant(l, r) - U * a
            assert m_right == secant(l, r) + V * a
            assert z[0] - z[1] == (U * m_left + V * m_right) / (U + V)
            cw = intercept(w, ETA)
            assert solve(u, w, cu, cw) == add(G, mul(a, rot(u)))
            assert solve(w, v, cw, cv) == sub(G, mul(a, rot(v)))
            if level:
                left = r <= F(1, 2)
                assert left or l >= F(1, 2)
                base = solve(u, v, intercept(u, 0) - a, intercept(v, 0) - a)
                assert sub(z, base) == ((ETA, 0) if left else (0, ETA))
                for t in (l, m, r):
                    difference = sub(z, endpoint(t, left))
                    assert dot(u, difference) / U == (t - l) ** 2 - a / U
                    assert max(map(abs, difference)) <= (r - l) ** 2 + 2 * (r - l)
            checked += 1
            if level < depth:
                children.extend(((u, w, z, a), (w, v, z, a)))
        cells = children
    return checked


def verify_jump_and_crossing():
    u, v = ROOT
    w = add(u, v)
    root_a = potential(u, v, ETA)
    assert root_a == F(1, 10) < potential(u, w, ETA) == F(1, 6)
    assert potential(w, v, ETA) == F(1, 6)
    partial = F(0)
    for j in range(100):
        partial += potential(add(u, mul(j, w)), w, ETA)
        partial += potential(w, add(v, mul(j, w)), ETA)
        terms = j + 1
        tail = F(1, 2 * (2 * terms + 1))
        assert partial + tail == F(1, 2)
    p_minus, p_plus = endpoint(F(1, 2), True), endpoint(F(1, 2), False)
    assert p_minus == (F(23, 20), F(3, 4))
    assert p_plus == (F(3, 4), F(23, 20))
    assert sub(p_plus, p_minus) == mul(root_a - F(1, 2), (w[1], -w[0]))
    assert endpoint(F(3, 10), True) == endpoint(F(7, 10), False) == (F(91, 100),) * 2


def verify_single_cell_translations():
    for k in range(1, 101):
        u, v = (1, k), (1, k - 1)
        delta = F(1, 2 * k + 1)
        assert (parameter(u), parameter(v)) == (F(1, k + 1), F(1, k))
        left_shift, right_shift = mul(delta, rot(u)), mul(-delta, rot(v))
        assert left_shift[0] == -F(k, 2 * k + 1) > -F(1, 2)
        assert right_shift[0] == F(k - 1, 2 * k + 1) >= 0



def draw_figure(path):
    """Draw the two endpoint arcs and the completion from their exact formulas."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.family": ["DejaVu Sans"],
        "svg.fonttype": "path",
        "svg.hashsalt": "farey-57",
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    figure, axes = plt.subplots(1, 2, figsize=(6.8, 3.05), layout="constrained")
    for ax, completed in zip(axes, (False, True)):
        for left, colour in ((True, "#145d7c"), (False, "#267259")):
            start = 0 if left else 100
            samples = [endpoint(F(i, 200), left) for i in range(start, start + 101)]
            ax.plot(*zip(*samples), color=colour, linewidth=2.2)
        ax.scatter([0.91], [0.91], s=12, color="#182b33", zorder=4)
        p_minus, p_plus = endpoint(F(1, 2), True), endpoint(F(1, 2), False)
        for name, p, offset in (("$P_-$", p_minus, (-10, -15)), ("$P_+$", p_plus, (3, 5))):
            ax.scatter(*p, s=14, color="#26343c", zorder=4)
            ax.annotate(name, p, xytext=offset, textcoords="offset points")
        if completed:
            for start, end in (((0, 1), endpoint(F(0), True)), (p_minus, p_plus)):
                ax.plot(*zip(start, end), "--", color="#a85328", linewidth=1.4)
                direction = sub(end, start)
                ax.annotate("", xy=add(start, mul(0.67, direction)),
                            xytext=add(start, mul(0.45, direction)),
                            arrowprops={"arrowstyle": "-|>", "color": "#a85328", "lw": 1.3})
        ax.set(aspect="equal", xlim=(-0.04, 1.28), ylim=(-0.04, 1.28),
               xticks=(0, 0.4, 0.8, 1.2), yticks=(0, 0.4, 0.8, 1.2), xlabel="$x$", ylabel="$y$")
        ax.set_title("$K$" if completed else "$S=E(P)$", fontsize=11)
        ax.grid(alpha=0.18)
    figure.savefig(path, metadata={"Date": None}, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--depth", type=int, default=10)
    parser.add_argument("--figure", help="Optional path for the figure (for example, example.svg)")
    args = parser.parse_args()
    depth = args.depth
    if depth < 0:
        parser.error("--depth must be nonnegative")
    nodes = verify_tree(depth)
    verify_jump_and_crossing()
    verify_single_cell_translations()
    print(f"Exact checks passed for {nodes} Farey cells, depths 0 through {depth}.")
    print("Root and child potentials: 1/10 and 1/6. Jump coefficient: -2/5.")
    print("Path labels 3/10 and 7/10 both end at (91/100, 91/100).")
    if args.figure:
        draw_figure(args.figure)
