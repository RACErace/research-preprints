# Farey 分支的收敛与逆恢复

- `proof.md` 是完整证明。区分带顺序的端点、裸端点集合与补线后的平面集合。论文没有解决一般裸端点集的单射性。
- `python3 -B verify.py --depth 13` 用精确分数复核有限层恒等式与自交例子；预期输出见 `VERIFY.txt`。无穷尾部与恢复定理由数学证明处理，不以有限计算代替。
- `example.svg` 为例图。重新绘制需 Matplotlib：`python3 verify.py --figure example.svg`。可用 Pandoc、Python Playwright、Chromium 和 Noto CJK 字体重排 PDF：`python3 render_pdf.py --chromium /path/to/chromium`。
