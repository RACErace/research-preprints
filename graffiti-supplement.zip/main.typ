#set document(title: "Sharp replacements for three Graffiti.pc inequalities")
#set page(paper: "a4", margin: (x: 26mm, y: 23mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.57em)
#set heading(numbering: "1.")
#let gam = math.gamma
#align(center)[
  #text(size: 21pt, weight: "semibold")[Sharp replacements for three \ Graffiti.pc inequalities]
  #v(5pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(3pt)
*Abstract.* We disprove Conjectures 138, 255 and 256 in DeLaViña's _Written on the Wall II_. A family of trees with a unique maximum independent set gives the first counterexample and shows that the factor of $2$, without the proposed bonus, is best possible when the distance is measured in the square. Two rook graphs augmented with hub vertices give the other counterexamples. A hub-star extension shows that the best universal coefficient in both total-domination inequalities is $1$, not $2$.

*Keywords:* induced path; graph square; total domination; rook graph. *MSC 2020:* 05C12, 05C69.

= The longest induced path and the square
Let $p(G)$ be the number of vertices in a longest induced path, and let $u(G)$ equal one if the maximum independent set is unique and zero otherwise. Write $M(G^2)$ for the vertices of maximum degree in the square, where two distinct vertices are adjacent when their distance in $G$ is at most two. Let $d$ be the least distance in $G^2$ between two distinct members of $M(G^2)$, whenever there are at least two. Conjecture 138 of @wow proposes $p(G) >= (2+u(G))d$.

*Proposition 1.* There is a 19-vertex tree with $p(G)=17$, $u(G)=1$ and $d=6$. For connected graphs the coefficient $2$ in $p(G)>=2d$ is sharp even under the extra condition $u(G)=1$.

_Proof._ For an even integer $ell>=14$, start with the path $v_0, dots, v_ell$ and attach two leaves to each endpoint. The diameter is $ell+2$ edges and the longest induced path has order $ell+3$. Every maximum independent set includes all four leaves. Indeed, an endpoint in the set can be replaced by its two leaves; an absent endpoint forces both leaves to be included by maximality. On the remaining odd path $v_1, dots, v_(ell-1)$ the maximum independent set is unique: an independent set of size $ell/2$ in $ell-1$ positions must start at the first position with successive gaps of two. Thus $u(G)=1$.

For a tree the square degree of a vertex equals the sum of the original degrees of its neighbors, since the distance-two contributions from different neighbors are disjoint. Exactly $v_1$ and $v_(ell-1)$ attain the maximum square degree, which is $5$. Their distance in the square is $(ell-2)/2$. At $ell=14$ this gives $17<3 dot 6$. The same example also violates the proposed inequality if distance is interpreted in the original graph. For the corrected bound in the square, the original distance for a pair at square distance $d$ is either $2d-1$ or $2d$. A shortest path is induced and has at least $2d$ vertices. In our family $(ell+3)/((ell-2)/2)$ tends to $2$, proving sharpness. $square$

= Total domination and edge neighborhoods
Let $N(v)$ denote an open neighborhood and $N(A)=union.big_(v in A) N(v)$. Put $L=max_(x y in E(G)) |N(x) union N(y)|$. Let $C$ denote the vertices of minimum eccentricity, and let $A$ denote the vertices of minimum degree. The total domination number $gam_t$ is the minimum size of a set $S$ with $N(S)=V(G)$. Conjectures 255 and 256 of @wow propose $gam_t L >= 2|C|$ and $gam_t L >= 2|N(A)|$, respectively.

*Proposition 2.* The two inequalities fail on graphs of orders 28 and 67, respectively. In each case replacing the coefficient $2$ by $1$ gives a valid and best possible inequality for connected graphs of order at least two.

_Proof._ Start with an $m$ by $m$ rook graph and add hubs on a path $a$–$b$–$c$. Partition the columns into three nonempty classes. Each rook is joined to exactly the hub for its column class. Distances between two rooks are at most two. A hub reaches any rook in at most two steps via a rook in the target row, and any two hubs are at distance at most two. In both instances below there is no universal vertex, so every vertex is central. The three hubs form a total dominating set. A smaller such set would have to be a pair forming an edge whose neighborhood union covers all vertices.

For Conjecture 255 take $m=5$ with $2,1,2$ columns assigned to the three hubs. Rooks have degree $9$, so rook edges contribute at most $18$ to $L$. Each hub edge sees $15$ rooks and all three hubs, giving $18$. For a rook incident to an end hub the neighborhood union is $11+9-5=15$: they share four rooks in its column and one in its row. For a rook incident to the middle hub the union is $7+9-4=12$. Thus $L=18$ and $gam_t=3$, giving $54<56$.

For Conjecture 256 take $m=8$ with class sizes $3,2,3$. The rook degree is $15$ and the hub degrees are $25,18,25$. Thus $A$ is precisely the set of rooks and $N(A)$ is the entire 67-vertex graph. Each hub edge sees $40$ rooks and three hubs. All other edge types have smaller degree sums, at most $40$. Thus $L=43$ and $gam_t=3$, giving $129<134$.

For any connected graph of order at least two, each degree is at most $L$ by considering an incident edge. The neighborhoods of a total dominating set cover the graph, so $gam_t L>=|V(G)|$. This gives both bounds with coefficient $1$.

To show sharpness, use a star of $k>=3$ hubs in the rook construction. Give the center two columns, and give each leaf hub $(m-2)/(k-1)$ columns, for $m equiv 2 mod (k-1)$ and $m$ sufficiently large at fixed $k$. As before every vertex is central. Rooks have degree $2m-1$, the center has degree $2m+k-1$, and leaf hubs have degree $m(m-2)/(k-1)+1$. The rooks are exactly the minimum-degree vertices and their open neighborhood covers the graph. The hubs totally dominate, and degree sums on individual edges give $L <= m^2/(k-1)+O_k(m)$. Hence $gam_t L/(m^2+k) <= k/(k-1)+o(1)$ as $m$ goes to infinity at fixed $k$. Taking arbitrarily large $k$ rules out any universal coefficient greater than $1$. $square$

The witnesses can also be checked by the supplied standalone Python script; the arguments above do not rely on that computation.

*Development disclosure.* OpenAI models were used to develop and check the arguments and prepare this manuscript.

#bibliography("references.bib", title: "References", style: "ieee")
