from collections import deque
from itertools import combinations, product

def adj(n, edges):
    a = [set() for _ in range(n)]
    for i, j in edges:
        a[i].add(j)
        a[j].add(i)
    return a

def distances(a, source):
    d = {source: 0}
    q = deque([source])
    while q:
        i = q.popleft()
        for j in a[i] - d.keys():
            d[j] = d[i] + 1
            q.append(j)
    assert len(d) == len(a)
    return d

def tree_witness():
    edges = [(i, i + 1) for i in range(14)]
    edges += [(0, 15), (0, 16), (14, 17), (14, 18)]
    a = adj(19, edges)
    ds = [distances(a, i) for i in range(19)]
    sq = [{j for j in range(19) if i != j and d[j] <= 2} for i, d in enumerate(ds)]
    m = [i for i, s in enumerate(sq) if len(s) == max(map(len, sq))]
    assert m == [1, 13]
    sd = distances(sq, m[0])[m[1]]
    assert sd == 6 and len(edges) == len(a) - 1
    lon = 1 + max(map(lambda d: max(d.values()), ds))
    for k in range(19, 0, -1):
        opt = [s for s in combinations(range(19), k) if all(y not in a[x] for x,y in combinations(s, 2))]
        if opt:
            break
    assert len(opt) == 1 and k == 11 and lon == 17 and lon < 3 * sd
    print(f"#138 n={len(a)}, max square-degree vertices={m}, square distance={sd}, largest induced path order={lon}, unique maximum independent set={opt[0]}")

def rook_star(k, m, root_cols=1):
    assert k >= 3 and m >= k and (m - root_cols) % (k - 1) == 0
    v = list(product(range(m), repeat=2))
    n = len(v) + k
    root = len(v)
    step = (m - root_cols) // (k - 1)
    classes = [1 + j // step for j in range(m - root_cols)]
    classes[m // 2:m // 2] = [0] * root_cols
    edges = [(i, j) for (i,(x,y)),(j,(z,w)) in combinations(enumerate(v), 2) if x == z or y == w]
    edges += [(root, root + j) for j in range(1,k)]
    edges += [(i, root + classes[y]) for i,(x,y) in enumerate(v)]
    return adj(n, edges), edges

def rook_witness():
    a, edges = rook_star(3, 5)
    centers = [i for i in range(len(a)) if max(distances(a,i).values()) == 2]
    edge_max = max(len(a[x]|a[y]) for x,y in edges)
    for k in range(1,len(a)+1):
        opt = next((s for s in combinations(range(len(a)), k) if len(set().union(*(a[i] for i in s))) == len(a)), None)
        if opt is not None:
            break
    assert len(centers) == 28 and k == 3 and edge_max == 18
    assert k * edge_max < 2 * len(centers)
    print(f"#255 n={len(a)}, center vertices={len(centers)}, total domination number={k}, extremal edge neighbourhood size={edge_max}")

def rook_min_witness():
    a, edges = rook_star(3, 8, 2)
    d = min(map(len,a))
    low = [i for i,N in enumerate(a) if len(N) == d]
    neighborhood = set().union(*(a[i] for i in low))
    edge_max = max(len(a[x]|a[y]) for x,y in edges)
    for k in range(1,len(a)+1):
        opt = next((s for s in combinations(range(len(a)), k) if len(set().union(*(a[i] for i in s))) == len(a)), None)
        if opt is not None:
            break
    assert d == 15 and len(low) == 64 and len(neighborhood) == 67
    assert k == 3 and edge_max == 43 and k * edge_max < 2 * len(neighborhood)
    print(f"#256 n={len(a)}, min-degree vertices={len(low)}, their neighbourhood size={len(neighborhood)}, total domination number={k}, extremal edge neighbourhood size={edge_max}")

if __name__ == "__main__":
    tree_witness()
    rook_witness()
    rook_min_witness()
