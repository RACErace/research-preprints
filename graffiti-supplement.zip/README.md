# Counterexamples and sharp coefficients for three Graffiti.pc conjectures

Primary source: Ermelinda DeLaViña, [Written on the Wall II](https://www.uhd.edu/academics/sciences/mathematics-statistics/wowii/files/wowiiaii.pdf), snapshot with November 6, 2026 footer. Conjectures 138 (pp. 79–80), 255 (p. 148) and 256 (p. 149) are each marked *open*. Exact-ID and equivalent-invariant searches did not turn up a prior resolution for the three exact statements. This does not establish absolute publication priority. The closely adjacent #254 and #257 are already marked false and have different numerators from #255 and #256. Checked on November 26, 2026: exact IDs and equivalent invariant combinations in web search, the aiXiv trace touching the catalogue, and the full [AI Village Graffiti verification campaign README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/raw/main/README.md), which documents 234 Graffiti results plus other literature. Its numeric matches #255 and #256 concern the first Written on the Wall catalogue or sequential counting, not the two Written on the Wall II claims here. Its #258/#259 claims were [retracted](https://grok-ai-village-news-496089.gitlab.io/articles/opus5-retracts-graffiti-conj258-259-eleven-to-nine.html); those rows have a different denominator (maximum spanning-tree leaf count) and are not addressed here.

## Conjecture 138

Let p(G) be the number of vertices of a longest induced path, u(G) the indicator that the maximum independent set is unique, and M(G²) the vertices with highest degree in the square (where pairs at distance at most two in G are joined). The claim is p(G) ≥ (2+u(G)) times the least distance between distinct members of M(G²).

Take a path v₀,…,v₁₄ and attach two leaves to each endpoint. This creates a tree T on 19 vertices. Its diameter is 16, so p(T)=17. Every maximum independent set includes all four added leaves: each endpoint can be replaced by its two pendant leaves, and if the endpoint is absent any missing leaf can be added. The remaining path v₁,…,v₁₃ has unique maximum independent set {v₁,v₃,…,v₁₃}: among 13 positions an independent subset of size 7 must start at 1 and leave exactly one gap everywhere. Thus u(T)=1.

In a tree the degree of v in the square is the sum of the original degrees of v's neighbors, because the distance-two contributions from different neighbors are disjoint. Thus the only vertices of degree 5 in T² are v₁ and v₁₃; the remaining vertices have lower degree. Their distance in T is 12 and in T² is 6. The claimed inequality fails: 17 < 18. If distances in the expression were instead measured in the original graph, the witness would still fail, with RHS 36.

The correction for distances in G² is sharp: every shortest G-path between vertices at G²-distance d has order at least 2d and is induced, since G²-distance equals ceil(G-distance / 2). In the above construction extend the spine to any even length ℓ≥14; p(T)=ℓ+3, M(T²)={v₁,v_(ℓ−1)}, d=(ℓ−2)/2, u(T)=1, and p(T)/d→2. Even when u=1 no universal positive bonus to the coefficient 2 is possible.

## Conjectures 255 and 256

Write γₜ for the least size of a total dominating set (each vertex must have a neighbor in the set, even if it lies in the set), and L for max |N(x) ∪ N(y)| over edges xy. Claim 255 is γₜL ≥ 2|C|, where C is the set of central vertices (those of minimum eccentricity). Claim 256 is γₜL ≥ 2|N(A)|, where A is the set of minimum-degree vertices and N(A) is its open neighborhood.

Use an m×m rook graph, whose vertices are cells adjacent precisely when they share a row or column. Add three hubs a—b—c and partition the columns into three nonempty classes, assigning each cell to a single hub according to class and joining it to that hub. All vertices are central: two rooks have distance at most two, a hub can reach any rook via a cell in the same row, a and c have distance two, and no vertex is universal in our examples. The hubs give a total dominating set of size three, and a total dominating set of size two would have to form an edge whose neighborhood union covers the graph.

For #255, use m=5 and column-class sizes 2,1,2; |C|=28. Grid vertices have degree 9, so two of them have neighborhood union of size at most 18. The two hub-hub edges each have union size 18 (three hubs and 15 cells). An edge from a or c to a rook has union size 11+9−5=15; the common neighbors are four other rooks in the same column and one in the same row. A b-to-rook edge has union size 7+9−4=12. Thus L=18 and γₜ=3, giving 54<56.

For #256, use m=8 and class sizes 3,2,3. The 64 grid vertices all have degree 15 and are exactly the minimum-degree vertices (hub degrees 25,18,25). Their neighborhood contains all 67 vertices. Either hub-hub edge has union size 43 (three hubs and 40 cells); hub-to-rook and rook-to-rook edges have smaller degree sums, hence L=43. Therefore γₜ=3 and 129<134.

## Both total-domination inequalities have sharp coefficient 1

In any connected graph with at least two vertices, the degree of every vertex is at most L, by considering an edge incident to it. The open neighborhoods of a total dominating set cover the vertex set, hence γₜL≥|V|. This proves both corrected inequalities with coefficient 1.

For sharpness take an m×m rook graph and replace the three hubs by a star of k≥3 hubs. Assign two columns to the central hub, divide the other columns equally among leaf hubs, and take m≡2 mod (k−1) with m sufficiently large. By the same distance argument all vertices are central, and the minimum-degree vertices are the rooks (degree 2m−1), whose open neighborhood contains all vertices. The k hubs totally dominate. A hub-hub edge covers at most m²/(k−1)+O_k(m) vertices: it reaches the center's two columns, a leaf hub's share of the remaining columns, and the hubs. A hub-to-rook edge satisfies the same asymptotic bound by degree sum, and rook-to-rook edges have degree sum at most 4m−2. Thus L≤m²/(k−1)+O_k(m), and γₜL/(m²+k) ≤ k/(k−1)+o(1) as m→∞ with k fixed. Then k→∞ gives the sharp coefficient 1 for both C and N(A).

All three finite examples were checked by the accompanying standalone Python script, using breadth-first distances and exact enumeration of small total dominating sets / the tree's maximum independent set.

The preprint is three-graffiti-inequalities.pdf. Its editable source is main.typ plus references.bib (Typst 0.15.2). Run python -B verify.py with standard Python 3; replay.txt records the exact witnesses. The paper itself provides analytic proofs.
