#set document(title: "A weighted Bernoulli inequality for at most ten positive weights")
#set page(paper: "a4", margin: (x: 26mm, y: 23mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.56em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#let P = math.bb("P")
#align(center)[
  #text(size: 21pt, weight: "semibold")[A weighted Bernoulli inequality \ for at most ten positive weights]
  #v(5pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(3pt)
*Abstract.* For independent Bernoulli random variables with parameter $p in [0,1/3]$ and a nonnegative vector of weights summing to one, Milojević and Sudakov conjecture that the probability for the weighted sum to reach its mean is at least $p$. We verify the entire real interval when there are at most ten positive weights. The proof uses a branching search over possible threshold families, rational linear certificates for bounds on $p$, and exact polynomial sign tests. It does not settle the conjecture for arbitrary support.

*Keywords:* weighted Bernoulli sum; threshold families; rational certificates. *MSC 2020:* 60E15, 05D05.

= Statement and subset reduction

*Theorem 1.* Let $0<=p<=1/3$ and let $B_1,dots,B_n$ be independent Bernoulli random variables of parameter $p$. If $w_i>=0$, $sum_i w_i=1$ and at most ten weights are positive, then
$ P[sum_i w_i B_i >= p] >= p. $

Conjecture 1 of @ms asks for this inequality without the support restriction. Their paper records a coupling for reciprocal $p$ and a connection to the Manickam–Miklós–Singhi problem. The Second Batch report of First Proof @fp establishes the case $p=2/k$ for integers $k>=6$, with no support restriction. Here the support is fixed and the parameter interval is continuous.

_Proof of the reduction._ Discard zero weights. The case $p=0$ is immediate. If a weight is at least $p$, then the corresponding success event alone has probability $p$ and ensures the desired threshold. Otherwise $x_i=w_i/p$ satisfy $1>x_1>=dots>=x_n>0$ after reordering, and $sum_i x_i=1/p>=3$. In particular $n>3$.

A subset $S$ of $[n]={1,dots,n}$ is heavy when $sum_(i in S) x_i>=1$ and light otherwise. Every singleton is light and every subset omitting at most two indices is heavy. For subsets $S,T$, say $S$ dominates $T$ if $|S inter [j]|>=|T inter [j]|$ at every $j$. Summation by parts gives $sum_(i in S) x_i>=sum_(i in T) x_i$ in that case: the difference is the sum of prefix-count differences multiplied by $x_j-x_(j+1)$, with $x_(n+1)=0$. Thus the heavy family is upward closed and the light family downward closed under dominance.

= Certifying an entire branch

A node records known heavy and light sets. For each $k$ let $a_k$ count known heavy sets of size $k$. The success probability is bounded below by $sum_k a_k p^k(1-p)^(n-k)$, since distinct outcomes of the Bernoulli vector are disjoint. The empty set is light. Set $q=p/(1-p)$. Dividing the lower bound by $p$ and clearing the positive denominator shows that it suffices to certify
$ F(q)=sum_(k=1)^n a_k q^(k-1)-(1+q)^(n-1)>=0. $ <poly>

The assumption $x_i<1$ gives $p>1/n$. To sharpen this lower bound, build a matrix $M$ from incidence rows of maximal known light sets, with right-hand sides one, and sorting rows $x_(i+1)-x_i<=0$, with right-hand sides zero. Write $b$ for the vector of right-hand sides. A nonnegative rational vector $v$ with $v^top M>=bold(1)^top$ componentwise gives
$ sum_i x_i < v^top b = U. $
In fact one multiplier on a light row must be positive: sorting rows have row sum zero and cannot alone dominate the all-ones row. Therefore at least one strict light inequality contributes to the estimate. If $U<=3$ the node is infeasible. Otherwise, for the probability check it suffices to consider the closed interval $[max(1/n,1/U),1/3]$ and its image under $p arrow.r q$.

For the polynomial test, nonnegative coefficients suffice. The other tests use exact arithmetic. If both endpoint evaluations are nonnegative and, after removing any zero at the left endpoint, the first nonzero right-hand sign is positive, a Sturm count of interior real roots of odd multiplicity can certify nonnegativity throughout. Indeed an interior root of even multiplicity does not change sign. As a shortcut, when the leading coefficient is positive and the coefficient sequence has at most one sign variation, Descartes' rule of signs and a nonnegative evaluation at the positive left endpoint suffice. The implementation handles the zero polynomial and one-point intervals separately.

If a bound has not yet closed a node, choose an unclassified set $S$. In the heavy child add $S$ and all sets dominating it; in the light child add $S$ and all sets dominated by it. Every actual sorted weight vector consistent with the node belongs to at least one child. Each child classifies a previously unknown set, so the tree is finite. A node not covered by a sign check or infeasibility estimate is never counted as a successful leaf; in particular an unclosed fully classified node aborts the proof replay.

= Reproduction

The implementation checks the following node counts in the reference replay; different valid choices of dual vector may change counts without changing the criteria for a valid leaf.
#align(center)[
  #table(columns: (auto, auto, auto, auto, auto, auto, auto, auto), align: center, inset: 4pt,
    [Support], [4], [5], [6], [7], [8], [9], [10],
    [Nodes], [1], [17], [51], [159], [745], [3,441], [27,019])
]
SciPy proposes dual coefficients. The replay converts them to rational numbers, verifies nonnegativity and every coordinate of $v^top M>=bold(1)^top$, and computes $U$ using those verified numbers. No LP optimality claim is needed. Polynomial signs and root counts are exact. With assertions enabled the supplied program closes every branch through ten weights, which completes the proof.

*Development disclosure.* OpenAI models were used to develop the argument, implement the checker and prepare the manuscript.

#bibliography("references.bib", title: "References", style: "ieee")
