"""Verify Milojevic–Sudakov's weighted Bernoulli inequality up to a given n.
Usage: OPENBLAS_NUM_THREADS=1 python verify.py 10
Requires numpy, scipy, sympy. SciPy only proposes dual LP certificates;
all accepted certificates and all polynomial sign checks use exact rationals.
Coordinates are ranked highest first; each mask denotes a subset of coordinates.
"""
import itertools, math, functools, sys
import numpy as np
from scipy.optimize import linprog
from fractions import Fraction as F
from collections import Counter
import sympy as sp
def run(n):
  cnt=Counter(); allmask=(1<<(1<<n))-1
  ks=[s.bit_count() for s in range(1<<n)]
  a=np.array([[(s>>j)&1 for j in range(n)] for s in range(1<<n)])
  pref=np.cumsum(a, axis=1)
  above=[sum(1<<i for i in range(1<<n) if np.all(pref[i]>=pref[j])) for j in range(1<<n)]
  below=[sum(1<<i for i in range(1<<n) if np.all(pref[i]<=pref[j])) for j in range(1<<n)]
  def bits(mask):
    while mask:
     b=mask&-mask
     yield b.bit_length()-1
     mask-=b
  x=sp.symbols('x')
  @functools.cache
  def polynomial(co):
    # q=p/(1-p), probability/p = sum_k co[k]*q**(k-1)/(1+q)**(n-1).

    return sp.Poly(sum((co[k+1]-math.comb(n-1,k))*x**k for k in range(n)),x)
  def rat(t): return sp.Rational(t.numerator,t.denominator)
  @functools.cache
  def check(co,t):
    l=rat(max(F(1,n),F(1,t))); r=sp.Rational(1,3)
    l=l/(1-l);r=r/(1-r)
    px=polynomial(co)
    if l>r:return True
    if not any(z<0 for z in px.all_coeffs()):return True
    # Square-free parts of odd multiplicity are exactly the sign-changing roots.
    # Count them with exact Sturm arithmetic, after removing endpoints.
    if px.is_zero:return True
    if px.eval(l)<0 or px.eval(r)<0:return False
    if l==r:return True
    coeff=[c for c in px.all_coeffs() if c]
    # Descartes: if there is at most one sign variation and the leading
    # coefficient is positive, after a nonnegative value there can be no
    # subsequent negative interval on the positive half-line.
    if coeff[0]>0 and sum(int(bool(z*w<0)) for z,w in zip(coeff,coeff[1:]))<=1:return True
    w=px
    fac=sp.Poly(x-l,x)
    while w.eval(l)==0:w=w.exquo(fac)
    if w.eval(l)<0:return False
    for f,mul in px.sqf_list()[1]:
      if mul%2==0:continue
      num=f.count_roots(l,r) - int(f.eval(l)==0) - int(f.eval(r)==0)
      if num != 0:return False
    return True
  # Light subsets have sum < 1 for x_i=w_i/p; heavy subsets have sum >= 1.
  # With sorted x, prefix-count dominance implies weighted-sum dominance.
  # Every assignment is kept in one of the two branches below.
  def go(H,L):
    cnt['states']+=1
    u=allmask^(H|L)
    co=[0]*(n+1)
    for s in bits(H):co[ks[s]]+=1
    if check(tuple(co),F(n)):
      cnt['prune polynomial']+=1;return
    # Given a dual v>=0 with v^T M>=1 coordinatewise, sum x_i<=v^T b.
    # The inequality is strict: v^T M>=1 forces some strict light row to have
    # positive multiplier, since all sortedness rows sum to zero.
    # all maximal light sets plus sorted coordinates x_i>=x_{i+1}.
    ls=[s for s in bits(L) if not ((above[s]^(1<<s))&L)]
    pairs=[np.eye(n)[j+1]-np.eye(n)[j] for j in range(n-1)]
    M=np.array([*a[ls],*pairs],dtype=int); b=[1]*len(ls)+[0]*(n-1)
    res=linprog(-np.ones(n), A_ub=M, b_ub=b, bounds=(0,None),method='highs')
    assert res.success
    v=[F(float(-y)).limit_denominator(100000) for y in res.ineqlin.marginals]
    assert min(v)>=0 and min(sum(v[i]*int(M[i,j]) for i in range(len(v))) for j in range(n))>=1
    t=sum(v[i]*b[i] for i in range(len(v)))
    if t<=3:
      cnt['prune total']+=1;return # first LS rows are strict; one positive multiplier
    if check(tuple(co),t):
      cnt['prune LP polynomial']+=1;return
    if not u:
      print('uncertified',n,co,t,H,L);raise SystemExit(1)
    s=max(bits(u),key=lambda s: ((above[s]&u).bit_count()+ (below[s]&u).bit_count()))
    go(H|above[s],L);go(H,L|below[s])
  if n<=3: print(n,'trivial');return
  # all singletons light; every subset whose complement has at most 2 elements is heavy.
  H=sum((1<<s) for s in range(1<<n) if ks[s]>=n-2)
  L=1+sum(1<<(1<<j) for j in range(n))
  go(H,L)
  print(n,cnt,check.cache_info(), flush=True)
for n in range(4, int(sys.argv[1])+1):run(n)
