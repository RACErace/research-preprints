"""Exact finite scan of all subsets of the upstream cylie window certificates."""
import re
from fractions import Fraction as F
from itertools import combinations
from decimal import Decimal, localcontext
from pathlib import Path
from verify import cross,dot

def sqdist(a,b):
    A,V,S=a[:3],a[4:],a[3]
    B,W,T=b[:3],b[4:],b[3]
    assert dot(A,A)==S*S and dot(A,V)==0 and S>0 and dot(V,V)>0
    assert dot(B,B)==T*T and dot(B,W)==0 and T>0 and dot(W,W)>0
    p=tuple(b*S-a*T for a,b in zip(A,B))
    c=cross(V,W)
    c2=dot(c,c)
    if c2:return F(dot(p,c)**2,(S*T)**2*c2)
    q=cross(p,V)
    return F(dot(q,q),(S*T)**2*dot(V,V))
def feasible(n,k,E,dist,val):
    adj=[0]*n
    for (a,b),d in zip(E,dist):
        if d>=val:
            adj[a]|=1<<b;adj[b]|=1<<a
    def go(S,k):
        if k==0:return True
        while S.bit_count()>=k:
            b=S&-S; S^=b
            if go(S&adj[b.bit_length()-1],k-1): return True
        return False
    return go((1<<n)-1,k)
scores={n:(F(0),'') for n in range(8,14)}
for P in sorted(Path('reference/cWindows').glob('cyl_window_N*.txt')):
    L=[tuple(map(int,re.findall(r'-?\d+',s))) for s in P.read_text().splitlines()]
    L=[x for x in L if len(x)==7]
    n=len(L)
    E=list(combinations(range(n),2))
    ds=[sqdist(L[a],L[b]) for a,b in E]
    Q=sorted(set(ds))
    for k in scores:
        if n<k:continue
        l=-1;r=len(Q)
        while r>l+1:
            m=(r+l)//2
            if feasible(n,k,E,ds,Q[m]):l=m
            else:r=m
        assert l>=0
        if Q[l]>scores[k][0]:scores[k]=Q[l],P.name
with localcontext() as C:
    C.prec=32
    for k,(a,f) in scores.items():
        v=(Decimal(a.numerator)/a.denominator).sqrt()
        print(k,v/(2-v),f)
