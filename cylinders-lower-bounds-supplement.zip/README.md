# Certified lower bounds for cylinders touching a unit sphere

For N = 8, 9, 10 the supplied packings prove strict lower bounds of 0.70215, 0.61196, and 0.54515, respectively. These are not exact maxima. The open nine-cylinder insertion question requires reaching approximately 0.6199144.

## Reproduce the theorem

Run with Python 3.11 or newer and its standard library only:

    python -B verify.py
    python -B verify_independent.py

Do not disable assertions. Both checks authenticate the rational tangency and all pairwise separation inequalities for the coordinates in certificates.json. They produce the same exact minimum squared separation for each packing. The first checker uses integer cross products; the second uses rational Gram projection. Output from clean runs is included.

Rebuild the manuscript with Typst 0.15.2:

    typst compile main.typ cylinders-lower-bounds.pdf

## Audit the older data comparison

This optional step compares against the authored window archive, not against an assumed absence of better packings. It does not enter the new proof.

    git clone https://github.com/maticivan/cylie.git reference
    git -C reference checkout c306097711481fcaf359bcda94f7c32fbab13273
    python -B prior_compare.py

The scanner parses the published tangent lines, calculates exact distances, and compares every subset size by a finite clique test. It prints high-precision approximations only after making all finite comparisons exactly.
