#set document(title: "Certified lower bounds for eight, nine and ten cylinders touching a unit sphere")
#set page(paper: "a4", margin: (x: 25mm, y: 23mm), numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true, leading: 0.61em)
#set heading(numbering: "1.")
#set math.equation(numbering: "(1)")
#align(center)[
  #text(size: 21pt, weight: "semibold")[Certified lower bounds for eight, nine \ and ten cylinders touching a unit sphere]
  #v(5pt)
  #text(size: 9pt, fill: luma(90))[Research preprint · 26 November 2026 · Version 1.0]
]
#v(6pt)
*Abstract.* Let $R_N$ denote the greatest radius of $N$ congruent infinite circular cylinders with disjoint interiors, each tangent to the unit sphere. We construct exact packings proving $R_8>0.70215$, $R_9>0.61196$, and $R_10>0.54515$. The configurations use integer quaternions, and all separation inequalities are certified by integer or rational arithmetic. The nine-cylinder bound brings the known constructions closer to the threshold for inserting a ninth cylinder into the rearranged parallel eight-cylinder ring; it does not reach that threshold.

*Keywords:* cylinder packing; tangent lines; exact certificates. *MSC 2020:* 52C15, 52C17.

= Bounds and comparison
Every cylinder is assumed to have infinite length. Its axis is at distance $1+r$ from the origin if its radius is $r$ and it is tangent to the unit sphere. Scaling the axes by $1/(1+r)$ thus identifies the problem with packing tangent lines of pairwise separations at least $2r/(1+r)$ on the unit sphere.

*Theorem 1.* The greatest admissible radii for eight, nine and ten cylinders satisfy
$ R_8>14043/20000, quad R_9>15299/25000, quad R_10>10903/20000. $

The following table compares the constructions with the previously reported lower bounds in @gl. The deposited-subset column also credits the usable slack in the deposited construction files of @mrs: taking subsets of those constructions can give a larger radius than the target for which they were originally deposited. We scanned every published window configuration in @data, evaluating pairwise distances exactly. At any rational squared threshold $s$, a valid subset is a clique in the finite graph having an edge exactly when its squared separation is at least $s$. Enumerating these cliques over the sorted distinct pairwise squared distances gives the best subset. The deposited-subset entries are rounded down and are not upper bounds on $R_N$.

#align(center)[
  #table(
    columns: (auto, auto, auto, auto), inset: (x: 8pt, y: 5pt),
    align: center, stroke: (x: none, y: 0.45pt + luma(190)),
    [$N$], [Lower bound in @gl], [Best deposited subset], [New strict lower bound],
    [8], [0.67149], [0.54121317], [0.70215],
    [9], [0.519803], [0.54121317], [0.61196],
    [10], [0.519803], [0.54121229], [0.54515],
  )
]

For comparison, the unproved eight-ring insertion question in @mrs, Conjecture 13.1, concerns nine cylinders at the specific radius $sin(pi/8)/(1-sin(pi/8))$, approximately $0.6199144$. The strict $0.61196$ bound is below that radius. The result gives no upper bound on $R_9$.

= Exact proof of the construction
Let $(w,x,y,z)$ be a nonzero integer quaternion and set $S=w^2+x^2+y^2+z^2$. For each line in the construction we take its tangent point $P/S$ and a direction $V/S$, where $P$ and $V$ are the first and third columns, respectively, of the integer rotation numerator:
$ P=(w^2+x^2-y^2-z^2,2(x y+w z),2(x z-w y)), $
$ V=(2(x z+w y),2(y z-w x),w^2-x^2-y^2+z^2). $
Direct multiplication gives $P dot P=V dot V=S^2$ and $P dot V=0$. These identities certify exact tangency. The certificate quaternions are supplied with the paper. For nine lines they can also be given compactly using the following four seeds and their images under a half-turn about the third coordinate axis:
#let cert = json("certificates.json")
#let q9 = cert.at(1).quaternions.slice(0,4)
#align(center)[
  #table(columns: (auto,auto,auto,auto), align: right, inset: (x: 9pt, y: 4pt),
    stroke: (x: none, y: 0.4pt + luma(200)),
    [$w$], [$x$], [$y$], [$z$],
    ..q9.map(q => q.map(v => str(v))).flatten())
]
For each seed $q=(w,x,y,z)$ the half-turn adds $(-z,-y,x,w)$, with overall sign immaterial. The ninth line uses quaternion $(1,0,-1,0)$ and is fixed as an unoriented line by that half-turn. The other packings require no symmetry assumption.

Take two certified lines defined by $(P,V,S)$ and $(Q,W,T)$. Put $J=S Q-T P$ and $H=V times W$. If $H$ is nonzero, the squared distance is
$ d^2 = (J dot H)^2 / ((S T)^2 (H dot H)). $
For $H=0$ use $d^2 = ((J times V) dot (J times V)) / ((S T)^2 (V dot V))$. For a target rational radius $a/b$, compare the squared distance numerator times $(a+b)^2$ to the denominator times $4a^2$. The strict integer comparison succeeds for 28, 36 and 45 pairs at the respective radii in Theorem 1. Since each configuration has finitely many pairs and the threshold is continuous in radius, its strict inequalities allow a slight increase of radius. Scaling back to axes at distance $1+r$ gives the claimed strict inequalities for $R_N$.

The supplied second checker evaluates all separations by a different formula: it subtracts the squared norm of the displacement projected on the span of the unit direction vectors using a two-by-two rational Gram matrix. It reproduces the same exact minimum squared separations. Thus no numerical optimizer output, convergence claim or decimal arithmetic is needed for the proof.

*Development disclosure.* OpenAI models were used to develop the constructions, build the verification programs and prepare the manuscript. Floating-point constrained optimization was used for candidate discovery only. The finite exact checks are reproducible from the supplied data.

#bibliography("references.bib", title: "References", style: "ieee")
