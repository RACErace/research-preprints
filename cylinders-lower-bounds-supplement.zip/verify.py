"""Check every pair of rational tangent lines using integer arithmetic only."""
from itertools import combinations
import json
from pathlib import Path
from math import gcd

def dot(u,v):return sum(a*b for a,b in zip(u,v,strict=True))
def cross(u,v):
    a,b,c=u;d,e,f=v
    return b*f-c*e,c*d-a*f,a*e-b*d

def frame(q):
    w,x,y,z=q
    S=dot(q,q)
    P=(w*w+x*x-y*y-z*z,2*(x*y+w*z),2*(x*z-w*y))
    V=(2*(x*z+w*y),2*(y*z-w*x),w*w-x*x-y*y+z*z)
    assert S>0 and dot(P,P)==dot(V,V)==S*S and dot(P,V)==0
    return P,V,S

def dist_sq(A,B):
    P,V,S=A
    Q,W,T=B
    p=tuple(b*S-a*T for a,b in zip(P,Q,strict=True))
    u=cross(V,W)
    v=dot(u,u)
    if v:
        return dot(p,u)**2,(S*T)**2*v
    u=cross(p,V)
    return dot(u,u),(S*T)**2*dot(V,V)

def main():
    data=json.loads(Path(__file__).with_name('certificates.json').read_text())
    for witness in data:
        N=witness['count']
        a,b=witness['radius']
        assert a>0 and b>0 and len(witness['quaternions'])==N
        axes=[frame(q) for q in witness['quaternions']]
        total=0
        worst=None
        for i,j in combinations(range(N),2):
            l,r=dist_sq(axes[i],axes[j])
            assert l*(a+b)**2>r*4*a*a,(N,i,j)
            if worst is None or l*worst[1]<r*worst[0]:
                worst=l,r,i+1,j+1
            total+=1
        d,e,i,j=worst
        g=gcd(d,e)
        print(f'{N}: radius > {a}/{b}; {total} exact pair checks; closest pair ({i},{j})')
        print(f'  minimum squared separation = {d//g}/{e//g}')

if __name__=='__main__':main()
