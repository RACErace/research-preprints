"""Check the supplied coordinates using rational Gram projection (no cross products)."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

def dot(u,v):return sum(a*b for a,b in zip(u,v,strict=True))
def columns(q):
    w=q[0]; v=q[1:]; s=dot(q,q)
    # Rodrigues formula in quaternion form; rotate e_x and e_z.
    M=((0,-v[2],v[1]),(v[2],0,-v[0]),(-v[1],v[0],0))
    A=[[F((2*w*w-s)*(i==j)+2*v[i]*v[j]+2*w*M[i][j],s) for j in range(3)] for i in range(3)]
    x=tuple(r[0] for r in A);z=tuple(r[2] for r in A)
    assert dot(x,x)==dot(z,z)==1 and dot(x,z)==0
    return x,z
def distance(p,u,q,v):
    w=tuple(b-a for a,b in zip(p,q,strict=True))
    a=dot(w,u);b=dot(w,v);c=dot(u,v)
    d=1-c*c
    assert d>=0
    return dot(w,w) - ((a*a-2*c*a*b+b*b)/d if d else a*a)

for W in json.loads(Path(__file__).with_name('certificates.json').read_text()):
    r=F(*W['radius'])
    axes=[columns(q) for q in W['quaternions']]
    assert len(axes)==W['count']
    D=min(distance(*a,*b) for a,b in combinations(axes,2))
    assert D>(2*r/(1+r))**2
    print(f"{W['count']}: exact Gram-distance test passed at {r}; min squared = {D}")
